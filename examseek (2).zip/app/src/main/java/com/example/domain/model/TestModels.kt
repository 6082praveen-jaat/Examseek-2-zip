package com.example.domain.model

enum class Difficulty {
  EASY, MEDIUM, HARD
}

enum class QuestionStatus {
  NOT_VISITED,
  NOT_ANSWERED,
  ANSWERED,
  MARKED_FOR_REVIEW,
  ANSWERED_AND_MARKED_FOR_REVIEW
}

data class TestQuestion(
  val id: String,
  val testId: String,
  val subject: String,
  val topic: String = "General",
  val questionText: String,
  val hindiQuestionText: String = "",
  val options: List<String>,
  val hindiOptions: List<String> = emptyList(),
  val correctOptionIndex: Int, // 0..3
  val explanation: String,
  val hindiExplanation: String = "",
  val difficulty: Difficulty = Difficulty.MEDIUM,
  val source: String = "ExamSeek Academic Team",
  val year: String = "2024",
  val shift: String = "Shift-1",
  val paper: String = "Paper-1",
  val officialAnswerKeyRef: String = "",
  val isVerified: Boolean = true,
  val sourceLabel: String = "OFFICIAL_VERIFIED_PYQ", // "OFFICIAL_VERIFIED_PYQ", "UNOFFICIAL_MEMORY_BASED", "AI_GENERATED_PRACTICE", "ADMIN_UPLOAD", "NEEDS_REVIEW"
  val contentHash: String = "",
  val targetExam: String = "SSC CGL",
  val stage: String = "Tier-1"
) {
  val correctAnswer: String
    get() = if (correctOptionIndex in 0..3) listOf("A", "B", "C", "D")[correctOptionIndex] else "A"
}

data class TestItem(
  val id: String,
  val title: String,
  val category: ExamCategory,
  val type: TestType,
  val durationMinutes: Int,
  val totalQuestions: Int = 15, // Standard practice test contains exactly 15 questions
  val totalMarks: Float = 30.0f,
  val marksPerQuestion: Float = 2.0f,
  val negativeMarkingRate: Float = 0.5f,
  val isNegativeMarkingEnabled: Boolean = true,
  val isVerified: Boolean = true,
  val subject: String = "All Subjects",
  val description: String = "",
  val tier: SubscriptionTier = SubscriptionTier.FREE,
  val attemptsCount: Int = 1240,
  val examYear: String = "2024",
  val examShift: String = "Shift-1"
)

data class UserAnswer(
  val questionId: String,
  val selectedOption: Int?,
  val isMarkedForReview: Boolean = false,
  val timeSpentSeconds: Int = 0
)

data class TestResult(
  val attemptId: String,
  val testId: String,
  val testTitle: String,
  val category: ExamCategory,
  val totalQuestions: Int,
  val correctAnswersCount: Int,
  val incorrectAnswersCount: Int,
  val unattemptedCount: Int,
  val marksObtained: Float,
  val totalMarks: Float,
  val accuracyPercentage: Float,
  val timeSpentSeconds: Int,
  val totalTimeSeconds: Int,
  val negativeMarkingApplied: Boolean,
  val negativeMarksDeducted: Float,
  val percentileEstimate: Float,
  val dateTimestamp: Long,
  val questions: List<TestQuestion>,
  val userAnswers: Map<String, Int?>
)

data class StudyMaterialItem(
  val id: String,
  val title: String,
  val category: String,
  val subject: String,
  val dateLabel: String,
  val content: String,
  val source: String,
  val tier: SubscriptionTier = SubscriptionTier.FREE
)

data class WrongAnswerItem(
  val id: String,
  val question: TestQuestion,
  val userWrongOption: Int,
  val recordedAt: Long,
  val isResolved: Boolean = false
)

data class SubscriptionPlan(
  val id: String,
  val tier: SubscriptionTier,
  val durationTitle: String,
  val priceInRupees: Int,
  val originalPriceInRupees: Int,
  val billingPeriod: String,
  val discountLabel: String,
  val features: List<String>
)

data class MultiApproachDoubtSolution(
  val questionStatement: String,
  val finalAnswer: String,
  val formulasUsed: List<String>,
  val method1Beginner: MethodExplanation,
  val method2ShortTrick: MethodExplanation,
  val method3Alternative: MethodExplanation,
  val verification: String,
  val subjectNuance: String,
  val sourceModel: String,
  val isFallback: Boolean = false,
  val isImageUnclear: Boolean = false
)

data class MethodExplanation(
  val title: String,
  val summary: String,
  val steps: List<String>,
  val speedTimeSeconds: String = "30-45 sec"
)
