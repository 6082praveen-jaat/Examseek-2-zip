package com.example.data.formula

import com.example.domain.formula.SolvedExample
import com.example.domain.formula.TopicPracticeMcq

object FormulaTopicBuilder {

  fun createMcq(
    id: String,
    q: String,
    hq: String = "",
    optA: String,
    optB: String,
    optC: String,
    optD: String,
    correctIdx: Int,
    exp: String,
    hexp: String = ""
  ): TopicPracticeMcq {
    return TopicPracticeMcq(
      id = id,
      question = q,
      hindiQuestion = hq,
      options = listOf(optA, optB, optC, optD),
      correctOptionIndex = correctIdx,
      explanation = exp,
      hindiExplanation = hexp
    )
  }

  fun createExample(
    id: String,
    problem: String,
    hindiProblem: String = "",
    steps: List<String>,
    ans: String,
    shortcut: String = ""
  ): SolvedExample {
    return SolvedExample(
      id = id,
      problem = problem,
      hindiProblem = hindiProblem,
      stepByStepSolution = steps,
      finalAnswer = ans,
      shortcutTip = shortcut
    )
  }
}
