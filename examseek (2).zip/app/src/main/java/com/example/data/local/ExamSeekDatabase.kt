package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.ActiveTestSessionDao
import com.example.data.local.dao.BookmarkDao
import com.example.data.local.dao.QuestionDao
import com.example.data.local.dao.StudyMaterialDao
import com.example.data.local.dao.SubscriptionOrderDao
import com.example.data.local.dao.TestAttemptDao
import com.example.data.local.dao.TestDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WrongAnswerDao
import com.example.data.local.entity.ActiveTestSessionEntity
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.QuestionEntity
import com.example.data.local.entity.StudyMaterialEntity
import com.example.data.local.entity.SubscriptionOrderEntity
import com.example.data.local.entity.TestAttemptEntity
import com.example.data.local.entity.TestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WrongAnswerEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    UserEntity::class,
    TestEntity::class,
    QuestionEntity::class,
    TestAttemptEntity::class,
    ActiveTestSessionEntity::class,
    WrongAnswerEntity::class,
    StudyMaterialEntity::class,
    SubscriptionOrderEntity::class,
    BookmarkEntity::class
  ],
  version = 4,
  exportSchema = false
)
abstract class ExamSeekDatabase : RoomDatabase() {
  abstract fun userDao(): UserDao
  abstract fun testDao(): TestDao
  abstract fun questionDao(): QuestionDao
  abstract fun testAttemptDao(): TestAttemptDao
  abstract fun activeTestSessionDao(): ActiveTestSessionDao
  abstract fun wrongAnswerDao(): WrongAnswerDao
  abstract fun studyMaterialDao(): StudyMaterialDao
  abstract fun subscriptionOrderDao(): SubscriptionOrderDao
  abstract fun bookmarkDao(): BookmarkDao

  companion object {
    @Volatile
    private var INSTANCE: ExamSeekDatabase? = null

    fun getInstance(context: Context): ExamSeekDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          ExamSeekDatabase::class.java,
          "examseek_database.db"
        )
          .addCallback(object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
              super.onCreate(db)
              CoroutineScope(Dispatchers.IO).launch {
                val database = getInstance(context)
                database.userDao().insertUser(SampleExamData.defaultUser)
                database.userDao().insertUser(SampleExamData.defaultAdmin)
                database.testDao().insertTests(SampleExamData.sampleTests)
                database.questionDao().insertQuestions(SampleExamData.sampleQuestions)
                database.studyMaterialDao().insertMaterials(SampleExamData.sampleStudyMaterials)
              }
            }
          })
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
