package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object EnglishTopicsPart1 {
  val topics: List<FormulaTopic> = listOf(
    // 1. Parts of Speech
    FormulaTopic(
      id = "eng_parts_of_speech",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Fundamentals",
      title = "Parts of Speech",
      hindiTitle = "शब्द भेद",
      summary = "The 8 fundamental building blocks of English grammar: Noun, Pronoun, Verb, Adjective, Adverb, Preposition, Conjunction, Interjection.",
      coreFormula = "Sentence Structure: Subject (Noun/Pronoun) + Verb + Object (Noun/Pronoun) + Modifiers (Adjectives/Adverbs)\nPrepositional Phrase = Preposition + Object of Preposition\nCoordinate Clause = Clause + Coordinating Conjunction + Clause",
      symbolExplanations = listOf(
        "Noun" to "Naming word for person, place, thing, or concept.",
        "Pronoun" to "Replaces a noun (he, she, it, they).",
        "Verb" to "Action, state, or occurrence word.",
        "Adjective" to "Modifies or qualifies a noun or pronoun.",
        "Adverb" to "Modifies a verb, adjective, or another adverb.",
        "Preposition" to "Shows spatial, temporal, or logical relationship.",
        "Conjunction" to "Connects words, phrases, or clauses.",
        "Interjection" to "Expresses spontaneous emotion or exclamation."
      ),
      importantIdentities = listOf(
        "Same word can function as different parts of speech depending on context (e.g. 'fast' as adjective: 'fast car'; as adverb: 'he ran fast'; as verb: 'they fast on Fridays')."
      ),
      shortcutsAndTips = listOf(
        "Identify grammatical function in sentence rather than memorizing static word definitions."
      ),
      commonMistakes = listOf(
        "Calling 'fastly' an adverb (there is no word 'fastly' in standard English; 'fast' is both adjective and adverb)."
      ),
      solvedExamples = listOf(
        createExample(
          "pos_ex1",
          "Identify the part of speech of 'well' in: 'She did very well in the examination.'",
          "'She did very well in the examination' में 'well' पहचानिए।",
          listOf(
            "Step 1: Ask what 'well' modifies: It answers 'how did she do?'.",
            "Step 2: 'Do' (did) is a verb.",
            "Step 3: A word modifying a verb is an ADVERB."
          ),
          "Adverb",
          "Answers 'how' regarding the verb."
        ),
        createExample(
          "pos_ex2",
          "Identify 'down' in: 'He went down the stairs.'",
          "'He went down the stairs' में 'down' पहचानिए।",
          listOf(
            "Step 1: 'down' connects the verb 'went' with the noun phrase 'the stairs'.",
            "Step 2: 'the stairs' is the object of 'down'.",
            "Step 3: Therefore, 'down' functions as a PREPOSITION."
          ),
          "Preposition",
          "Preposition takes a noun object."
        ),
        createExample(
          "pos_ex3",
          "Identify 'but' in: 'There is no one but loves his motherland.'",
          "'There is no one but loves his motherland' में 'but' पहचानिए।",
          listOf(
            "Step 1: Here 'but' means 'who does not'.",
            "Step 2: It stands in place of a relative pronoun.",
            "Step 3: It functions as a Relative Pronoun."
          ),
          "Relative Pronoun (or Conjunction)",
          "'But' functioning as negative relative pronoun."
        )
      ),
      practiceMcqs = listOf(
        createMcq("pos_q1", "In 'He came after me', 'after' is:", "", "Preposition", "Adverb", "Conjunction", "Adjective", 0, "Followed by pronoun object 'me' => Preposition."),
        createMcq("pos_q2", "In 'He arrived after I had left', 'after' is:", "", "Conjunction", "Preposition", "Adverb", "Noun", 0, "Connects two complete clauses => Subordinating Conjunction."),
        createMcq("pos_q3", "In 'She is a fast runner', 'fast' is:", "", "Adjective", "Adverb", "Noun", "Verb", 0, "Modifies noun 'runner' => Adjective."),
        createMcq("pos_q4", "In 'She ran fast', 'fast' is:", "", "Adverb", "Adjective", "Preposition", "Conjunction", 0, "Modifies action verb 'ran' => Adverb."),
        createMcq("pos_q5", "Which of the following words is ALWAYS an interjection?", "", "Alas", "Well", "Right", "Like", 0, "'Alas' expresses sorrow and is solely an interjection."),
        createMcq("pos_q6", "In 'Still waters run deep', 'Still' is:", "", "Adjective", "Adverb", "Noun", "Conjunction", 0, "Modifies noun 'waters' => Adjective."),
        createMcq("pos_q7", "In 'He is still waiting', 'still' is:", "", "Adverb", "Adjective", "Verb", "Preposition", 0, "Modifies verb 'waiting' => Adverb of time."),
        createMcq("pos_q8", "Identify the abstract noun: (A) Table, (B) Bravery, (C) Soldier, (D) City", "", "Bravery", "Table", "Soldier", "City", 0, "Bravery represents an intangible quality."),
        createMcq("pos_q9", "In 'Neither he nor his brother came', 'Neither...nor' is:", "", "Correlative Conjunction", "Relative Pronoun", "Adverb", "Preposition", 0, "Paired coordinating conjunction."),
        createMcq("pos_q10", "In 'The up train has arrived', 'up' is:", "", "Adjective", "Preposition", "Adverb", "Noun", 0, "Modifies noun 'train' => Adjective.")
      )
    ),
    // 2. Nouns
    FormulaTopic(
      id = "eng_nouns",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Fundamentals",
      title = "Nouns & Number Rules",
      hindiTitle = "संज्ञा एवं वचन नियम",
      summary = "Proper, common, collective, material, abstract nouns; singular/plural anomalies; uncountable nouns taking singular verbs.",
      coreFormula = "Always Singular Uncountable Nouns: Scenery, Furniture, Advice, Information, Luggage, Baggage, Hair, Poetry, Machinery, Work, Paper, Bread\nAlways Plural Nouns (Pairs): Scissors, Trousers, Tongs, Spectacles, Binoculars, Pliers, Premises, Alms, Riches, Cattle (plural in meaning)\nSingular in form, Plural in use: Cattle, Gentry, Poultry, Peasantry, Clergy, People",
      symbolExplanations = listOf(
        "Uncountable Nouns" to "Cannot take 'a/an', cannot be made plural by adding 's/es' (e.g. no 'furnitures', no 'informations').",
        "Collective Nouns" to "Takes singular verb when acting as one body; takes plural when divided in opinion."
      ),
      importantIdentities = listOf(
        "Hyphenated compound nouns do not take plural forms (e.g. 'a five-rupee note', not 'five-rupees note').",
        "Nouns plural in form but singular in meaning: Mathematics, Physics, News, Politics, Innings, Measles, Rickets."
      ),
      shortcutsAndTips = listOf(
        "To quantify uncountable nouns, use 'a piece of advice', 'an item of furniture', 'two loaves of bread'."
      ),
      commonMistakes = listOf(
        "Writing 'sceneries of Kashmir' (correct is 'scenery of Kashmir').",
        "Writing 'he gave me an advice' (correct is 'he gave me some advice' or 'a piece of advice')."
      ),
      solvedExamples = listOf(
        createExample(
          "noun_ex1",
          "Correct the sentence: 'The sceneries of Switzerland are very charming.'",
          "त्रुटि सुधारें: 'The sceneries of Switzerland are very charming.'",
          listOf(
            "Step 1: 'Scenery' is an uncountable noun and does not have a plural form 'sceneries'.",
            "Step 2: Being uncountable, it takes a singular verb 'is' rather than 'are'.",
            "Step 3: Correct sentence: 'The scenery of Switzerland is very charming.'"
          ),
          "The scenery of Switzerland is very charming.",
          "'Scenery' is always singular uncountable."
        ),
        createExample(
          "noun_ex2",
          "Correct: 'He gave me two five-hundred-rupees notes.'",
          "सुधारें: 'He gave me two five-hundred-rupees notes.'",
          listOf(
            "Step 1: 'five-hundred-rupee' is a compound adjective modifying 'notes'.",
            "Step 2: Adjectives cannot be pluralized.",
            "Step 3: Correct: 'He gave me two five-hundred-rupee notes.'"
          ),
          "two five-hundred-rupee notes",
          "Hyphenated numeral compound nouns stay singular."
        ),
        createExample(
          "noun_ex3",
          "Fill with appropriate verb: 'The committee ______ (was/were) divided in their opinions.'",
          "उपयुक्त क्रिया भरें: 'The committee ______ divided in their opinions.'",
          listOf(
            "Step 1: 'Committee' is a collective noun.",
            "Step 2: Members are divided individually in opinion (indicated by 'their opinions').",
            "Step 3: When collective noun acts as divided individuals, use plural verb 'were'."
          ),
          "were",
          "Collective noun divided in opinion takes plural verb."
        )
      ),
      practiceMcqs = listOf(
        createMcq("noun_q1", "Find error: 'All the furnitures (A) / of the house (B) / were destroyed (C) / No error (D)'", "", "(A) All the furnitures", "(B)", "(C)", "(D)", 0, "'Furniture' is uncountable; cannot be 'furnitures'."),
        createMcq("noun_q2", "'Cattle ______ grazing in the field.'", "", "are", "is", "was", "has been", 0, "'Cattle' is always treated as plural; takes 'are'."),
        createMcq("noun_q3", "Plural form of 'Commander-in-chief' is:", "", "Commanders-in-chief", "Commander-in-chiefs", "Commanders-in-chiefs", "None", 0, "Add 's' to the principal root noun: Commanders-in-chief."),
        createMcq("noun_q4", "Find error: 'Mathematics are (A) / a difficult subject (B) / for many students (C) / No error (D)'", "", "(A) Mathematics are", "(B)", "(C)", "(D)", 0, "'Mathematics' is a singular field of study; takes 'is'."),
        createMcq("noun_q5", "'His spectacles ______ missing from the desk.'", "", "are", "is", "was", "has been", 0, "Spectacles is paired noun; takes plural verb 'are'."),
        createMcq("noun_q6", "'He bought two ______ of bread from bakery.'", "", "loaves", "breads", "loafs", "pieces of breads", 0, "Plural of loaf is loaves; 'bread' cannot be pluralized."),
        createMcq("noun_q7", "Find error: 'He has packed (A) / all his luggages (B) / for the journey (C) / No error (D)'", "", "(B) all his luggages", "(A)", "(C)", "(D)", 0, "'Luggage' is uncountable; never 'luggages'."),
        createMcq("noun_q8", "'The jury ______ announced its verdict.'", "", "has", "have", "were", "are", 0, "Acting unanimously as single unit ('its verdict') => singular verb 'has'."),
        createMcq("noun_q9", "Plural of 'Radius' is:", "", "Radii", "Radiuses", "Radia", "Radi", 0, "Latin origin noun: Radius -> Radii."),
        createMcq("noun_q10", "'He gave me ______ information about the project.'", "", "a piece of", "an", "many", "a", 0, "'Information' cannot take 'an'; use 'a piece of information'.")
      )
    ),
    // 3. Pronouns
    FormulaTopic(
      id = "eng_pronouns",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Fundamentals",
      title = "Pronouns & Case Agreement",
      hindiTitle = "सर्वनाम एवं कारक नियम",
      summary = "Order of personal pronouns (231 rule for good deeds, 123 for mistakes), subjective vs objective case, relative pronouns.",
      coreFormula = "Order of Personal Pronouns:\nGood Deeds: Second (2) -> Third (3) -> First (1) [You, he, and I]\nConfessions / Negative / Plural: First (1) -> Second (2) -> Third (3) [I, you, and he]\nBetween / Let / But / Except + OBJECTIVE Case (me, him, her, them, us)",
      symbolExplanations = listOf(
        "Subjective Case" to "I, we, you, he, she, it, they (used as subject of verb).",
        "Objective Case" to "Me, us, you, him, her, it, them (used after verbs and prepositions).",
        "Possessive Pronoun" to "Mine, ours, yours, his, hers, theirs (no apostrophe!)."
      ),
      importantIdentities = listOf(
        "It's = It is | Its = Possessive pronoun (no apostrophe).",
        "'Who' acts as subject of verb; 'Whom' acts as object.",
        "After superlative adjectives and words like 'all', 'any', 'none', 'only', use relative pronoun 'that'."
      ),
      shortcutsAndTips = listOf(
        "Substitute 'he/they' for who, and 'him/them' for whom to check case correctness."
      ),
      commonMistakes = listOf(
        "Writing 'between you and I' (correct is 'between you and me' because between is a preposition)."
      ),
      solvedExamples = listOf(
        createExample(
          "pro_ex1",
          "Correct: 'Between you and I, he is a liar.'",
          "सुधारें: 'Between you and I, he is a liar.'",
          listOf(
            "Step 1: 'Between' is a preposition.",
            "Step 2: Prepositions are followed by the OBJECTIVE case of pronouns.",
            "Step 3: Objective case of 'I' is 'me'.",
            "Step 4: Correct sentence: 'Between you and me, he is a liar.'"
          ),
          "Between you and me",
          "Preposition takes objective case."
        ),
        createExample(
          "pro_ex2",
          "Arrange pronouns: 'I, you, and he helped the injured passengers.'",
          "व्यवस्थित करें: 'I, you, and he helped the injured passengers.'",
          listOf(
            "Step 1: Helping passengers is a praiseworthy action.",
            "Step 2: Use the 2-3-1 rule (Second -> Third -> First).",
            "Step 3: Second: You; Third: he; First: I.",
            "Step 4: Result: 'You, he, and I helped the injured passengers.'"
          ),
          "You, he, and I",
          "Rule 231 for good acts."
        ),
        createExample(
          "pro_ex3",
          "Fill with who/whom: 'He is the candidate ______ we believe will win the election.'",
          "भरें: 'He is the candidate ______ we believe will win the election.'",
          listOf(
            "Step 1: Remove parenthetical clause 'we believe'.",
            "Step 2: Remaining sentence: 'He is the candidate [who/whom] will win the election.'",
            "Step 3: Pronoun is subject of verb 'will win'.",
            "Step 4: Therefore, use subjective case 'who'."
          ),
          "who",
          "Subject of 'will win'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("pro_q1", "Let ______ do the work.", "", "him and me", "he and I", "him and I", "he and me", 0, "'Let' is followed by objective case pronouns: him and me."),
        createMcq("pro_q2", "Arrange for confession of crime: 'You, he and I committed the robbery.'", "", "I, you and he", "You, he and I", "He, you and I", "I, he and you", 0, "Confession of mistake uses 123 rule: I, you and he."),
        createMcq("pro_q3", "'This is the best movie ______ I have ever seen.'", "", "that", "which", "who", "whom", 0, "After superlative degree 'best', use 'that'."),
        createMcq("pro_q4", "Find error: 'Each of the boys (A) / have brought (B) / their books (C) / No error (D)'", "", "(B) have brought", "(A)", "(C)", "(D)", 0, "'Each' is singular, requires 'has brought his book'."),
        createMcq("pro_q5", "'One must respect ______ elders.'", "", "one's", "his", "their", "her", 0, "Pronoun 'one' must be maintained consistently with 'one's'."),
        createMcq("pro_q6", "'Neither of the two sisters came, ______?'", "", "did they", "didn't they", "did she", "didn't she", 0, "Neither is negative; tag must be affirmative plural: 'did they?'."),
        createMcq("pro_q7", "It was ______ who knocked at the door.", "", "he", "him", "his", "himself", 0, "After 'It is/was', use subjective case: 'It was he'."),
        createMcq("pro_q8", "'Nobody but ______ attended the lecture.'", "", "him", "he", "his", "himself", 0, "'But' as preposition meaning 'except' takes objective case 'him'."),
        createMcq("pro_q9", "'Everyone should do ______ duty.'", "", "his", "their", "one's", "her", 0, "Singular masculine 'his' is standard indefinite singular pronoun agreement."),
        createMcq("pro_q10", "'The dog wagged ______ tail.'", "", "its", "it's", "it", "his", 0, "Possessive form of it is 'its' (no apostrophe).")
      )
    ),
    // 4. Verbs
    FormulaTopic(
      id = "eng_verbs",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Fundamentals",
      title = "Verbs: Finite, Non-Finite & Causatives",
      hindiTitle = "क्रिया एवं प्रेरक क्रियाएं",
      summary = "Transitive vs intransitive, gerunds, infinitives, bare infinitives, participles, and causative verbs.",
      coreFormula = "Infinitive: to + V1\nBare Infinitive (Without 'to'): Used after Let, Make, Bid, Watch, Hear, See, Need not, Dare not, Had better, Would rather\nGerund (V1 + ing as noun): Followed after Look forward to, Accustomed to, With a view to, Addicted to\nCausative Verbs:\nMake + Person + V1 (bare)\nGet + Person + to V1 | Get + Thing + V3",
      symbolExplanations = listOf(
        "Bare Infinitive" to "Base verb without 'to' (e.g. 'She made him cry').",
        "Gerund" to "Verb functioning as a noun taking '-ing'."
      ),
      importantIdentities = listOf(
        "Had better / Would rather + Bare Infinitive ('You had better go now')."
      ),
      shortcutsAndTips = listOf(
        "Phrasal combinations ending with 'to' that take gerund: 'looking forward to hearing', 'with a view to purchasing'."
      ),
      commonMistakes = listOf(
        "Using 'to + V1' after causative 'make' in active voice ('She made me to do it' is incorrect; correct is 'She made me do it')."
      ),
      solvedExamples = listOf(
        createExample(
          "verb_ex1",
          "Correct: 'I am looking forward to meet you.'",
          "सुधारें: 'I am looking forward to meet you.'",
          listOf(
            "Step 1: 'Looking forward to' is a fixed idiom where 'to' is a preposition.",
            "Step 2: A preposition must be followed by a noun or gerund (V1 + ing).",
            "Step 3: Correct sentence: 'I am looking forward to meeting you.'"
          ),
          "looking forward to meeting you",
          "Gerund follows 'looking forward to'."
        ),
        createExample(
          "verb_ex2",
          "Correct: 'She made me to laugh.'",
          "सुधारें: 'She made me to laugh.'",
          listOf(
            "Step 1: 'Make' is a causative verb in active voice.",
            "Step 2: Causative 'make' takes a bare infinitive (without 'to').",
            "Step 3: Correct sentence: 'She made me laugh.'"
          ),
          "She made me laugh.",
          "Bare infinitive after 'make'."
        ),
        createExample(
          "verb_ex3",
          "Fill: 'You had better ______ (consult/to consult) a doctor immediately.'",
          "भरें: 'You had better ______ a doctor immediately.'",
          listOf(
            "Step 1: 'Had better' expresses strong advice.",
            "Step 2: 'Had better' is always followed by a bare infinitive.",
            "Step 3: Correct form: 'consult'."
          ),
          "consult",
          "Bare infinitive after 'had better'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("verb_q1", "'He is addicted to ______ gambling.'", "", "gambling", "gamble", "to gamble", "gambled", 0, "'Addicted to' takes a gerund (-ing form)."),
        createMcq("verb_q2", "'You need not ______ there.'", "", "go", "to go", "going", "went", 0, "'Need not' as modal takes bare infinitive 'go'."),
        createMcq("verb_q3", "'I saw him ______ the bridge.'", "", "cross", "to cross", "crossed", "crosses", 0, "Verb of perception 'see' takes bare infinitive or participle."),
        createMcq("verb_q4", "'He got his car ______.'", "", "repaired", "repair", "to repair", "repairing", 0, "Causative 'get' + object + past participle (V3): 'got his car repaired'."),
        createMcq("verb_q5", "'I would rather starve than ______.'", "", "beg", "to beg", "begging", "begged", 0, "'Would rather... than' takes bare infinitive on both sides."),
        createMcq("verb_q6", "'With a view to ______ his knowledge, he joined the library.'", "", "enhancing", "enhance", "enhanced", "to enhance", 0, "'With a view to' takes gerund: enhancing."),
        createMcq("verb_q7", "Passive of 'She made him laugh' is:", "", "He was made to laugh by her.", "He was made laugh.", "He is made laugh.", "None", 0, "In passive voice, causative 'make' takes full infinitive 'to laugh'."),
        createMcq("verb_q8", "'Stop ______ so much noise.'", "", "making", "to make", "make", "made", 0, "Stop + gerund means ceasing the activity: making."),
        createMcq("verb_q9", "'He was accused of ______ money.'", "", "stealing", "steal", "to steal", "stolen", 0, "Preposition 'of' takes gerund: stealing."),
        createMcq("verb_q10", "'She let me ______ her car.'", "", "drive", "to drive", "driving", "drove", 0, "'Let' always takes bare infinitive 'drive'.")
      )
    ),
    // 5. Adjectives
    FormulaTopic(
      id = "eng_adjectives",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Fundamentals",
      title = "Adjectives & Comparison Rules",
      hindiTitle = "विशेषण एवं तुलना नियम",
      summary = "Order of adjectives (OSASCOMP), Latin comparatives ending in -ior, preferable, elder vs older, little vs few.",
      coreFormula = "Order of Adjectives: OSASCOMP\nOpinion -> Size -> Age -> Shape -> Color -> Origin -> Material -> Purpose\nLatin Comparatives in -ior: Prior, Junior, Senior, Superior, Inferior + TO (NEVER 'than')\nPreferable: Takes 'TO' (NEVER 'more preferable than')\nLittle (quantity): Little (negligible), A little (some), The little (all that is left)\nFew (number): Few (negligible), A few (some), The few (all that there are)",
      symbolExplanations = listOf(
        "Elder/Eldest" to "Used strictly for family members; never followed by 'than'.",
        "Older/Oldest" to "Used for persons or things; followed by 'than'."
      ),
      importantIdentities = listOf(
        "Non-comparable absolute adjectives cannot take 'more/most': Unique, Perfect, Universal, Complete, Dead, Supreme."
      ),
      shortcutsAndTips = listOf(
        "Remember Latin: Junior TO, Senior TO, Superior TO."
      ),
      commonMistakes = listOf(
        "Writing 'He is senior than me' (correct is 'senior to me').",
        "Writing 'Milk is more preferable than tea' (correct is 'Milk is preferable to tea')."
      ),
      solvedExamples = listOf(
        createExample(
          "adj_ex1",
          "Correct: 'He is senior than me in service.'",
          "सुधारें: 'He is senior than me in service.'",
          listOf(
            "Step 1: 'Senior' is a Latin comparative adjective ending in '-ior'.",
            "Step 2: Latin comparatives are always followed by the preposition 'to', never 'than'.",
            "Step 3: Correct sentence: 'He is senior to me in service.'"
          ),
          "senior to me",
          "Latin adjectives take 'to'."
        ),
        createExample(
          "adj_ex2",
          "Correct: 'This painting is more unique than that one.'",
          "सुधारें: 'This painting is more unique than that one.'",
          listOf(
            "Step 1: 'Unique' means one of a kind (absolute adjective).",
            "Step 2: Absolute adjectives cannot have comparative degrees (no 'more unique').",
            "Step 3: Correct sentence: 'This painting is unique' or 'different from that one.'"
          ),
          "is unique (cannot take 'more')",
          "Unique cannot be qualified by 'more'."
        ),
        createExample(
          "adj_ex3",
          "Fill: 'There is ______ (little/a little) hope of his recovery; his condition is critical.'",
          "भरें: 'There is ______ hope of his recovery; his condition is critical.'",
          listOf(
            "Step 1: Condition is critical, meaning chances of survival are negligible.",
            "Step 2: 'Little' carries negative meaning (hardly any).",
            "Step 3: Therefore, use 'little'."
          ),
          "little",
          "'Little' = almost none."
        )
      ),
      practiceMcqs = listOf(
        createMcq("adj_q1", "Coffee is preferable ______ tea.", "", "to", "than", "more than", "over", 0, "'Preferable' is always followed by preposition 'to'."),
        createMcq("adj_q2", "My brother is elder ______ me by two years.", "", "to", "than", "from", "of", 0, "'Elder' takes 'to', not 'than'."),
        createMcq("adj_q3", "Find error: 'He is the most supreme (A) / leader of (B) / our nation (C) / No error (D)'", "", "(A) the most supreme", "(B)", "(C)", "(D)", 0, "'Supreme' is absolute; cannot take 'most'."),
        createMcq("adj_q4", "'He drank ______ water that was in the jug.'", "", "the little", "little", "a little", "few", 0, "'The little' means all that was present."),
        createMcq("adj_q5", "'Only ______ students passed the difficult exam.'", "", "a few", "few", "little", "a little", 0, "'A few' denotes small positive count of countable nouns."),
        createMcq("adj_q6", "Arrange: 'leather / beautiful / brown / jacket'", "", "beautiful brown leather jacket", "brown beautiful leather jacket", "leather brown beautiful jacket", "beautiful leather brown jacket", 0, "Opinion -> Color -> Material."),
        createMcq("adj_q7", "Which sentence is correct?", "", "He is superior to all competitors.", "He is superior than all competitors.", "He is more superior.", "None", 0, "'Superior' takes 'to'."),
        createMcq("adj_q8", "Comparative degree of 'bad' is:", "", "Worse", "Badder", "Worst", "More bad", 0, "Bad -> Worse -> Worst."),
        createMcq("adj_q9", "Find error: 'This is the most perfect (A) / solution to (B) / the crisis (C) / No error (D)'", "", "(A) the most perfect", "(B)", "(C)", "(D)", 0, "'Perfect' is absolute; cannot be modified by 'most'."),
        createMcq("adj_q10", "'Of the two sisters, Sunita is ______.'", "", "the smarter", "smarter", "the smartest", "smartest", 0, "When choosing between two, use 'the + comparative degree': 'the smarter'.")
      )
    ),
    // 6. Adverbs
    FormulaTopic(
      id = "eng_adverbs",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Fundamentals",
      title = "Adverbs & Inversion",
      hindiTitle = "क्रियाविशेषण एवं व्युत्क्रम",
      summary = "Adverbs of manner, place, time (MPT rule), negative adverbs triggering inversion, too...to, so...that, and enough.",
      coreFormula = "Order of Adverbs: Manner (How) -> Place (Where) -> Time (When) [MPT Rule]\nInversion with Negative Adverbs:\nHardly / Scarcely / Seldom / Never / Barely / Little + Auxiliary Verb + Subject\nExample: 'Hardly had he arrived when the bell rang'\nEnough Position: Adjective/Adverb + Enough",
      symbolExplanations = listOf(
        "Inversion" to "Placing auxiliary verb before subject for emphasis."
      ),
      importantIdentities = listOf(
        "Hardly / Scarcely is paired with WHEN.",
        "No sooner is paired with THAN.",
        "'Too... to' has negative implication (too weak to walk = so weak that he cannot walk)."
      ),
      shortcutsAndTips = listOf(
        "If a sentence begins with Seldom, Never, Hardly, No sooner, immediately check for inversion (Verb before Subject)."
      ),
      commonMistakes = listOf(
        "Writing 'No sooner did he arrive WHEN...' (correct pair is 'No sooner... THAN').",
        "Writing 'He is enough rich' (correct is 'rich enough')."
      ),
      solvedExamples = listOf(
        createExample(
          "adv_ex1",
          "Correct: 'No sooner had I reached the station when the train left.'",
          "सुधारें: 'No sooner had I reached the station when the train left.'",
          listOf(
            "Step 1: 'No sooner' is a comparative adverb correlative.",
            "Step 2: Comparative degree must be followed by 'than', never 'when'.",
            "Step 3: Correct sentence: 'No sooner had I reached the station THAN the train left.'"
          ),
          "No sooner ... than",
          "'No sooner' pairs with 'than'."
        ),
        createExample(
          "adv_ex2",
          "Correct: 'He is enough intelligent to solve this puzzle.'",
          "सुधारें: 'He is enough intelligent to solve this puzzle.'",
          listOf(
            "Step 1: 'Enough' when functioning as an adverb modifies the adjective 'intelligent'.",
            "Step 2: The adverb 'enough' must always follow the adjective it modifies.",
            "Step 3: Correct sentence: 'He is intelligent enough to solve this puzzle.'"
          ),
          "intelligent enough",
          "Adjective precedes 'enough'."
        ),
        createExample(
          "adv_ex3",
          "Correct: 'Seldom I have seen such a breathtaking sight.'",
          "सुधारें: 'Seldom I have seen such a breathtaking sight.'",
          listOf(
            "Step 1: Sentence starts with negative adverb 'Seldom'.",
            "Step 2: Negative adverbs at the beginning require subject-verb INVERSION.",
            "Step 3: Place auxiliary 'have' before subject 'I'.",
            "Step 4: Correct sentence: 'Seldom have I seen such a breathtaking sight.'"
          ),
          "Seldom have I seen",
          "Negative adverb requires inversion."
        )
      ),
      practiceMcqs = listOf(
        createMcq("adv_q1", "'Hardly had he entered the room ______ the lights went out.'", "", "when", "than", "then", "that", 0, "'Hardly' is strictly paired with 'when'."),
        createMcq("adv_q2", "'She sang ______ at the concert last night.'", "", "beautifully", "beautiful", "beauty", "more beautiful", 0, "Modifies verb 'sang' => Adverb of manner 'beautifully'."),
        createMcq("adv_q3", "'He was ______ tired to walk any further.'", "", "too", "so", "very", "much", 0, "'Too... to' expresses negative consequence."),
        createMcq("adv_q4", "Position of MPT: 'He danced last night gracefully on stage.' Correct order:", "", "gracefully on stage last night", "on stage gracefully last night", "last night gracefully on stage", "None", 0, "Manner -> Place -> Time."),
        createMcq("adv_q5", "'No sooner did the bell ring ______ the students left.'", "", "than", "when", "then", "after", 0, "'No sooner' takes 'than'."),
        createMcq("adv_q6", "'He speaks English ______.'", "", "well", "good", "best", "fluent", 0, "'Well' is adverb; 'good' is adjective."),
        createMcq("adv_q7", "Find error: 'Scarcely had she bought (A) / the ticket (B) / than the bus arrived (C) / No error (D)'", "", "(C) than the bus arrived", "(A)", "(B)", "(D)", 0, "'Scarcely' pairs with 'when', not 'than'."),
        createMcq("adv_q8", "'He is ______ weak that he cannot stand.'", "", "so", "too", "very", "much", 0, "'So... that' pairs with full subordinate clause."),
        createMcq("adv_q9", "'Little ______ know about the danger ahead.'", "", "did they", "they did", "they", "had they", 0, "Inversion after negative adverb 'Little': 'did they'."),
        createMcq("adv_q10", "'She is talented ______ to win the scholarship.'", "", "enough", "too", "very", "much", 0, "Adjective + enough: talented enough.")
      )
    ),
    // 7. Articles
    FormulaTopic(
      id = "eng_articles",
      subject = FormulaSubject.ENGLISH,
      chapter = "Determiners & Articles",
      title = "Articles (A, An, The)",
      hindiTitle = "उपपद (A, An, The)",
      summary = "Indefinite articles based on vowel sound, definite article 'the', omission of articles.",
      coreFormula = "Indefinite 'An': Used before VOWEL SOUND (स्वर ध्वनि)\nExamples with 'An': An honest man, An hour, An heir, An MLA, An FIR, An MBA, An umbrella\nExamples with 'A': A European (Yu-sound), A university, A unique gift, A one-rupee note\nDefinite 'The': Unique celestial bodies, rivers, oceans, mountain ranges, musical instruments, superlative degrees",
      symbolExplanations = listOf(
        "Sound Rule" to "Choice between 'a' and 'an' depends on phonetic pronunciation sound, NOT spelling letter."
      ),
      importantIdentities = listOf(
        "No article before names of languages, meals, sports, proper nouns.",
        "Omission before School, College, Church, Hospital, Temple, Prison when visited for their primary purpose."
      ),
      shortcutsAndTips = listOf(
        "Speak the word in Hindi: If first phoneme is a Hindi vowel (अ, आ, इ, ई...), use 'an'. If consonant, use 'a'."
      ),
      commonMistakes = listOf(
        "Using 'an' before 'European' or 'University' (these start with consonant 'y' sound)."
      ),
      solvedExamples = listOf(
        createExample(
          "art_ex1",
          "Fill with suitable article: 'He is ______ European citizen.'",
          "भरें: 'He is ______ European citizen.'",
          listOf(
            "Step 1: Phonetic sound of 'European' is /jʊərəˈpiːən/ (starts with 'y' / 'य' consonant sound).",
            "Step 2: Words beginning with consonant sound take indefinite article 'a'.",
            "Step 3: Correct: 'He is a European citizen.'"
          ),
          "a",
          "Consonant 'y' sound."
        ),
        createExample(
          "art_ex2",
          "Fill with article: 'He filed ______ FIR against the miscreants.'",
          "भरें: 'He filed ______ FIR against the miscreants.'",
          listOf(
            "Step 1: Pronounce abbreviation 'FIR': starts with 'ef' (vowel sound /e/ / 'ए').",
            "Step 2: Since it begins with a vowel sound, it takes 'an'.",
            "Step 3: Correct: 'He filed an FIR.'"
          ),
          "an",
          "Vowel phoneme /e/."
        ),
        createExample(
          "art_ex3",
          "Correct: 'The patient was admitted in the hospital.'",
          "सुधारें: 'The patient was admitted in the hospital.'",
          listOf(
            "Step 1: The patient went to hospital for primary purpose of medical treatment.",
            "Step 2: No article is used before hospital when visited for primary purpose.",
            "Step 3: Correct sentence: 'The patient was admitted in hospital.'"
          ),
          "in hospital (omission of 'the')",
          "Zero article for primary purpose."
        )
      ),
      practiceMcqs = listOf(
        createMcq("art_q1", "'He bought ______ one-rupee note from the collector.'", "", "a", "an", "the", "no article", 0, "'One' begins with consonant 'w' sound; takes 'a'."),
        createMcq("art_q2", "'She is ______ honest police officer.'", "", "an", "a", "the", "no article", 0, "'Honest' has silent 'h', starts with vowel sound 'o'; takes 'an'."),
        createMcq("art_q3", "'______ Ganga is a sacred river.'", "", "The", "A", "An", "No article", 0, "Names of holy rivers take definite article 'The'."),
        createMcq("art_q4", "'Kalidasa is ______ Shakespeare of India.'", "", "the", "a", "an", "no article", 0, "Proper noun used as benchmark takes 'the'."),
        createMcq("art_q5", "'He plays ______ guitar very well.'", "", "the", "a", "an", "no article", 0, "Musical instruments take definite article 'the'."),
        createMcq("art_q6", "'He has been studying in ______ university since 2021.'", "", "a", "an", "the", "no article", 0, "'University' begins with 'yu' consonant sound; takes 'a'."),
        createMcq("art_q7", "'I have ______ headache today.'", "", "a", "an", "the", "no article", 0, "Idiomatic health ailment: 'have a headache'."),
        createMcq("art_q8", "'______ Mount Everest is highest peak.'", "", "No article", "The", "A", "An", 0, "Individual peaks do NOT take 'the'; mountain ranges do."),
        createMcq("art_q9", "'He is ______ MLA from this constituency.'", "", "an", "a", "the", "no article", 0, "MLA begins with vowel phoneme 'em'; takes 'an'."),
        createMcq("art_q10", "'______ richer he gets, ______ more charitable he becomes.'", "", "The, the", "A, a", "The, a", "A, the", 0, "Parallel comparative structure takes 'The..., the...'")
      )
    ),
    // 8. Determiners
    FormulaTopic(
      id = "eng_determiners",
      subject = FormulaSubject.ENGLISH,
      chapter = "Determiners & Articles",
      title = "Determiners & Quantifiers",
      hindiTitle = "निर्धारक एवं परिमाणवाचक",
      summary = "Much vs Many, Some vs Any, Each vs Every, Either vs Neither, Little vs Few.",
      coreFormula = "Quantifier Rules:\nMuch: Used with UNCOUNTABLE nouns (quantity)\nMany: Used with PLURAL COUNTABLE nouns (number)\nSome: Used in AFFIRMATIVE sentences and polite requests\nAny: Used in NEGATIVE and INTERROGATIVE sentences\nEach: Individual focus, used for 2 or more entities\nEvery: Group focus, used strictly for 3 or more entities",
      symbolExplanations = listOf(
        "Each" to "Can be pronoun or adjective; applies to groups of two or more.",
        "Every" to "Only an adjective; applies strictly to groups of more than two."
      ),
      importantIdentities = listOf(
        "Either of / Neither of is followed by Plural Noun but SINGULAR Verb (e.g. 'Neither of the boys is guilty')."
      ),
      shortcutsAndTips = listOf(
        "In questions expecting a 'Yes' answer (offers/requests), use 'some' instead of 'any'."
      ),
      commonMistakes = listOf(
        "Using 'much' with countable plural items (e.g. 'much books' is incorrect; must be 'many books')."
      ),
      solvedExamples = listOf(
        createExample(
          "det_ex1",
          "Fill: 'I do not have ______ (some/any) money left in my wallet.'",
          "भरें: 'I do not have ______ money left in my wallet.'",
          listOf(
            "Step 1: Sentence contains negative marker 'not'.",
            "Step 2: Negative sentences use 'any' rather than 'some'.",
            "Step 3: Correct word is 'any'."
          ),
          "any",
          "'Any' in negative sentences."
        ),
        createExample(
          "det_ex2",
          "Fill: '______ (Each/Every) of the two candidates was interviewed.'",
          "भरें: '______ of the two candidates was interviewed.'",
          listOf(
            "Step 1: The total number is exactly two.",
            "Step 2: 'Every' cannot be used for two; only 'Each' can refer to two.",
            "Step 3: Correct word is 'Each'."
          ),
          "Each",
          "'Each' refers to two; 'Each of' is grammatically valid."
        ),
        createExample(
          "det_ex3",
          "Fill: 'There are ______ (many/much) people at the rally.'",
          "भरें: 'There are ______ people at the rally.'",
          listOf(
            "Step 1: 'People' is a plural countable noun.",
            "Step 2: Countable plural nouns take 'many', not 'much'.",
            "Step 3: Correct word: 'many'."
          ),
          "many",
          "Countable plural takes 'many'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("det_q1", "'Would you like ______ coffee?'", "", "some", "any", "much", "many", 0, "Polite offer expecting 'yes' takes 'some'."),
        createMcq("det_q2", "'Neither of the accusations ______ true.'", "", "is", "are", "were", "have been", 0, "'Neither of' takes singular verb 'is'."),
        createMcq("det_q3", "'How ______ milk is left in the container?'", "", "much", "many", "few", "a few", 0, "'Milk' is uncountable; takes 'much'."),
        createMcq("det_q4", "'She gave ______ student a certificate.'", "", "each", "every of", "either", "any of", 0, "Distributive adjective modifying singular noun."),
        createMcq("det_q5", "'Is there ______ water in the glass?'", "", "any", "some", "many", "few", 0, "Interrogative question takes 'any'."),
        createMcq("det_q6", "'He has ______ friends in the city because he is new.'", "", "few", "a few", "little", "much", 0, "'Few' carries negative meaning (hardly any friends)."),
        createMcq("det_q7", "'______ seat in the auditorium was occupied.'", "", "Every", "All", "Many", "Both", 0, "'Every' modifies singular noun 'seat'."),
        createMcq("det_q8", "'Both sisters are intelligent, but ______ is ambitious.'", "", "neither", "none", "no one", "not", 0, "For exactly two persons, use 'neither'."),
        createMcq("det_q9", "'He spends ______ time practicing guitar.'", "", "a lot of", "many", "few", "a few", 0, "'Time' is uncountable; 'a lot of' is correct."),
        createMcq("det_q10", "'______ of the three applicants got the job.'", "", "None", "Neither", "Each other", "No", 0, "For more than two, use 'none'.")
      )
    ),
    // 9. Tenses
    FormulaTopic(
      id = "eng_tenses",
      subject = FormulaSubject.ENGLISH,
      chapter = "Verb Structures",
      title = "Tenses & Time Aspects",
      hindiTitle = "काल एवं समय पहलू",
      summary = "Present, Past, Future structures, time markers (since/for), conditional clauses, and past perfect with before/after.",
      coreFormula = "Present Perfect: has/have + V3 (markers: already, yet, just, so far)\nPresent Perfect Continuous: has/have + been + V1-ing + since/for\nPast Perfect with Two Events:\n1st Event (Earlier): had + V3\n2nd Event (Later): Simple Past (V2)\nSince = Specific point of time (since 2010, since morning)\nFor = Duration of time (for 3 years, for 2 hours)",
      symbolExplanations = listOf(
        "Since" to "Exact starting point of uninterrupted action.",
        "For" to "Total elapsed duration of time."
      ),
      importantIdentities = listOf(
        "Universal truths / scientific laws stay in Simple Present tense, even if introduced by a past reporting verb."
      ),
      shortcutsAndTips = listOf(
        "The patient had died before the doctor came (Earlier event gets 'had + V3')."
      ),
      commonMistakes = listOf(
        "Using Present Continuous for stative verbs: 'I am knowing him' (wrong! Correct: 'I know him')."
      ),
      solvedExamples = listOf(
        createExample(
          "ten_ex1",
          "Correct: 'The patient died before the doctor arrived.'",
          "सुधारें: 'The patient died before the doctor arrived.'",
          listOf(
            "Step 1: Two past actions occurred sequentially.",
            "Step 2: Patient's death happened first; doctor's arrival happened second.",
            "Step 3: The earlier action must be in Past Perfect (had + V3).",
            "Step 4: Correct: 'The patient had died before the doctor arrived.'"
          ),
          "had died before the doctor arrived",
          "Earlier action takes Past Perfect."
        ),
        createExample(
          "ten_ex2",
          "Correct: 'He is living in this city since 2015.'",
          "सुधारें: 'He is living in this city since 2015.'",
          listOf(
            "Step 1: Action started in the past (2015) and is still continuing in present.",
            "Step 2: Ongoing past action with 'since/for' requires Present Perfect Continuous.",
            "Step 3: Correct sentence: 'He has been living in this city since 2015.'"
          ),
          "has been living",
          "'Since' requires Perfect Continuous."
        ),
        createExample(
          "ten_ex3",
          "Fill: 'She ______ (read) when the telephone rang.'",
          "भरें: 'She ______ when the telephone rang.'",
          listOf(
            "Step 1: An ongoing background action was interrupted by a past point event.",
            "Step 2: Ongoing background past action takes Past Continuous (was/were + V1-ing).",
            "Step 3: Correct: 'She was reading when the telephone rang.'"
          ),
          "was reading",
          "Past continuous interrupted by simple past."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ten_q1", "'He ______ here for the last five years.'", "", "has been working", "is working", "works", "worked", 0, "Duration 'for the last five years' requires Present Perfect Continuous."),
        createMcq("ten_q2", "'The train ______ before we reached the platform.'", "", "had left", "left", "has left", "leaves", 0, "Earlier past event takes Past Perfect: had left."),
        createMcq("ten_q3", "'Water ______ at 100 degrees Celsius.'", "", "boils", "is boiling", "has boiled", "boiled", 0, "Scientific fact takes Simple Present: boils."),
        createMcq("ten_q4", "'I ______ him since we graduated.'", "", "have not seen", "did not see", "do not see", "am not seeing", 0, "Action from past point until now takes Present Perfect: have not seen."),
        createMcq("ten_q5", "'By next December, she ______ her degree.'", "", "will have completed", "will complete", "completes", "completed", 0, "Future deadline requires Future Perfect: will have completed."),
        createMcq("ten_q6", "'I ______ a letter when he entered.'", "", "was writing", "wrote", "am writing", "had written", 0, "Past continuous for interrupted action: was writing."),
        createMcq("ten_q7", "Find error: 'I am knowing (A) / him (B) / very well (C) / No error (D)'", "", "(A) I am knowing", "(B)", "(C)", "(D)", 0, "Stative verb 'know' cannot be used in continuous tense; correct is 'I know'."),
        createMcq("ten_q8", "'If it rains, we ______ the match.'", "", "will cancel", "would cancel", "cancelled", "cancel", 0, "First conditional: If + Present, Future Simple."),
        createMcq("ten_q9", "'He went to bed after he ______ his dinner.'", "", "had eaten", "ate", "has eaten", "was eating", 0, "Eating dinner happened before going to bed => Past Perfect: had eaten."),
        createMcq("ten_q10", "'She ______ French for two hours every day.'", "", "practices", "is practicing", "has practiced", "practiced", 0, "Habitual regular routine takes Simple Present: practices.")
      )
    ),
    // 10. Subject-Verb Agreement
    FormulaTopic(
      id = "eng_subject_verb_agreement",
      subject = FormulaSubject.ENGLISH,
      chapter = "Syntax & Concord",
      title = "Subject-Verb Agreement",
      hindiTitle = "कर्ता-क्रिया सामंजस्य",
      summary = "Proximity rule (either/or, neither/nor), parenthetical connectors (as well as, along with), and collective nouns.",
      coreFormula = "Rule 1: Proximity Rule (Either...or, Neither...nor, Not only...but also): Verb agrees with CLOSEST subject\nRule 2: Parenthetical Rule (As well as, along with, together with, in addition to, accompanied by): Verb agrees with FIRST subject\nRule 3: 'A number of' + Plural Verb | 'The number of' + SINGULAR Verb\nRule 4: Singular quantities expressing unified distance/time/money: Takes SINGULAR verb",
      symbolExplanations = listOf(
        "First Subject Rule" to "Parenthetical additions do not alter the number of the original grammatical subject.",
        "Proximity Rule" to "Nearest noun dictates the singular or plural inflection."
      ),
      importantIdentities = listOf(
        "'Ten thousand rupees is a big amount' (unified sum -> singular).",
        "'Ten kilometers is a long distance to walk' (unified measurement -> singular)."
      ),
      shortcutsAndTips = listOf(
        "Cross out everything between commas or parenthetical phrases (with, along with, as well as) to see real subject."
      ),
      commonMistakes = listOf(
        "Letting verb agree with parenthetical addition: 'The captain along with his players were present' (wrong! Captain is singular, so WAS present)."
      ),
      solvedExamples = listOf(
        createExample(
          "sva_ex1",
          "Correct: 'The captain, along with all his players, were felicitated.'",
          "सुधारें: 'The captain, along with all his players, were felicitated.'",
          listOf(
            "Step 1: Subject joined by 'along with' agrees with the FIRST subject.",
            "Step 2: First subject is 'The captain' (singular).",
            "Step 3: Therefore, the verb must be singular 'was'.",
            "Step 4: Correct sentence: 'The captain, along with all his players, was felicitated.'"
          ),
          "was felicitated",
          "Agrees with first subject 'captain'."
        ),
        createExample(
          "sva_ex2",
          "Fill: 'Either the teacher or the students ______ (is/are) responsible.'",
          "भरें: 'Either the teacher or the students ______ responsible.'",
          listOf(
            "Step 1: 'Either... or' follows the rule of proximity (agrees with nearest subject).",
            "Step 2: Nearest subject to the verb is 'the students' (plural).",
            "Step 3: Plural subject requires plural verb 'are'.",
            "Step 4: Correct: 'Either the teacher or the students are responsible.'"
          ),
          "are",
          "Agrees with nearest subject 'students'."
        ),
        createExample(
          "sva_ex3",
          "Fill: 'The number of students in the auditorium ______ (is/are) sixty.'",
          "भरें: 'The number of students in the auditorium ______ sixty.'",
          listOf(
            "Step 1: 'The number of' refers to a specific singular numerical figure.",
            "Step 2: It always takes a SINGULAR verb.",
            "Step 3: Correct form: 'is'."
          ),
          "is",
          "'The number of' takes singular verb."
        )
      ),
      practiceMcqs = listOf(
        createMcq("sva_q1", "'Neither praise nor blame ______ to affect him.'", "", "seems", "seem", "are seeming", "have seemed", 0, "Proximity rule: 'blame' is singular uncountable => seems."),
        createMcq("sva_q2", "'Bread and butter ______ his favourite breakfast.'", "", "is", "are", "were", "have been", 0, "Two nouns expressing single unified idea take singular verb 'is'."),
        createMcq("sva_q3", "'A number of students ______ absent today.'", "", "are", "is", "was", "has been", 0, "'A number of' takes plural verb: are."),
        createMcq("sva_q4", "'Five thousand rupees ______ too much for this bag.'", "", "is", "are", "were", "have been", 0, "Specific sum of money regarded as a unit takes singular verb 'is'."),
        createMcq("sva_q5", "'The minister, accompanied by his secretaries, ______ arrived.'", "", "has", "have", "are", "were", 0, "Agrees with first subject 'The minister' => has."),
        createMcq("sva_q6", "'Not only the teacher but also the students ______ enthusiastic.'", "", "were", "was", "is", "has been", 0, "Proximity with 'students' (plural) => were."),
        createMcq("sva_q7", "'Many a man ______ tempted by greed.'", "", "has been", "have been", "are", "were", 0, "'Many a' is followed by singular noun and SINGULAR verb: has been."),
        createMcq("sva_q8", "'Slow and steady ______ the race.'", "", "wins", "win", "are winning", "have won", 0, "Compound subject expressing single motto takes singular verb 'wins'."),
        createMcq("sva_q9", "'Two miles ______ not a long distance.'", "", "is", "are", "were", "have been", 0, "Definite unit of distance takes singular verb 'is'."),
        createMcq("sva_q10", "'One of my friends ______ a doctor.'", "", "is", "are", "were", "have been", 0, "Subject is 'One' (singular) => is.")
      )
    ),
    // 11. Prepositions
    FormulaTopic(
      id = "eng_prepositions",
      subject = FormulaSubject.ENGLISH,
      chapter = "Syntax & Concord",
      title = "Prepositions & Fixed Usages",
      hindiTitle = "संबंधबोधक अव्यय",
      summary = "Time prepositions (at, on, in), place/direction, between vs among, beside vs besides, and fixed prepositions.",
      coreFormula = "Time Hierarchy: At (exact time) -> On (days & dates) -> In (months, years, centuries)\nBetween: Strictly for 2 persons/things\nAmong: For more than 2 persons/things\nBeside = By the side of | Besides = In addition to\nFixed Prepositions: Abide by, Abstain from, Accused of, Congratulate on, Cope with, Prevent from, Rely on",
      symbolExplanations = listOf(
        "Fixed Preposition" to "Verbs and adjectives that mandate specific prepositions regardless of context."
      ),
      importantIdentities = listOf(
        "Never say 'cope up with' (standard English is strictly 'cope with').",
        "Say 'congratulate ON success' (never 'congratulate for').",
        "Say 'discuss' or 'describe' without preposition (no 'discuss about')."
      ),
      shortcutsAndTips = listOf(
        "Verbs of motion into an enclosure take 'into' ('He jumped INTO the river')."
      ),
      commonMistakes = listOf(
        "Using 'about' after describe, discuss, order: 'ordered for coffee' (wrong! 'ordered coffee')."
      ),
      solvedExamples = listOf(
        createExample(
          "prep_ex1",
          "Correct: 'I congratulated him for his grand victory.'",
          "सुधारें: 'I congratulated him for his grand victory.'",
          listOf(
            "Step 1: The verb 'congratulate' takes the fixed preposition 'on'.",
            "Step 2: Correct sentence: 'I congratulated him ON his grand victory.'"
          ),
          "congratulated him on",
          "'Congratulate' takes 'on'."
        ),
        createExample(
          "prep_ex2",
          "Correct: 'He could not cope up with the heavy workload.'",
          "सुधारें: 'He could not cope up with the heavy workload.'",
          listOf(
            "Step 1: 'Cope up with' is a very common error.",
            "Step 2: The correct idiom in standard English is 'cope with' (no 'up').",
            "Step 3: Correct sentence: 'He could not cope with the heavy workload.'"
          ),
          "cope with",
          "No 'up' in 'cope with'."
        ),
        createExample(
          "prep_ex3",
          "Fill: 'She sat ______ (beside/besides) me throughout the lecture.'",
          "भरें: 'She sat ______ me throughout the lecture.'",
          listOf(
            "Step 1: 'Beside' means next to or by the side of.",
            "Step 2: 'Besides' means in addition to.",
            "Step 3: Sitting next to someone physical location requires 'beside'."
          ),
          "beside",
          "'Beside' means by the side of."
        )
      ),
      practiceMcqs = listOf(
        createMcq("prep_q1", "'He was accused ______ theft.'", "", "of", "with", "for", "in", 0, "Fixed preposition: 'accused of'."),
        createMcq("prep_q2", "'She is proficient ______ mathematics.'", "", "in", "at", "with", "on", 0, "'Proficient in' a subject."),
        createMcq("prep_q3", "'He jumped ______ the swimming pool.'", "", "into", "in", "on", "onto", 0, "Motion towards inside requires 'into'."),
        createMcq("prep_q4", "'Distribute the sweets ______ the five children.'", "", "among", "between", "with", "in", 0, "More than two children takes 'among'."),
        createMcq("prep_q5", "'He is fond ______ classical music.'", "", "of", "off", "with", "in", 0, "Fixed idiom: 'fond of'."),
        createMcq("prep_q6", "'The meeting is scheduled ______ Monday ______ 10:00 AM.'", "", "on, at", "at, on", "in, at", "on, in", 0, "'On' for days, 'At' for exact time."),
        createMcq("prep_q7", "Find error: 'He ordered for (A) / a cup of tea (B) / immediately (C) / No error (D)'", "", "(A) ordered for", "(B)", "(C)", "(D)", 0, "'Order' is transitive; does not take 'for'."),
        createMcq("prep_q8", "'You must abide ______ the traffic rules.'", "", "by", "with", "to", "on", 0, "Fixed idiom: 'abide by'."),
        createMcq("prep_q9", "'She was prevented ______ leaving the country.'", "", "from", "to", "of", "against", 0, "'Prevented from' taking gerund."),
        createMcq("prep_q10", "'We discussed ______ the budget proposal.'", "", "No preposition", "about", "on", "for", 0, "'Discuss' does not take 'about'.")
      )
    ),
    // 12. Conjunctions
    FormulaTopic(
      id = "eng_conjunctions",
      subject = FormulaSubject.ENGLISH,
      chapter = "Syntax & Concord",
      title = "Conjunctions & Correlatives",
      hindiTitle = "समुच्चयबोधक अव्यय",
      summary = "Correlative conjunction pairs (Although...yet, Not only...but also, Scarcely...when), lest...should, and parallel structure.",
      coreFormula = "Fixed Correlative Pairs:\nAlthough / Though ... YET (or comma, NEVER 'but')\nLest ... SHOULD (no negative word like 'not' allowed!)\nNot only ... BUT ALSO (requires parallel parts of speech)\nBoth ... AND (never 'as well as')\nBetween ... AND (never 'to')",
      symbolExplanations = listOf(
        "Correlative Conjunctions" to "Pairs of words that join grammatically equal sentence elements."
      ),
      importantIdentities = listOf(
        "'Lest' already implies fear of something negative; adding 'not' creates a double negative error."
      ),
      shortcutsAndTips = listOf(
        "Parallelism Check: Whatever part of speech follows 'but also' must also follow 'not only'."
      ),
      commonMistakes = listOf(
        "Writing 'Although he was poor but he was honest' (wrong! 'Although he was poor, yet he was honest')."
      ),
      solvedExamples = listOf(
        createExample(
          "conj_ex1",
          "Correct: 'Work hard lest you should not fail.'",
          "सुधारें: 'Work hard lest you should not fail.'",
          listOf(
            "Step 1: 'Lest' means 'for fear that' and inherently contains a negative meaning.",
            "Step 2: 'Lest' is followed by modal 'should' without any negative word 'not'.",
            "Step 3: Correct sentence: 'Work hard lest you should fail.'"
          ),
          "lest you should fail",
          "No 'not' after 'lest'."
        ),
        createExample(
          "conj_ex2",
          "Correct: 'Although he worked hard but he failed the exam.'",
          "सुधारें: 'Although he worked hard but he failed the exam.'",
          listOf(
            "Step 1: 'Although' is correlatively paired with 'yet' or a simple comma.",
            "Step 2: It is never paired with 'but'.",
            "Step 3: Correct sentence: 'Although he worked hard, yet he failed the exam.'"
          ),
          "Although ... yet",
          "'Although' takes 'yet', not 'but'."
        ),
        createExample(
          "conj_ex3",
          "Correct: 'He not only lost his wallet but also his watch.'",
          "सुधारें: 'He not only lost his wallet but also his watch.'",
          listOf(
            "Step 1: 'But also' is followed by noun phrase 'his watch'.",
            "Step 2: By rule of parallelism, 'not only' must immediately precede noun phrase 'his wallet'.",
            "Step 3: Correct sentence: 'He lost not only his wallet but also his watch.'"
          ),
          "He lost not only his wallet but also his watch.",
          "Parallel placement before nouns."
        )
      ),
      practiceMcqs = listOf(
        createMcq("conj_q1", "'Run fast lest you ______ miss the train.'", "", "should", "would", "may", "will", 0, "'Lest' is strictly followed by 'should'."),
        createMcq("conj_q2", "'The meeting is between 3:00 PM ______ 5:00 PM.'", "", "and", "to", "until", "with", 0, "'Between' is paired with 'and'."),
        createMcq("conj_q3", "'Both Ram ______ his brother attended the ceremony.'", "", "and", "as well as", "with", "along with", 0, "'Both' is paired strictly with 'and'."),
        createMcq("conj_q4", "'Scarcely had I reached home ______ it began to pour.'", "", "when", "than", "then", "that", 0, "'Scarcely' pairs with 'when'."),
        createMcq("conj_q5", "'I doubt ______ he will pass the test.'", "", "whether", "that", "what", "as", 0, "Expressing uncertainty in affirmative sentences takes 'whether/if'."),
        createMcq("conj_q6", "'She is ______ intelligent but also hardworking.'", "", "not only", "also", "too", "both", 0, "'Not only... but also' pair."),
        createMcq("conj_q7", "Find error: 'Though he is rich (A) / but he is (B) / very miserly (C) / No error (D)'", "", "(B) but he is", "(A)", "(C)", "(D)", 0, "'Though' cannot pair with 'but'; use 'yet' or comma."),
        createMcq("conj_q8", "'The reason why he failed is ______ he did not study.'", "", "that", "because", "due to", "since", 0, "'The reason why' is followed by 'that'."),
        createMcq("conj_q9", "'He had no other alternative ______ to surrender.'", "", "than", "but", "except", "and", 0, "'Other' and 'rather' are followed by 'than'."),
        createMcq("conj_q10", "'Unless you ______ hard, you cannot pass.'", "", "work", "do not work", "will work", "shall work", 0, "'Unless' is conditional negative; cannot take 'not' in its clause.")
      )
    ),
    // 13. Modals
    FormulaTopic(
      id = "eng_modals",
      subject = FormulaSubject.ENGLISH,
      chapter = "Verb Structures",
      title = "Modals & Auxiliary Verbs",
      hindiTitle = "मोडल क्रियाएं",
      summary = "Permission, capability, obligation, deduction, probability (can, could, may, might, must, should, ought to).",
      coreFormula = "Modals are followed by BARE INFINITIVE (V1):\nCan: Ability, informal permission\nMay: Probability (50%), formal permission, wish/blessing\nMight: Weak probability (25%)\nMust: Compulsion, strong logical deduction (95%)\nShould: Advice, moral duty\nOught to: Moral obligation (followed by 'to')\nCould have / Should have + V3: Unrealized past possibility",
      symbolExplanations = listOf(
        "Modals" to "Do not change form with subject; never take 's/es' or '-ed'."
      ),
      importantIdentities = listOf(
        "May have + V3: Deduction about a past possibility.",
        "Must have + V3: Strong conclusion about a past event."
      ),
      shortcutsAndTips = listOf(
        "Use 'Can' for physical/mental capability; use 'May' for permission and probability."
      ),
      commonMistakes = listOf(
        "Using 'can be able to' (redundant double expression of ability; use either 'can' or 'is able to')."
      ),
      solvedExamples = listOf(
        createExample(
          "mod_ex1",
          "Correct: 'He can be able to lift this heavy trunk.'",
          "सुधारें: 'He can be able to lift this heavy trunk.'",
          listOf(
            "Step 1: 'Can' and 'able to' both express ability.",
            "Step 2: Using both together is a superfluous redundant error.",
            "Step 3: Correct: 'He can lift this heavy trunk' OR 'He is able to lift this heavy trunk.'"
          ),
          "He can lift (remove 'be able to')",
          "Superfluous duplication of ability."
        ),
        createExample(
          "mod_ex2",
          "Fill: 'You ______ (should have/must) consulted a lawyer before signing yesterday.'",
          "भरें: 'You ______ consulted a lawyer before signing yesterday.'",
          listOf(
            "Step 1: The action was in the past and represents an unfulfilled advice.",
            "Step 2: Unfulfilled past advice takes 'should have + V3'.",
            "Step 3: Correct: 'You should have consulted...'"
          ),
          "should have",
          "Unfulfilled past duty."
        ),
        createExample(
          "mod_ex3",
          "Fill: 'The ground is wet; it ______ (must have/should have) rained last night.'",
          "भरें: 'The ground is wet; it ______ rained last night.'",
          listOf(
            "Step 1: The speaker makes a strong logical deduction about past.",
            "Step 2: Strong deduction in past takes 'must have + V3'.",
            "Step 3: Correct: 'it must have rained last night.'"
          ),
          "must have",
          "Strong past logical deduction."
        )
      ),
      practiceMcqs = listOf(
        createMcq("mod_q1", "'We ______ obey the traffic laws.'", "", "must", "might", "may", "could", 0, "Legal obligation requires 'must'."),
        createMcq("mod_q2", "'Take an umbrella; it ______ rain later today.'", "", "might", "shall", "must", "will have", 0, "Uncertain future possibility takes 'might' or 'may'."),
        createMcq("mod_q3", "'______ God bless you with prosperity!'", "", "May", "Can", "Must", "Should", 0, "Expressing wish/prayer uses 'May'."),
        createMcq("mod_q4", "'You ______ park your car in front of the emergency exit.'", "", "must not", "need not", "might not", "could not", 0, "Strict prohibition takes 'must not'."),
        createMcq("mod_q5", "'When he was young, he ______ swim across the river.'", "", "could", "can", "may", "might", 0, "Past general ability takes 'could'."),
        createMcq("mod_q6", "'You ______ worry; everything is under control.'", "", "need not", "must not", "cannot", "should not", 0, "Absence of obligation takes 'need not'."),
        createMcq("mod_q7", "'We ______ to help the poor and needy.'", "", "ought", "should", "must", "can", 0, "Followed by 'to' => 'ought to'."),
        createMcq("mod_q8", "'She ______ have left the keys in the office.'", "", "might", "should", "ought", "shall", 0, "Possibility in the past: might have left."),
        createMcq("mod_q9", "'I ______ rather stay at home than attend the party.'", "", "would", "should", "could", "might", 0, "'Would rather' expresses preference."),
        createMcq("mod_q10", "'How ______ you speak to me like that!'", "", "dare", "need", "may", "shall", 0, "Challenge/indignation takes 'dare'.")
      )
    ),
    // 14. Active and Passive Voice
    FormulaTopic(
      id = "eng_active_passive_voice",
      subject = FormulaSubject.ENGLISH,
      chapter = "Syntax & Transformations",
      title = "Active and Passive Voice",
      hindiTitle = "कर्तृवाच्य एवं कर्मवाच्य",
      summary = "Transformation formulas across tenses, modals, interrogatives, and imperatives (Let + obj + be + V3).",
      coreFormula = "General Passive: Object + form of 'Be' + Past Participle (V3) + by + Subject\nTense Matrix:\nSimple Present: is/am/are + V3\nPresent Continuous: is/am/are + being + V3\nPresent Perfect: has/have + been + V3\nSimple Past: was/were + V3\nPast Continuous: was/were + being + V3\nPast Perfect: had + been + V3\nSimple Future: will/shall + be + V3\nImperative: Let + Object + be + V3",
      symbolExplanations = listOf(
        "V3" to "Past participle form of main verb (always used in passive voice).",
        "Form of 'Be'" to "is, am, are, was, were, been, being."
      ),
      importantIdentities = listOf(
        "Four tenses have NO passive voice in standard English: Present Perfect Continuous, Past Perfect Continuous, Future Continuous, and Future Perfect Continuous.",
        "Intransitive verbs cannot be converted to passive."
      ),
      shortcutsAndTips = listOf(
        "Always identify the receiver of action (Object) and make it the Subject in passive."
      ),
      commonMistakes = listOf(
        "Changing tense during active-passive conversion (voice transformation NEVER changes tense!)."
      ),
      solvedExamples = listOf(
        createExample(
          "ap_ex1",
          "Convert to passive: 'The chef is preparing a delicious meal.'",
          "कर्मवाच्य में बदलिए: 'The chef is preparing a delicious meal.'",
          listOf(
            "Step 1: Subject = The chef; Verb = is preparing (Present Continuous); Object = a delicious meal.",
            "Step 2: Passive formula: Object + is/am/are + being + V3 + by + Subject.",
            "Step 3: Result: 'A delicious meal is being prepared by the chef.'"
          ),
          "A delicious meal is being prepared by the chef.",
          "Present Continuous uses 'being + V3'."
        ),
        createExample(
          "ap_ex2",
          "Convert to passive: 'Close the door.'",
          "कर्मवाच्य में बदलिए: 'Close the door.'",
          listOf(
            "Step 1: Imperative sentence expressing an order.",
            "Step 2: Formula: Let + Object + be + V3.",
            "Step 3: Result: 'Let the door be closed.'"
          ),
          "Let the door be closed.",
          "Imperative formula: Let + Obj + be + V3."
        ),
        createExample(
          "ap_ex3",
          "Convert to passive: 'Who wrote this famous novel?'",
          "कर्मवाच्य में बदलिए: 'Who wrote this famous novel?'",
          listOf(
            "Step 1: 'Who' converts to 'By whom'.",
            "Step 2: Simple Past ('wrote' -> was/were + V3).",
            "Step 3: Result: 'By whom was this famous novel written?'"
          ),
          "By whom was this famous novel written?",
          "'Who' converts to 'By whom'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ap_q1", "Passive of 'She has written a letter':", "", "A letter has been written by her.", "A letter was written by her.", "A letter is written by her.", "A letter had been written.", 0, "Present Perfect takes 'has been + V3'."),
        createMcq("ap_q2", "Passive of 'Post this letter':", "", "Let this letter be posted.", "This letter should post.", "Post the letter let.", "You are posted this letter.", 0, "Imperative formula: Let + object + be + V3."),
        createMcq("ap_q3", "Passive of 'They will build a new bridge':", "", "A new bridge will be built by them.", "A new bridge will build.", "A new bridge is built.", "A new bridge was built.", 0, "Future simple takes 'will be + V3'."),
        createMcq("ap_q4", "Passive of 'Why did you break the window pane?'", "", "Why was the window pane broken by you?", "Why were the window pane broken?", "Why the window pane was broken?", "Why did the window broken?", 0, "Interrogative simple past: Why + was + object + broken + by you?"),
        createMcq("ap_q5", "Passive of 'He made me write an essay':", "", "I was made to write an essay by him.", "I was made write an essay.", "An essay made me write.", "I had been made write.", 0, "In passive, causative 'make' takes full infinitive 'to write'."),
        createMcq("ap_q6", "Passive of 'Someone has stolen my pen':", "", "My pen has been stolen.", "My pen was stolen by someone.", "My pen is stolen.", "Someone was stolen my pen.", 0, "Vague subjects like 'someone' are omitted in passive."),
        createMcq("ap_q7", "Passive of 'Does he play cricket?'", "", "Is cricket played by him?", "Was cricket played by him?", "Did cricket played by him?", "Has cricket played by him?", 0, "Simple present interrogative takes 'Is + obj + V3'."),
        createMcq("ap_q8", "Which sentence cannot be converted into passive?", "", "He died in his sleep.", "He painted the wall.", "She sang a song.", "They won the trophy.", 0, "'Die' is intransitive; has no direct object."),
        createMcq("ap_q9", "Passive of 'People speak English all over the world':", "", "English is spoken all over the world.", "English was spoken.", "English has been spoken.", "English is being spoken.", 0, "Simple present passive: English is spoken."),
        createMcq("ap_q10", "Passive of 'The doctor examined the patient':", "", "The patient was examined by the doctor.", "The patient is examined.", "The patient had been examined.", "The patient was being examined.", 0, "Simple past passive: was examined.")
      )
    )
  )
}
