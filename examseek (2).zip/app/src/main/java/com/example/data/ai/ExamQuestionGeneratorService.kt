package com.example.data.ai

import com.example.BuildConfig
import com.example.data.local.entity.QuestionEntity
import com.example.domain.model.Difficulty
import com.example.domain.model.ExamDetail
import com.example.domain.model.TestQuestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit

sealed class GenerationResult {
  data class Success(
    val questions: List<QuestionEntity>,
    val duplicatesSkipped: Int,
    val sourceUsed: String
  ) : GenerationResult()

  data class Error(
    val message: String,
    val isApiKeyMissing: Boolean = false,
    val canRetry: Boolean = true
  ) : GenerationResult()
}

class ExamQuestionGeneratorService {

  private val client = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  companion object {
    const val PRIMARY_MODEL = "gemini-3.8-flash"
    const val SECONDARY_MODEL = "gemini-3.5-flash"
    const val FALLBACK_MODEL = "gemini-3.5-flash-lite"

    fun computeContentHash(qText: String, a: String, b: String, c: String, d: String): String {
      val normQ = qText.trim().lowercase().replace("\\s+".toRegex(), " ")
      val normA = a.trim().lowercase().replace("\\s+".toRegex(), " ")
      val normB = b.trim().lowercase().replace("\\s+".toRegex(), " ")
      val normC = c.trim().lowercase().replace("\\s+".toRegex(), " ")
      val normD = d.trim().lowercase().replace("\\s+".toRegex(), " ")
      val combined = "$normQ|$normA|$normB|$normC|$normD"
      val bytes = MessageDigest.getInstance("SHA-256").digest(combined.toByteArray())
      return bytes.joinToString("") { "%02x".format(it) }.take(16)
    }

    fun computeHash(qText: String, a: String, b: String, c: String, d: String): String =
      computeContentHash(qText, a, b, c, d)
  }

  fun generateContentHash(statement: String, answer: String): String {
    val normQ = statement.trim().lowercase().replace("\\s+".toRegex(), " ")
    val normA = answer.trim().lowercase().replace("\\s+".toRegex(), " ")
    val combined = "$normQ|$normA"
    val bytes = MessageDigest.getInstance("SHA-256").digest(combined.toByteArray())
    return bytes.joinToString("") { "%02x".format(it) }.take(16)
  }

  fun parseAndValidateQuestions(
    jsonText: String,
    examId: String,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String,
    language: String
  ): List<TestQuestion> {
    try {
      val jsonArray = parseCleanJsonArray(jsonText)
      if (jsonArray != null) {
        val list = mutableListOf<TestQuestion>()
        for (i in 0 until jsonArray.length()) {
          val obj = jsonArray.optJSONObject(i) ?: continue
          val qText = obj.optString("questionText").trim()
          val optionsArray = obj.optJSONArray("options")
          val optionsList = mutableListOf<String>()
          if (optionsArray != null) {
            for (j in 0 until optionsArray.length()) {
              optionsList.add(optionsArray.optString(j).trim())
            }
          } else {
            val a = obj.optString("optionA").trim()
            val b = obj.optString("optionB").trim()
            val c = obj.optString("optionC").trim()
            val d = obj.optString("optionD").trim()
            if (a.isNotBlank() && b.isNotBlank() && c.isNotBlank() && d.isNotBlank()) {
              optionsList.addAll(listOf(a, b, c, d))
            }
          }
          if (qText.isBlank() || optionsList.size != 4) continue
          val correctIndex = obj.optInt("correctAnswerIndex", obj.optInt("correctOptionIndex", 0)).coerceIn(0, 3)
          val explanation = obj.optString("explanation").trim()
          val hindiQText = obj.optString("hindiQuestionText", qText)
          val hindiOptionsArray = obj.optJSONArray("hindiOptions")
          val hindiOptionsList = mutableListOf<String>()
          if (hindiOptionsArray != null) {
            for (j in 0 until hindiOptionsArray.length()) {
              hindiOptionsList.add(hindiOptionsArray.optString(j).trim())
            }
          }

          list.add(
            TestQuestion(
              id = "parsed_${System.currentTimeMillis()}_$i",
              testId = "test_$examId",
              subject = subject,
              topic = topic,
              questionText = qText,
              hindiQuestionText = hindiQText,
              options = optionsList,
              hindiOptions = hindiOptionsList,
              correctOptionIndex = correctIndex,
              explanation = explanation.ifBlank { "Option ${listOf("A", "B", "C", "D")[correctIndex]} is correct." },
              hindiExplanation = obj.optString("hindiExplanation", ""),
              difficulty = try { Difficulty.valueOf(difficulty) } catch (e: Exception) { Difficulty.MEDIUM },
              source = "ExamSeek AI Generator ($PRIMARY_MODEL)",
              year = "2024",
              shift = "Shift-1",
              paper = "Paper-1",
              officialAnswerKeyRef = "",
              isVerified = false,
              sourceLabel = "AI_GENERATED",
              contentHash = generateContentHash(qText, optionsList.getOrElse(correctIndex) { "" }),
              targetExam = examId,
              stage = stage
            )
          )
        }
        return list
      }
    } catch (_: Throwable) {
      // Fallback for plain JVM unit tests
    }
    return parseQuestionsFallback(jsonText, examId, stage, subject, topic, difficulty)
  }

  private fun parseQuestionsFallback(
    jsonText: String,
    examId: String,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String
  ): List<TestQuestion> {
    val list = mutableListOf<TestQuestion>()
    val objectRegex = Regex("""\{([^{}]+)\}""")
    val matches = objectRegex.findAll(jsonText)
    var idx = 0
    for (match in matches) {
      val body = match.groupValues[1]
      val qText = Regex(""""questionText"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1)?.trim() ?: continue
      val optMatch = Regex(""""options"\s*:\s*\[(.*?)\]""").find(body)
      val optionsList = mutableListOf<String>()
      if (optMatch != null) {
        val rawOpts = optMatch.groupValues[1]
        Regex(""""([^"]+)"""").findAll(rawOpts).forEach {
          optionsList.add(it.groupValues[1].trim())
        }
      }
      if (optionsList.size != 4) continue
      val correctIndex = Regex(""""correctAnswerIndex"\s*:\s*(\d+)"""").find(body)?.groupValues?.get(1)?.toIntOrNull() ?: 0
      val explanation = Regex(""""explanation"\s*:\s*"([^"]*)"""").find(body)?.groupValues?.get(1)?.trim() ?: ""
      val hindiQText = Regex(""""hindiQuestionText"\s*:\s*"([^"]*)"""").find(body)?.groupValues?.get(1)?.trim() ?: qText

      list.add(
        TestQuestion(
          id = "parsed_${System.currentTimeMillis()}_$idx",
          testId = "test_$examId",
          subject = subject,
          topic = topic,
          questionText = qText,
          hindiQuestionText = hindiQText,
          options = optionsList,
          hindiOptions = emptyList(),
          correctOptionIndex = correctIndex.coerceIn(0, 3),
          explanation = explanation.ifBlank { "Option ${listOf("A", "B", "C", "D")[correctIndex]} is correct." },
          difficulty = try { Difficulty.valueOf(difficulty) } catch (e: Exception) { Difficulty.MEDIUM },
          source = "ExamSeek AI Generator ($PRIMARY_MODEL)",
          year = "2024",
          isVerified = false,
          sourceLabel = "AI_GENERATED",
          contentHash = generateContentHash(qText, optionsList.getOrElse(correctIndex) { "" }),
          targetExam = examId,
          stage = stage
        )
      )
      idx++
    }
    return list
  }

  fun generateCurriculumFallbackBatch(
    exam: ExamDetail,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String,
    language: String,
    count: Int
  ): List<TestQuestion> {
    val templates = AcademicQuestionBankTemplates.getTemplates(subject, topic)
    val list = mutableListOf<TestQuestion>()
    for (i in 0 until count) {
      val template = templates[i % templates.size]
      val seed = (i * 19) + 7
      val instantiated = template.instantiate(seed, difficulty)
      val options = listOf(instantiated.optA, instantiated.optB, instantiated.optC, instantiated.optD)
      list.add(
        TestQuestion(
          id = "curriculum_fb_${System.currentTimeMillis()}_$i",
          testId = "test_${exam.id}",
          subject = subject,
          topic = topic,
          questionText = instantiated.qText,
          hindiQuestionText = instantiated.hindiQText,
          options = options,
          hindiOptions = listOf(instantiated.hindiOptA, instantiated.hindiOptB, instantiated.hindiOptC, instantiated.hindiOptD),
          correctOptionIndex = instantiated.correctIndex,
          explanation = instantiated.explanation,
          hindiExplanation = instantiated.hindiExplanation,
          difficulty = try { Difficulty.valueOf(difficulty) } catch (e: Exception) { Difficulty.MEDIUM },
          source = "ExamSeek Curriculum Engine (Academic Model)",
          year = "2024",
          isVerified = false,
          sourceLabel = "AI_GENERATED",
          contentHash = generateContentHash(instantiated.qText, options[instantiated.correctIndex]),
          targetExam = exam.id,
          stage = stage
        )
      )
    }
    return list
  }

  suspend fun generateQuestionBatch(
    examDetail: ExamDetail,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String,
    language: String,
    batchSize: Int = 10,
    existingHashesChecker: suspend (String) -> Boolean
  ): GenerationResult = withContext(Dispatchers.IO) {
    val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
    val isKeyConfigured = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

    if (!isKeyConfigured) {
      return@withContext generateLocalAcademicBatch(
        examDetail = examDetail,
        stage = stage,
        subject = subject,
        topic = topic,
        difficulty = difficulty,
        language = language,
        batchSize = batchSize,
        existingHashesChecker = existingHashesChecker
      )
    }

    var attempt = 0
    val maxRetries = 2
    var lastErrorMsg = ""
    while (attempt <= maxRetries) {
      try {
        val result = callGeminiGenerate(
          apiKey = apiKey,
          examDetail = examDetail,
          stage = stage,
          subject = subject,
          topic = topic,
          difficulty = difficulty,
          language = language,
          batchSize = batchSize,
          existingHashesChecker = existingHashesChecker
        )
        if (result is GenerationResult.Success) {
          return@withContext result
        } else if (result is GenerationResult.Error && !result.canRetry) {
          return@withContext result
        }
        lastErrorMsg = (result as? GenerationResult.Error)?.message ?: "Retry"
        attempt++
        if (attempt <= maxRetries) delay(1000L * attempt)
      } catch (e: Exception) {
        lastErrorMsg = e.localizedMessage ?: "Network error"
        attempt++
        if (attempt <= maxRetries) delay(1000L * attempt)
      }
    }

    // Fallback to local academic model if remote call fails
    generateLocalAcademicBatch(
      examDetail = examDetail,
      stage = stage,
      subject = subject,
      topic = topic,
      difficulty = difficulty,
      language = language,
      batchSize = batchSize,
      existingHashesChecker = existingHashesChecker
    )
  }

  private suspend fun callGeminiGenerate(
    apiKey: String,
    examDetail: ExamDetail,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String,
    language: String,
    batchSize: Int,
    existingHashesChecker: suspend (String) -> Boolean
  ): GenerationResult {
    val systemPrompt = """
      You are an expert Question Designer and Academic Controller for Indian competitive exams (${examDetail.name}).
      Your objective is to generate strictly realistic, high-quality Multiple Choice Questions (MCQs) mapped precisely to the syllabus.

      STRICT REQUIREMENTS:
      1. Exam: ${examDetail.name} (${examDetail.category.displayName})
      2. Stage: $stage
      3. Subject: $subject
      4. Topic: $topic
      5. Difficulty: $difficulty
      6. Output Count: Exactly $batchSize questions.
      7. Each question MUST have:
         - Exactly 4 distinct options (Option A, B, C, D).
         - Exactly 1 unambiguous correct answer index (0 for A, 1 for B, 2 for C, 3 for D).
         - A comprehensive step-by-step mathematical calculation or conceptual explanation.
         - Both English and Hindi translations for question text, options and explanation.
      8. NEVER label questions as official PYQ. They are AI-generated practice questions.
      9. Output MUST be ONLY valid JSON matching this schema:
      [
        {
          "questionText": "...",
          "hindiQuestionText": "...",
          "optionA": "...",
          "optionB": "...",
          "optionC": "...",
          "optionD": "...",
          "hindiOptionA": "...",
          "hindiOptionB": "...",
          "hindiOptionC": "...",
          "hindiOptionD": "...",
          "correctOptionIndex": 0,
          "explanation": "...",
          "hindiExplanation": "..."
        }
      ]
    """.trimIndent()

    val prompt = "Generate a fresh batch of $batchSize MCQs on '$topic' for $subject under ${examDetail.name} ($stage). Return valid JSON array only."

    val requestJson = JSONObject().apply {
      val contentsArray = JSONArray().apply {
        val contentObj = JSONObject().apply {
          val partsArray = JSONArray().apply {
            put(JSONObject().put("text", prompt))
          }
          put("parts", partsArray)
        }
        put(contentObj)
      }
      put("contents", contentsArray)

      val systemObj = JSONObject().apply {
        val partsArray = JSONArray().apply {
          put(JSONObject().put("text", systemPrompt))
        }
        put("parts", partsArray)
      }
      put("systemInstruction", systemObj)

      val genConfig = JSONObject().apply {
        put("temperature", 0.7)
        put("responseMimeType", "application/json")
      }
      put("generationConfig", genConfig)
    }

    val mediaType = "application/json; charset=utf-8".toMediaType()
    val body = requestJson.toString().toRequestBody(mediaType)

    val modelsToTry = listOf(PRIMARY_MODEL, SECONDARY_MODEL, FALLBACK_MODEL)
    var lastError = ""
    var modelUsed = PRIMARY_MODEL

    for (model in modelsToTry) {
      val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
      val httpRequest = Request.Builder()
        .url(url)
        .post(body)
        .build()

      try {
        val response = client.newCall(httpRequest).execute()
        val responseString = response.body?.string() ?: ""

        if (response.isSuccessful) {
          modelUsed = model
          val root = JSONObject(responseString)
          val candidates = root.optJSONArray("candidates")
          if (candidates != null && candidates.length() > 0) {
            val content = candidates.getJSONObject(0).optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text") ?: ""
            val jsonArray = parseCleanJsonArray(rawText)
            if (jsonArray != null) {
              val validQuestions = mutableListOf<QuestionEntity>()
              var duplicates = 0

              for (i in 0 until jsonArray.length()) {
                val item = jsonArray.optJSONObject(i) ?: continue
                val qText = item.optString("questionText").trim()
                val optA = item.optString("optionA").trim()
                val optB = item.optString("optionB").trim()
                val optC = item.optString("optionC").trim()
                val optD = item.optString("optionD").trim()
                val correctIdx = item.optInt("correctOptionIndex", 0).coerceIn(0, 3)
                val explanation = item.optString("explanation").trim()

                if (qText.isBlank() || optA.isBlank() || optB.isBlank() || optC.isBlank() || optD.isBlank()) {
                  continue
                }
                val distinctOptions = setOf(optA, optB, optC, optD)
                if (distinctOptions.size < 4) {
                  continue
                }

                val hash = computeContentHash(qText, optA, optB, optC, optD)
                if (existingHashesChecker(hash)) {
                  duplicates++
                  continue
                }

                val entity = QuestionEntity(
                  id = "gen_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                  testId = "test_practice_${examDetail.id}",
                  subject = subject,
                  topic = topic,
                  questionText = qText,
                  optionA = optA,
                  optionB = optB,
                  optionC = optC,
                  optionD = optD,
                  correctOptionIndex = correctIdx,
                  explanation = explanation.ifBlank { "Correct option is ${('A' + correctIdx)}. Step-by-step logic applies." },
                  hindiQuestionText = item.optString("hindiQuestionText", qText).trim(),
                  hindiOptionA = item.optString("hindiOptionA", optA).trim(),
                  hindiOptionB = item.optString("hindiOptionB", optB).trim(),
                  hindiOptionC = item.optString("hindiOptionC", optC).trim(),
                  hindiOptionD = item.optString("hindiOptionD", optD).trim(),
                  hindiExplanation = item.optString("hindiExplanation", explanation).trim(),
                  difficulty = difficulty,
                  source = "ExamSeek AI Generator ($model)",
                  year = "2024",
                  shift = "Shift-1",
                  paper = "Paper-1",
                  officialAnswerKeyRef = "",
                  isVerified = false,
                  targetExam = examDetail.name,
                  stage = stage,
                  language = language,
                  sourceLabel = "AI_GENERATED_PRACTICE",
                  contentHash = hash,
                  createdAt = System.currentTimeMillis()
                )
                validQuestions.add(entity)
              }

              if (validQuestions.isNotEmpty()) {
                return GenerationResult.Success(
                  questions = validQuestions,
                  duplicatesSkipped = duplicates,
                  sourceUsed = "Gemini AI Engine ($modelUsed)"
                )
              }
            }
          }
        } else {
          lastError = "Model $model returned HTTP ${response.code}: $responseString"
        }
      } catch (callEx: Exception) {
        lastError = callEx.message ?: "Network error calling $model"
      }
    }

    return GenerationResult.Error(
      message = lastError.ifBlank { "Failed to generate questions from AI services." },
      isApiKeyMissing = false,
      canRetry = true
    )
  }

  private fun parseCleanJsonArray(rawText: String): JSONArray? {
    val clean = rawText.trim()
      .removePrefix("```json")
      .removePrefix("```")
      .removeSuffix("```")
      .trim()
    return try {
      JSONArray(clean)
    } catch (e: Exception) {
      val firstBracket = clean.indexOf('[')
      val lastBracket = clean.lastIndexOf(']')
      if (firstBracket >= 0 && lastBracket > firstBracket) {
        try {
          JSONArray(clean.substring(firstBracket, lastBracket + 1))
        } catch (e2: Exception) {
          null
        }
      } else {
        null
      }
    }
  }

  private suspend fun generateLocalAcademicBatch(
    examDetail: ExamDetail,
    stage: String,
    subject: String,
    topic: String,
    difficulty: String,
    language: String,
    batchSize: Int,
    existingHashesChecker: suspend (String) -> Boolean
  ): GenerationResult {
    val list = mutableListOf<QuestionEntity>()
    var duplicates = 0
    val templates = AcademicQuestionBankTemplates.getTemplates(subject, topic)

    for (i in 0 until batchSize) {
      val template = templates[i % templates.size]
      val variationSeed = (System.currentTimeMillis() % 1000).toInt() + (i * 17) + 1
      val questionData = template.instantiate(variationSeed, difficulty)

      val hash = computeContentHash(
        questionData.qText,
        questionData.optA,
        questionData.optB,
        questionData.optC,
        questionData.optD
      )

      if (existingHashesChecker(hash)) {
        duplicates++
        continue
      }

      val entity = QuestionEntity(
        id = "local_gen_${System.currentTimeMillis()}_${i}_${UUID.randomUUID().toString().take(4)}",
        testId = "test_practice_${examDetail.id}",
        subject = subject,
        topic = topic,
        questionText = questionData.qText,
        optionA = questionData.optA,
        optionB = questionData.optB,
        optionC = questionData.optC,
        optionD = questionData.optD,
        correctOptionIndex = questionData.correctIndex,
        explanation = questionData.explanation,
        hindiQuestionText = questionData.hindiQText,
        hindiOptionA = questionData.hindiOptA,
        hindiOptionB = questionData.hindiOptB,
        hindiOptionC = questionData.hindiOptC,
        hindiOptionD = questionData.hindiOptD,
        hindiExplanation = questionData.hindiExplanation,
        difficulty = difficulty,
        source = "ExamSeek Academic Engine (Curriculum Algorithmic Model)",
        year = "2024",
        shift = "Shift-1",
        paper = "Paper-1",
        officialAnswerKeyRef = "",
        isVerified = false,
        targetExam = examDetail.name,
        stage = stage,
        language = language,
        sourceLabel = "AI_GENERATED_PRACTICE",
        contentHash = hash,
        createdAt = System.currentTimeMillis()
      )
      list.add(entity)
    }

    return GenerationResult.Success(
      questions = list,
      duplicatesSkipped = duplicates,
      sourceUsed = "ExamSeek Academic Pattern Engine"
    )
  }
}

data class InstantiatedQuestion(
  val qText: String,
  val hindiQText: String,
  val optA: String,
  val optB: String,
  val optC: String,
  val optD: String,
  val hindiOptA: String,
  val hindiOptB: String,
  val hindiOptC: String,
  val hindiOptD: String,
  val correctIndex: Int,
  val explanation: String,
  val hindiExplanation: String
)

interface AcademicTemplate {
  fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion
}

object AcademicQuestionBankTemplates {
  fun getTemplates(subject: String, topic: String): List<AcademicTemplate> {
    return when {
      subject.contains("Quant", ignoreCase = true) || subject.contains("Math", ignoreCase = true) -> quantTemplates
      subject.contains("Reasoning", ignoreCase = true) || subject.contains("Intelligence", ignoreCase = true) -> reasoningTemplates
      subject.contains("English", ignoreCase = true) -> englishTemplates
      else -> generalAwarenessTemplates
    }
  }

  private val quantTemplates = listOf(
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        val cp = 400 + (seed % 15) * 50
        val markup = 20 + (seed % 4) * 10
        val discount = 10 + (seed % 3) * 5
        val mp = cp + (cp * markup / 100)
        val discountAmount = mp * discount / 100
        val sp = mp - discountAmount
        val options = listOf(
          "₹$sp",
          "₹${sp + 25}",
          "₹${sp - 30}",
          "₹${sp + 50}"
        )
        return InstantiatedQuestion(
          qText = "A retailer marks an article $markup% above its cost price and offers a discount of $discount%. If the cost price is ₹$cp, find the selling price.",
          hindiQText = "एक व्यापारी किसी वस्तु पर क्रय मूल्य से $markup% अधिक अंकित करता है और $discount% की छूट देता है। यदि क्रय मूल्य ₹$cp है, तो विक्रय मूल्य ज्ञात कीजिए।",
          optA = options[0],
          optB = options[1],
          optC = options[2],
          optD = options[3],
          hindiOptA = options[0],
          hindiOptB = options[1],
          hindiOptC = options[2],
          hindiOptD = options[3],
          correctIndex = 0,
          explanation = "Cost Price = ₹$cp. Marked Price = $cp + ($markup% of $cp) = ₹$mp. Discount = $discount% of ₹$mp = ₹$discountAmount. Selling Price = MP - Discount = ₹$sp.",
          hindiExplanation = "क्रय मूल्य = ₹$cp, अंकित मूल्य = ₹$mp, छूट = ₹$discountAmount, विक्रय मूल्य = ₹$sp।",
        )
      }
    },
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        val men = 12 + (seed % 6) * 2
        val days = 15 + (seed % 5) * 3
        val newMen = men + 6
        val newDays = (men * days) / newMen
        val options = listOf(
          "$newDays days",
          "${newDays + 2} days",
          "${newDays + 4} days",
          "${newDays - 2} days"
        )
        return InstantiatedQuestion(
          qText = "If $men men can complete a construction project in $days days, how many days will $newMen men take to complete the same work at the same rate?",
          hindiQText = "यदि $men पुरुष किसी निर्माण कार्य को $days दिनों में पूरा कर सकते हैं, तो उसी कार्य को $newMen पुरुष कितने दिनों में पूरा करेंगे?",
          optA = options[0],
          optB = options[1],
          optC = options[2],
          optD = options[3],
          hindiOptA = "${options[0].replace("days", "दिन")}",
          hindiOptB = "${options[1].replace("days", "दिन")}",
          hindiOptC = "${options[2].replace("days", "दिन")}",
          hindiOptD = "${options[3].replace("days", "दिन")}",
          correctIndex = 0,
          explanation = "Total Work = Men * Days = $men * $days = ${men * days} man-days. Days required for $newMen men = ${men * days} / $newMen = $newDays days.",
          hindiExplanation = "कुल कार्य = $men * $days = ${men * days} मानव-दिन। आवश्यक दिन = $newDays दिन।",
        )
      }
    },
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        val p = 5000 + (seed % 10) * 1000
        val r = 8 + (seed % 4) * 2
        val ciDiff = (p * (r * r)) / 10000
        val options = listOf(
          "₹$ciDiff",
          "₹${ciDiff + 10}",
          "₹${ciDiff + 25}",
          "₹${ciDiff - 8.coerceAtLeast(1)}"
        )
        return InstantiatedQuestion(
          qText = "What is the difference between Simple Interest (SI) and Compound Interest (CI) on a principal of ₹$p for 2 years at an annual interest rate of $r% compounded annually?",
          hindiQText = "₹$p के मूलधन पर $r% वार्षिक दर से 2 वर्ष के साधारण ब्याज और चक्रवृद्धि ब्याज में क्या अंतर होगा?",
          optA = options[0],
          optB = options[1],
          optC = options[2],
          optD = options[3],
          hindiOptA = options[0],
          hindiOptB = options[1],
          hindiOptC = options[2],
          hindiOptD = options[3],
          correctIndex = 0,
          explanation = "For 2 years, Difference = P * (R/100)² = $p * ($r/100)² = $p * ${r * r}/10000 = ₹$ciDiff.",
          hindiExplanation = "2 वर्ष के लिए अंतर = P * (R/100)² = ₹$ciDiff।",
        )
      }
    }
  )

  private val reasoningTemplates = listOf(
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        val base = 11 + (seed % 7)
        val square = base * base
        val nextBase = base + 3
        val nextSquare = nextBase * nextBase
        val options = listOf(
          "$nextSquare",
          "${nextSquare - 10}",
          "${nextSquare + 20}",
          "${nextSquare + 15}"
        )
        return InstantiatedQuestion(
          qText = "Select the related number from the given alternatives: $base : $square :: $nextBase : ?",
          hindiQText = "संबंधित संख्या चुनिए: $base : $square :: $nextBase : ?",
          optA = options[0],
          optB = options[1],
          optC = options[2],
          optD = options[3],
          hindiOptA = options[0],
          hindiOptB = options[1],
          hindiOptC = options[2],
          hindiOptD = options[3],
          correctIndex = 0,
          explanation = "The pattern follows n : n². $base² = $square. Similarly, $nextBase² = $nextSquare.",
          hindiExplanation = "पैटर्न n : n² का है। $base² = $square, अतः $nextBase² = $nextSquare।",
        )
      }
    },
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        return InstantiatedQuestion(
          qText = "Statements: All Rivers are Water. Some Water is Ocean.\nConclusions:\nI. Some Rivers are Ocean.\nII. All Ocean being Water is a possibility.",
          hindiQText = "कथन: सभी नदियाँ जल हैं। कुछ जल महासागर हैं।\nनिष्कर्ष:\nI. कुछ नदियाँ महासागर हैं।\nII. सभी महासागर के जल होने की संभावना है।",
          optA = "Only conclusion II follows",
          optB = "Only conclusion I follows",
          optC = "Both I and II follow",
          optD = "Neither I nor II follows",
          hindiOptA = "केवल निष्कर्ष II अनुसरण करता है",
          hindiOptB = "केवल निष्कर्ष I अनुसरण करता है",
          hindiOptC = "दोनों निष्कर्ष अनुसरण करते हैं",
          hindiOptD = "कोई भी निष्कर्ष अनुसरण नहीं करता",
          correctIndex = 0,
          explanation = "1. Definite overlap between Rivers and Ocean is not given, so Conclusion I is false. 2. Ocean can be a subset of Water as a valid possibility diagram, so Conclusion II follows.",
          hindiExplanation = "केवल संभावना वाला निष्कर्ष II सत्य है।",
        )
      }
    }
  )

  private val englishTemplates = listOf(
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        return InstantiatedQuestion(
          qText = "Identify the segment containing a grammatical error: 'Neither the principal nor the teachers (A) / was present in the auditorium (B) / when the chief guest arrived (C) / No Error (D)'.",
          hindiQText = "व्याकरण त्रुटि पहचानिए: 'Neither the principal nor the teachers was present in the auditorium when the chief guest arrived'.",
          optA = "was present in the auditorium",
          optB = "Neither the principal nor the teachers",
          optC = "when the chief guest arrived",
          optD = "No Error",
          hindiOptA = "was present in the auditorium (त्रुटि)",
          hindiOptB = "Neither the principal nor the teachers",
          hindiOptC = "when the chief guest arrived",
          hindiOptD = "No Error (कोई त्रुटि नहीं)",
          correctIndex = 0,
          explanation = "Rule: When subjects are connected by 'neither...nor', the verb agrees with the closer subject. 'teachers' is plural, so 'were present' should be used instead of 'was present'.",
          hindiExplanation = "'Neither...nor' में क्रिया निकटतम कर्ता ('teachers') के अनुसार बहुवचन ('were') होनी चाहिए।",
        )
      }
    }
  )

  private val generalAwarenessTemplates = listOf(
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        return InstantiatedQuestion(
          qText = "Which Article of the Indian Constitution empowers the President of India to promulgate Ordinances during the recess of Parliament?",
          hindiQText = "भारतीय संविधान का कौन सा अनुच्छेद संसद के अवकाश के दौरान राष्ट्रपति को अध्यादेश जारी करने का अधिकार देता है?",
          optA = "Article 123",
          optB = "Article 213",
          optC = "Article 72",
          optD = "Article 143",
          hindiOptA = "अनुच्छेद 123",
          hindiOptB = "अनुच्छेद 213",
          hindiOptC = "अनुच्छेद 72",
          hindiOptD = "अनुच्छेद 143",
          correctIndex = 0,
          explanation = "Article 123 of the Indian Constitution grants the President power to promulgate Ordinances when Parliament is not in session. Article 213 grants similar powers to Governors.",
          hindiExplanation = "अनुच्छेद 123 राष्ट्रपति के अध्यादेश से संबंधित है (राज्यपाल के लिए अनुच्छेद 213)।",
        )
      }
    },
    object : AcademicTemplate {
      override fun instantiate(seed: Int, difficulty: String): InstantiatedQuestion {
        return InstantiatedQuestion(
          qText = "In which year was the Goods and Services Tax (GST) officially implemented in India?",
          hindiQText = "भारत में वस्तु एवं सेवा कर (GST) आधिकारिक तौर पर किस वर्ष लागू किया गया था?",
          optA = "1 July 2017",
          optB = "1 April 2016",
          optC = "15 August 2017",
          optD = "1 January 2018",
          hindiOptA = "1 जुलाई 2017",
          hindiOptB = "1 अप्रैल 2016",
          hindiOptC = "15 अगस्त 2017",
          hindiOptD = "1 जनवरी 2018",
          correctIndex = 0,
          explanation = "The Goods and Services Tax (GST) was implemented in India on 1 July 2017 through the 101st Constitutional Amendment Act.",
          hindiExplanation = "101वें संविधान संशोधन अधिनियम द्वारा 1 जुलाई 2017 से GST लागू हुआ।",
        )
      }
    }
  )
}
