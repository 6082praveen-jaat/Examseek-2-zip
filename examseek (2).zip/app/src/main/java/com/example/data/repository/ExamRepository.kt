package com.example.data.repository

import android.content.Context
import com.example.data.ai.ExamQuestionGeneratorService
import com.example.data.local.ExamSeekDatabase
import com.example.data.local.SampleExamData
import com.example.data.local.entity.ActiveTestSessionEntity
import com.example.data.local.entity.BookmarkEntity
import com.example.data.local.entity.QuestionEntity
import com.example.data.local.entity.TestAttemptEntity
import com.example.data.local.entity.TestEntity
import com.example.data.local.entity.WrongAnswerEntity
import com.example.domain.model.Difficulty
import com.example.domain.model.ExamCategory
import com.example.domain.model.ExamDetail
import com.example.domain.model.ExamRegistry
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.domain.model.TestResult
import com.example.domain.model.TestType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ExamRepository(private val context: Context) {

  private val database = ExamSeekDatabase.getInstance(context)
  private val testDao = database.testDao()
  private val questionDao = database.questionDao()
  private val attemptDao = database.testAttemptDao()
  private val activeSessionDao = database.activeTestSessionDao()
  private val wrongAnswerDao = database.wrongAnswerDao()
  private val bookmarkDao = database.bookmarkDao()
  private val aiGenerator = ExamQuestionGeneratorService()

  suspend fun initializeIfNeeded() = withContext(Dispatchers.IO) {
    val count = questionDao.getQuestionCount()
    if (count == 0) {
      testDao.insertTests(SampleExamData.sampleTests)
      questionDao.insertQuestions(SampleExamData.sampleQuestions)
      database.studyMaterialDao().insertMaterials(SampleExamData.sampleStudyMaterials)
      database.userDao().insertUser(SampleExamData.defaultUser)
      database.userDao().insertUser(SampleExamData.defaultAdmin)
    }
  }

  // --- TESTS ---
  fun getAllTests(): Flow<List<TestItem>> {
    return testDao.getAllTests().map { entities ->
      entities.map { it.toDomain() }
    }
  }

  suspend fun getTestsByCategory(category: String): List<TestItem> = withContext(Dispatchers.IO) {
    testDao.getTestsByCategory(category).first().map { it.toDomain() }
  }

  suspend fun getTestById(testId: String): TestItem? = withContext(Dispatchers.IO) {
    testDao.getTestById(testId)?.toDomain()
  }

  // Standard 15-question generator for any exam
  suspend fun generateOrGetStandard15QuestionTest(
    examName: String,
    category: ExamCategory,
    subject: String = "All Subjects",
    testType: TestType = TestType.FULL_MOCK
  ): Pair<TestItem, List<TestQuestion>> = withContext(Dispatchers.IO) {
    var rawQuestions = questionDao.getRandomQuestionsForExam(examName, if (subject == "All Subjects") "All" else subject, 30)
      .map { it.toDomain() }

    if (rawQuestions.size < 15) {
      val fallbackPool = questionDao.getRandomQuestionsForExam(category.displayName, "All", 30).map { it.toDomain() }
      rawQuestions = (rawQuestions + fallbackPool).distinctBy { it.contentHash.ifEmpty { it.id } }
    }

    val distinct15 = rawQuestions.distinctBy { it.contentHash.ifEmpty { it.questionText } }.shuffled().take(15)

    val finalQuestions = if (distinct15.size >= 15) {
      distinct15
    } else {
      val examDetail = ExamRegistry.findExam(examName) ?: ExamRegistry.allExams.first()
      val generated = aiGenerator.generateCurriculumFallbackBatch(
        exam = examDetail,
        stage = "Tier-1",
        subject = if (subject == "All Subjects") "Quantitative Aptitude" else subject,
        topic = "General",
        difficulty = "MEDIUM",
        language = "ENGLISH",
        count = 15 - distinct15.size
      )
      questionDao.insertQuestions(generated.map { it.toEntity() })
      (distinct15 + generated).take(15)
    }

    val testId = "dyn_${category.id.lowercase()}_${System.currentTimeMillis()}"
    val testItem = TestItem(
      id = testId,
      title = "$examName 15-Question Practice Set",
      category = category,
      type = testType,
      durationMinutes = 15,
      totalQuestions = 15,
      totalMarks = 30f,
      marksPerQuestion = 2.0f,
      negativeMarkingRate = 0.5f,
      isNegativeMarkingEnabled = true,
      isVerified = true,
      subject = subject,
      description = "Real exam-standard 15-question timed mock test with negative marking & comprehensive solutions.",
      tier = SubscriptionTier.FREE,
      attemptsCount = (100..2500).random(),
      examYear = "2024",
      examShift = "Shift-1"
    )

    testDao.insertTest(testItem.toEntity())

    val boundQuestions = finalQuestions.mapIndexed { index, q ->
      val entity = q.copy(testId = testId, id = "${testId}_q${index + 1}").toEntity()
      questionDao.insertQuestion(entity)
      entity.toDomain()
    }

    Pair(testItem, boundQuestions)
  }

  suspend fun getQuestionsForTest(testId: String): List<TestQuestion> = withContext(Dispatchers.IO) {
    val questions = questionDao.getQuestionsForTest(testId).map { it.toDomain() }
    if (questions.isNotEmpty()) {
      return@withContext questions.take(15)
    }
    val test = testDao.getTestById(testId)?.toDomain()
    val examName = test?.title?.split(" ")?.firstOrNull() ?: "SSC CGL"
    val fallback = questionDao.getRandomQuestionsForExam(examName, "All", 15).map { it.toDomain() }
    if (fallback.size == 15) return@withContext fallback

    SampleExamData.sampleQuestions.take(15).map { it.toDomain() }
  }

  // --- PYQ VAULT QUERIES ---
  suspend fun getPyqYears(exam: String): List<String> = withContext(Dispatchers.IO) {
    val years = questionDao.getAvailableYearsForExam(exam)
    if (years.isEmpty()) listOf("2024", "2023", "2022", "2021", "2020", "2019") else years
  }

  suspend fun getPyqShifts(exam: String, year: String): List<String> = withContext(Dispatchers.IO) {
    val shifts = questionDao.getAvailableShiftsForExam(exam, year)
    if (shifts.isEmpty()) listOf("Shift-1", "Shift-2", "Shift-3") else shifts
  }

  suspend fun getPyqExams(): List<String> = withContext(Dispatchers.IO) {
    ExamRegistry.allExams.map { it.name }
  }

  suspend fun getPyqSubjects(exam: String): List<String> = withContext(Dispatchers.IO) {
    val examDetail = ExamRegistry.findExam(exam)
    examDetail?.subjects ?: listOf("General Intelligence & Reasoning", "Quantitative Aptitude", "English Comprehension", "General Awareness")
  }

  suspend fun queryPyqVault(
    exam: String,
    year: String?,
    shift: String?,
    subject: String?,
    sourceLabel: String?,
    verifiedOnly: Boolean,
    limit: Int = 20,
    offset: Int = 0
  ): List<TestQuestion> = withContext(Dispatchers.IO) {
    val entities = questionDao.getFilteredPyqsPaged(
      exam = if (exam.isEmpty()) "All" else exam,
      year = if (year.isNullOrEmpty()) "All" else year,
      shift = if (shift.isNullOrEmpty()) "All" else shift,
      subject = if (subject.isNullOrEmpty()) "All" else subject,
      sourceLabel = if (sourceLabel.isNullOrEmpty()) "All" else sourceLabel,
      searchQuery = "",
      limit = limit,
      offset = offset
    )
    entities.map { it.toDomain() }
  }

  suspend fun countPyqVault(
    exam: String,
    year: String?,
    shift: String?,
    subject: String?,
    sourceLabel: String?,
    verifiedOnly: Boolean
  ): Int = withContext(Dispatchers.IO) {
    questionDao.getFilteredPyqCount(
      exam = if (exam.isEmpty()) "All" else exam,
      year = if (year.isNullOrEmpty()) "All" else year,
      shift = if (shift.isNullOrEmpty()) "All" else shift,
      subject = if (subject.isNullOrEmpty()) "All" else subject,
      sourceLabel = if (sourceLabel.isNullOrEmpty()) "All" else sourceLabel,
      searchQuery = ""
    )
  }

  suspend fun createPyqDrillTest(
    exam: String,
    year: String?,
    shift: String?,
    subject: String?
  ): Pair<TestItem, List<TestQuestion>> = withContext(Dispatchers.IO) {
    val eligible = questionDao.getFilteredPyqsPaged(
      exam = if (exam.isEmpty()) "All" else exam,
      year = if (year.isNullOrEmpty()) "All" else year,
      shift = if (shift.isNullOrEmpty()) "All" else shift,
      subject = if (subject.isNullOrEmpty()) "All" else subject,
      sourceLabel = "All",
      searchQuery = "",
      limit = 30,
      offset = 0
    ).map { it.toDomain() }

    val selected15 = if (eligible.size >= 15) {
      eligible.shuffled().take(15)
    } else {
      val pad = questionDao.getRandomQuestionsForExam(exam, "All", 30).map { it.toDomain() }
      (eligible + pad).distinctBy { it.contentHash.ifEmpty { it.id } }.take(15)
    }

    val drillTitle = buildString {
      append(exam)
      if (!year.isNullOrEmpty() && year != "All") append(" $year")
      if (!shift.isNullOrEmpty() && shift != "All") append(" $shift")
      append(" 15-Q Drill")
    }

    val testId = "pyq_drill_${System.currentTimeMillis()}"
    val testItem = TestItem(
      id = testId,
      title = drillTitle,
      category = ExamRegistry.findExam(exam)?.category ?: ExamCategory.SSC,
      type = TestType.PYQ_PAPER,
      durationMinutes = 15,
      totalQuestions = 15,
      totalMarks = 30.0f,
      marksPerQuestion = 2.0f,
      negativeMarkingRate = 0.5f,
      isNegativeMarkingEnabled = true,
      isVerified = true,
      subject = subject ?: "All Subjects",
      description = "Real 15-question previous year practice set with official answer-key reference and step-by-step methods.",
      tier = SubscriptionTier.FREE,
      examYear = year ?: "2024",
      examShift = shift ?: "Shift-1"
    )

    testDao.insertTest(testItem.toEntity())
    Pair(testItem, selected15)
  }

  suspend fun importQuestionsFromJson(jsonContent: String): Pair<Int, Int> = withContext(Dispatchers.IO) {
    try {
      val jsonArray = JSONArray(jsonContent)
      var imported = 0
      var skippedDuplicates = 0

      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        val qText = obj.getString("questionText")
        val optionsArr = obj.getJSONArray("options")
        val optA = if (optionsArr.length() > 0) optionsArr.getString(0) else ""
        val optB = if (optionsArr.length() > 1) optionsArr.getString(1) else ""
        val optC = if (optionsArr.length() > 2) optionsArr.getString(2) else ""
        val optD = if (optionsArr.length() > 3) optionsArr.getString(3) else ""

        val hash = ExamQuestionGeneratorService.computeHash(qText, optA, optB, optC, optD)
        if (questionDao.existsByContentHash(hash)) {
          skippedDuplicates++
          continue
        }

        val entity = QuestionEntity(
          id = "imp_${UUID.randomUUID().toString().take(8)}",
          testId = obj.optString("testId", "bank_import"),
          subject = obj.optString("subject", "General"),
          topic = obj.optString("topic", "General"),
          questionText = qText,
          optionA = optA,
          optionB = optB,
          optionC = optC,
          optionD = optD,
          correctOptionIndex = obj.getInt("correctOptionIndex"),
          explanation = obj.optString("explanation", "Standard verified solution."),
          hindiQuestionText = obj.optString("hindiQuestionText", ""),
          hindiOptionA = "",
          hindiOptionB = "",
          hindiOptionC = "",
          hindiOptionD = "",
          hindiExplanation = "",
          difficulty = obj.optString("difficulty", "MEDIUM"),
          source = obj.optString("source", "Verified Import"),
          year = obj.optString("year", "2024"),
          shift = obj.optString("shift", "Shift-1"),
          paper = obj.optString("paper", "Paper-1"),
          officialAnswerKeyRef = obj.optString("officialAnswerKeyRef", "Official Board Master Key"),
          isVerified = true,
          targetExam = obj.optString("targetExam", "SSC CGL"),
          stage = obj.optString("stage", "Tier-1"),
          language = "ENGLISH",
          sourceLabel = obj.optString("sourceLabel", "OFFICIAL_VERIFIED_PYQ"),
          contentHash = hash,
          createdAt = System.currentTimeMillis()
        )
        questionDao.insertQuestion(entity)
        imported++
      }
      Pair(imported, skippedDuplicates)
    } catch (e: Exception) {
      Pair(0, 0)
    }
  }

  suspend fun generateAiQuestionsForBank(
    examName: String,
    category: String,
    subject: String,
    count: Int = 5,
    difficulty: Difficulty = Difficulty.MEDIUM
  ): List<QuestionEntity> = withContext(Dispatchers.IO) {
    val examDetail = ExamRegistry.allExams.firstOrNull { it.id.equals(examName, ignoreCase = true) || it.name.equals(examName, ignoreCase = true) }
      ?: ExamRegistry.allExams.firstOrNull { it.category.name.equals(category, ignoreCase = true) }
      ?: ExamRegistry.allExams.first()

    val result = aiGenerator.generateQuestionBatch(
      examDetail = examDetail,
      stage = "Tier-1",
      subject = subject,
      topic = subject,
      difficulty = difficulty.name,
      language = "ENGLISH",
      batchSize = count,
      existingHashesChecker = { hash -> questionDao.existsByContentHash(hash) }
    )

    when (result) {
      is com.example.data.ai.GenerationResult.Success -> {
        questionDao.insertQuestions(result.questions)
        result.questions
      }
      is com.example.data.ai.GenerationResult.Error -> {
        val fallback = aiGenerator.generateCurriculumFallbackBatch(
          exam = examDetail,
          stage = "Tier-1",
          subject = subject,
          topic = subject,
          difficulty = difficulty.name,
          language = "ENGLISH",
          count = count
        )
        val entities = fallback.map { it.toEntity() }
        questionDao.insertQuestions(entities)
        entities
      }
    }
  }

  suspend fun saveActiveSession(
    testId: String,
    currentIndex: Int,
    timeRemainingSeconds: Int,
    answers: Map<String, Int?>,
    markedForReview: Set<String>
  ) = withContext(Dispatchers.IO) {
    val answersJson = JSONObject()
    answers.forEach { (qId, opt) ->
      if (opt != null) answersJson.put(qId, opt)
    }
    val reviewArr = JSONArray(markedForReview.toList())

    activeSessionDao.saveActiveSession(
      ActiveTestSessionEntity(
        testId = testId,
        userId = 1L,
        timeRemainingSeconds = timeRemainingSeconds,
        currentIndex = currentIndex,
        answersSummary = answersJson.toString(),
        markedReviewSummary = reviewArr.toString(),
        applyNegativeMarking = true,
        lastSavedTimestamp = System.currentTimeMillis()
      )
    )
  }

  suspend fun getActiveSession(testId: String): ActiveTestSessionEntity? = withContext(Dispatchers.IO) {
    activeSessionDao.getActiveSession(testId, 1L)
  }

  suspend fun clearActiveSession(testId: String) = withContext(Dispatchers.IO) {
    activeSessionDao.deleteActiveSession(testId, 1L)
  }

  suspend fun submitTest(
    testItem: TestItem,
    questions: List<TestQuestion>,
    answers: Map<String, Int?>,
    timeSpentSeconds: Int
  ): TestResult = withContext(Dispatchers.IO) {
    var correctCount = 0
    var incorrectCount = 0
    var unattemptedCount = 0

    val wrongQuestions = mutableListOf<WrongAnswerEntity>()

    questions.forEach { q ->
      val userOpt = answers[q.id]
      when {
        userOpt == null -> {
          unattemptedCount++
        }
        userOpt == q.correctOptionIndex -> {
          correctCount++
        }
        else -> {
          incorrectCount++
          wrongQuestions.add(
            WrongAnswerEntity(
              id = "wa_${UUID.randomUUID().toString().take(8)}",
              userId = 1L,
              questionId = q.id,
              testId = testItem.id,
              userWrongOption = userOpt,
              correctOption = q.correctOptionIndex,
              recordedAt = System.currentTimeMillis(),
              isResolved = false
            )
          )
        }
      }
    }

    val positiveMarks = correctCount * testItem.marksPerQuestion
    val negativeDeduction = if (testItem.isNegativeMarkingEnabled) {
      incorrectCount * testItem.negativeMarkingRate
    } else 0f

    val totalMarksObtained = maxOf(0f, positiveMarks - negativeDeduction)
    val attempted = correctCount + incorrectCount
    val accuracy = if (attempted > 0) (correctCount.toFloat() / attempted) * 100f else 0f
    val percentile = minOf(99.4f, maxOf(40.0f, (accuracy * 0.7f) + (totalMarksObtained / testItem.totalMarks * 30f)))

    val attemptId = "att_${UUID.randomUUID().toString().take(8)}"
    val answersJson = JSONObject()
    answers.forEach { (qId, opt) ->
      if (opt != null) answersJson.put(qId, opt)
    }

    val attemptEntity = TestAttemptEntity(
      attemptId = attemptId,
      userId = 1L,
      testId = testItem.id,
      testTitle = testItem.title,
      category = testItem.category.displayName,
      score = totalMarksObtained,
      totalMarks = testItem.totalMarks,
      accuracy = accuracy,
      totalQuestions = questions.size,
      correctCount = correctCount,
      incorrectCount = incorrectCount,
      unattemptedCount = unattemptedCount,
      timeSpentSeconds = timeSpentSeconds,
      totalTimeSeconds = testItem.durationMinutes * 60,
      negativeMarkingApplied = testItem.isNegativeMarkingEnabled,
      negativeMarksDeducted = negativeDeduction,
      attemptedAt = System.currentTimeMillis(),
      answersSummary = answersJson.toString()
    )

    attemptDao.insertAttempt(attemptEntity)
    wrongQuestions.forEach { wa ->
      wrongAnswerDao.insertWrongAnswer(wa)
    }
    clearActiveSession(testItem.id)

    TestResult(
      attemptId = attemptId,
      testId = testItem.id,
      testTitle = testItem.title,
      category = testItem.category,
      totalQuestions = questions.size,
      correctAnswersCount = correctCount,
      incorrectAnswersCount = incorrectCount,
      unattemptedCount = unattemptedCount,
      marksObtained = totalMarksObtained,
      totalMarks = testItem.totalMarks,
      accuracyPercentage = accuracy,
      timeSpentSeconds = timeSpentSeconds,
      totalTimeSeconds = testItem.durationMinutes * 60,
      negativeMarkingApplied = testItem.isNegativeMarkingEnabled,
      negativeMarksDeducted = negativeDeduction,
      percentileEstimate = percentile,
      dateTimestamp = System.currentTimeMillis(),
      questions = questions,
      userAnswers = answers
    )
  }

  suspend fun toggleBookmark(question: TestQuestion): Boolean = withContext(Dispatchers.IO) {
    val isMarked = bookmarkDao.isBookmarked(question.id, 1L)
    if (isMarked) {
      bookmarkDao.deleteBookmark(question.id, 1L)
      false
    } else {
      bookmarkDao.insertBookmark(
        BookmarkEntity(
          questionId = question.id,
          userId = 1L,
          savedAt = System.currentTimeMillis()
        )
      )
      true
    }
  }

  suspend fun getBookmarkedQuestions(): List<TestQuestion> = withContext(Dispatchers.IO) {
    val bookmarks = bookmarkDao.getBookmarksForUser(1L).first()
    val qList = mutableListOf<TestQuestion>()
    for (b in bookmarks) {
      questionDao.getQuestionById(b.questionId)?.let { qList.add(it.toDomain()) }
    }
    qList
  }

  suspend fun getWrongAnswers(): List<Pair<TestQuestion, Int>> = withContext(Dispatchers.IO) {
    val wrongEntities = wrongAnswerDao.getUnresolvedWrongAnswers(1L).first()
    val list = mutableListOf<Pair<TestQuestion, Int>>()
    for (w in wrongEntities) {
      questionDao.getQuestionById(w.questionId)?.let { q ->
        list.add(Pair(q.toDomain(), w.userWrongOption))
      }
    }
    list
  }

  // Domain conversions
  fun TestEntity.toDomain() = TestItem(
    id = id,
    title = title,
    category = ExamCategory.fromId(category),
    type = when (type) {
      "SECTIONAL_TEST" -> TestType.SECTIONAL_TEST
      "TOPIC_TEST" -> TestType.TOPIC_TEST
      "PYQ_PAPER" -> TestType.PYQ_PAPER
      "DAILY_QUIZ" -> TestType.DAILY_QUIZ
      "PRACTICE_SET" -> TestType.PRACTICE_SET
      else -> TestType.FULL_MOCK
    },
    durationMinutes = durationMinutes,
    totalQuestions = totalQuestions,
    totalMarks = totalMarks,
    marksPerQuestion = marksPerQuestion,
    negativeMarkingRate = negativeMarkingRate,
    isNegativeMarkingEnabled = true,
    isVerified = isVerified,
    subject = subject,
    description = description,
    tier = when (tier) {
      "PRO" -> SubscriptionTier.PRO
      "PLUS" -> SubscriptionTier.PLUS
      else -> SubscriptionTier.FREE
    },
    attemptsCount = attemptsCount,
    examYear = examYear,
    examShift = examShift
  )

  fun TestItem.toEntity() = TestEntity(
    id = id,
    title = title,
    category = category.id,
    type = type.name,
    durationMinutes = durationMinutes,
    totalQuestions = totalQuestions,
    totalMarks = totalMarks,
    marksPerQuestion = marksPerQuestion,
    negativeMarkingRate = negativeMarkingRate,
    isVerified = isVerified,
    subject = subject,
    description = description,
    tier = tier.name,
    attemptsCount = attemptsCount,
    examYear = examYear,
    examShift = examShift
  )

  fun QuestionEntity.toDomain() = TestQuestion(
    id = id,
    testId = testId,
    subject = subject,
    topic = topic,
    questionText = questionText,
    hindiQuestionText = hindiQuestionText,
    options = listOf(optionA, optionB, optionC, optionD),
    hindiOptions = if (hindiOptionA.isNotBlank()) listOf(hindiOptionA, hindiOptionB, hindiOptionC, hindiOptionD) else emptyList(),
    correctOptionIndex = correctOptionIndex,
    explanation = explanation,
    hindiExplanation = hindiExplanation,
    difficulty = when (difficulty) {
      "EASY" -> Difficulty.EASY
      "HARD" -> Difficulty.HARD
      else -> Difficulty.MEDIUM
    },
    source = source,
    year = year,
    shift = shift,
    paper = paper,
    officialAnswerKeyRef = officialAnswerKeyRef,
    isVerified = isVerified,
    sourceLabel = sourceLabel,
    contentHash = contentHash,
    targetExam = targetExam,
    stage = stage
  )

  fun TestQuestion.toEntity() = QuestionEntity(
    id = id,
    testId = testId,
    subject = subject,
    topic = topic,
    questionText = questionText,
    optionA = options.getOrElse(0) { "" },
    optionB = options.getOrElse(1) { "" },
    optionC = options.getOrElse(2) { "" },
    optionD = options.getOrElse(3) { "" },
    correctOptionIndex = correctOptionIndex,
    explanation = explanation,
    hindiQuestionText = hindiQuestionText,
    hindiOptionA = hindiOptions.getOrElse(0) { "" },
    hindiOptionB = hindiOptions.getOrElse(1) { "" },
    hindiOptionC = hindiOptions.getOrElse(2) { "" },
    hindiOptionD = hindiOptions.getOrElse(3) { "" },
    hindiExplanation = hindiExplanation,
    difficulty = difficulty.name,
    source = source,
    year = year,
    shift = shift,
    paper = paper,
    officialAnswerKeyRef = officialAnswerKeyRef,
    isVerified = isVerified,
    targetExam = targetExam,
    stage = stage,
    language = "ENGLISH",
    sourceLabel = sourceLabel,
    contentHash = contentHash,
    createdAt = System.currentTimeMillis()
  )
}
