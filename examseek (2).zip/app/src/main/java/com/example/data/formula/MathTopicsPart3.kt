package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object MathTopicsPart3 {
  val topics: List<FormulaTopic> = listOf(
    // 21. Geometry
    FormulaTopic(
      id = "math_geometry",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Pure Geometry",
      title = "Lines, Angles & Polygons",
      hindiTitle = "रेखाएं, कोण एवं बहुभुज",
      summary = "Complementary/supplementary angles, parallel lines transversals, and interior/exterior angles of polygons.",
      coreFormula = "Sum of interior angles of n-sided polygon = (n - 2) * 180°\nEach interior angle of regular polygon = [(n - 2) * 180°] / n\nSum of all exterior angles = 360°\nNumber of diagonals = [n(n - 3)] / 2",
      symbolExplanations = listOf(
        "n" to "Number of sides of polygon (n >= 3).",
        "Complementary angles" to "Two angles whose sum is 90°.",
        "Supplementary angles" to "Two angles whose sum is 180°."
      ),
      importantIdentities = listOf(
        "Vertically opposite angles are equal.",
        "Alternate interior angles of parallel lines cut by transversal are equal."
      ),
      shortcutsAndTips = listOf(
        "Each exterior angle of regular polygon = 360° / n. Knowing this gives n immediately: n = 360° / ext_angle."
      ),
      commonMistakes = listOf(
        "Confusing complementary (90°) and supplementary (180°)."
      ),
      solvedExamples = listOf(
        createExample(
          "geo_ex1",
          "Find the number of diagonals in a regular octagon (8-sided polygon).",
          "एक नियमित अष्टभुज में विकर्णों की संख्या ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula for diagonals = [n(n - 3)] / 2.",
            "Step 2: Here n = 8.",
            "Step 3: Diagonals = [8 * (8 - 3)] / 2 = [8 * 5] / 2 = 20."
          ),
          "20",
          "Apply n(n-3)/2."
        ),
        createExample(
          "geo_ex2",
          "If each interior angle of a regular polygon is 144°, find the number of sides.",
          "यदि एक सम बहुभुज का प्रत्येक आंतरिक कोण 144° है, तो भुजाओं की संख्या ज्ञात कीजिए।",
          listOf(
            "Step 1: Each exterior angle = 180° - 144° = 36°.",
            "Step 2: Number of sides n = 360° / Exterior angle.",
            "Step 3: n = 360° / 36° = 10 (Decagon)."
          ),
          "10",
          "Always calculate exterior angle first."
        ),
        createExample(
          "geo_ex3",
          "An angle is 24° more than its complement. Find the measure of the angle.",
          "एक कोण अपने कोटिपूरक कोण से 24° अधिक है। कोण का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: Let the angle be x. Its complement is 90° - x.",
            "Step 2: x = (90° - x) + 24°.",
            "Step 3: 2x = 114° => x = 57°."
          ),
          "57°",
          "Complementary sum = 90°."
        )
      ),
      practiceMcqs = listOf(
        createMcq("geo_q1", "Number of diagonals in a 12-sided polygon is:", "", "54", "48", "60", "52", 0, "12 * 9 / 2 = 54."),
        createMcq("geo_q2", "If an angle is equal to its supplement, the angle is:", "", "90°", "45°", "180°", "60°", 0, "x + x = 180° => 2x = 180° => x = 90°."),
        createMcq("geo_q3", "Interior angle of a regular hexagon is:", "", "120°", "108°", "135°", "150°", 0, "Exterior = 360/6 = 60°. Interior = 180 - 60 = 120°."),
        createMcq("geo_q4", "Sum of interior angles of a pentagon is:", "", "540°", "360°", "720°", "180°", 0, "(5 - 2) * 180° = 3 * 180° = 540°."),
        createMcq("geo_q5", "Ratio of interior to exterior angle of a regular polygon is 7:2. Number of sides is:", "", "9", "8", "10", "12", 0, "7x + 2x = 180 => 9x = 180 => x = 20. Exterior = 40°. Sides = 360 / 40 = 9."),
        createMcq("geo_q6", "Number of sides in polygon with 35 diagonals is:", "", "10", "9", "11", "12", 0, "n(n-3)/2 = 35 => n(n-3) = 70 = 10 * 7 => n = 10."),
        createMcq("geo_q7", "Two parallel lines are cut by transversal. If one interior angle is 65°, its consecutive interior angle is:", "", "115°", "65°", "90°", "125°", 0, "Consecutive interior angles sum to 180°. 180 - 65 = 115°."),
        createMcq("geo_q8", "An angle is 1/4 of its supplementary angle. The angle is:", "", "36°", "45°", "30°", "72°", 0, "x = (180 - x)/4 => 5x = 180 => x = 36°."),
        createMcq("geo_q9", "Each exterior angle of regular polygon is 45°. The polygon is:", "", "Octagon", "Nonagon", "Heptagon", "Hexagon", 0, "n = 360 / 45 = 8 (Octagon)."),
        createMcq("geo_q10", "If difference between interior and exterior angle of regular polygon is 60°, number of sides is:", "", "6", "8", "5", "10", 0, "I - E = 60, I + E = 180 => 2E = 120 => E = 60°. n = 360 / 60 = 6.")
      )
    ),
    // 22. Triangles
    FormulaTopic(
      id = "math_triangles",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Pure Geometry",
      title = "Triangles & Centers",
      hindiTitle = "त्रिभुज एवं इसके केंद्र",
      summary = "Pythagoras theorem, triangle similarity, congruence, incenter, circumcenter, centroid, and orthocenter.",
      coreFormula = "Pythagoras: c² = a² + b²\nHeron's Formula: Area = √[s(s - a)(s - b)(s - c)], where s = (a + b + c)/2\nInradius: r = Area / s | Circumradius: R = (abc) / (4 * Area)\nEquilateral Area = (√3 / 4) * a²\nAngle at Incenter: ∠BIC = 90° + (∠BAC / 2)",
      symbolExplanations = listOf(
        "s" to "Semi-perimeter of triangle.",
        "Centroid (G)" to "Intersection of medians. Divides median in ratio 2:1 from vertex.",
        "Incenter (I)" to "Intersection of angle bisectors. Center of inscribed circle.",
        "Circumcenter (O)" to "Intersection of perpendicular bisectors of sides.",
        "Orthocenter (H)" to "Intersection of altitudes."
      ),
      importantIdentities = listOf(
        "In right-angled triangle, circumcenter lies at midpoint of hypotenuse (R = c/2).",
        "Orthocenter of right triangle lies at right-angled vertex.",
        "For equilateral triangle: r = a / (2√3) and R = a / √3 (R = 2r)."
      ),
      shortcutsAndTips = listOf(
        "Angle at Circumcenter: ∠BOC = 2 * ∠A.",
        "Angle at Orthocenter: ∠BHC = 180° - ∠A."
      ),
      commonMistakes = listOf(
        "Confusing incenter angle ∠BIC = 90° + A/2 with circumcenter angle ∠BOC = 2A."
      ),
      solvedExamples = listOf(
        createExample(
          "tri_ex1",
          "In ΔABC, I is the incenter. If ∠BAC = 70°, find ∠BIC.",
          "ΔABC में I अंतःकेंद्र है। यदि ∠BAC = 70° है, तो ∠BIC ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula for angle at incenter: ∠BIC = 90° + (∠A / 2).",
            "Step 2: Here ∠A = 70°.",
            "Step 3: ∠BIC = 90° + (70° / 2) = 90° + 35° = 125°."
          ),
          "125°",
          "∠BIC = 90° + A/2."
        ),
        createExample(
          "tri_ex2",
          "Find the area of an equilateral triangle whose side is 8 cm.",
          "8 सेमी भुजा वाले समबाहु त्रिभुज का क्षेत्रफल ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: Area = (√3 / 4) * a².",
            "Step 2: Area = (√3 / 4) * 8² = (√3 / 4) * 64 = 16√3 cm²."
          ),
          "16√3 cm²",
          "Equilateral area = (√3/4) a²."
        ),
        createExample(
          "tri_ex3",
          "The sides of a triangle are 5 cm, 12 cm, and 13 cm. Find its inradius.",
          "एक त्रिभुज की भुजाएं 5 सेमी, 12 सेमी और 13 सेमी हैं। इसकी अंतःत्रिज्या ज्ञात कीजिए।",
          listOf(
            "Step 1: Check Pythagorean triplet: 5² + 12² = 25 + 144 = 169 = 13² (Right-angled triangle).",
            "Step 2: For right triangle, inradius r = (a + b - c) / 2.",
            "Step 3: r = (5 + 12 - 13) / 2 = 4 / 2 = 2 cm."
          ),
          "2 cm",
          "Shortcut for right triangle: r = (Perpendicular + Base - Hypotenuse) / 2."
        )
      ),
      practiceMcqs = listOf(
        createMcq("tri_q1", "In right triangle with sides 6, 8, 10, the circumradius is:", "", "5 cm", "4 cm", "6 cm", "3 cm", 0, "Circumradius = Hypotenuse / 2 = 10 / 2 = 5 cm."),
        createMcq("tri_q2", "Centroid divides each median in the ratio:", "", "2:1", "1:2", "3:1", "1:1", 0, "Centroid divides median in ratio 2:1 from vertex to base."),
        createMcq("tri_q3", "In ΔABC, O is circumcenter. If ∠BAC = 50°, then ∠BOC is:", "", "100°", "115°", "130°", "80°", 0, "∠BOC = 2 * ∠A = 2 * 50° = 100°."),
        createMcq("tri_q4", "Area of triangle with sides 13, 14, 15 cm is:", "", "84 cm²", "80 cm²", "90 cm²", "72 cm²", 0, "s = 21. Area = √(21*8*7*6) = 84 cm²."),
        createMcq("tri_q5", "Height of equilateral triangle of side 6 cm is:", "", "3√3 cm", "3 cm", "6√3 cm", "4√3 cm", 0, "h = (√3/2) * a = (√3/2) * 6 = 3√3 cm."),
        createMcq("tri_q6", "In ΔABC, D and E are midpoints of AB and AC. If BC = 12 cm, DE is:", "", "6 cm", "4 cm", "8 cm", "9 cm", 0, "Midpoint theorem: DE = 1/2 BC = 6 cm."),
        createMcq("tri_q7", "If ratio of areas of two similar triangles is 16:25, ratio of corresponding sides is:", "", "4:5", "16:25", "2:√5", "8:12.5", 0, "Ratio of sides = √(Ratio of areas) = √16 : √25 = 4 : 5."),
        createMcq("tri_q8", "If the angles of a triangle are in ratio 2:3:5, the triangle is:", "", "Right-angled", "Equilateral", "Obtuse-angled", "Isosceles", 0, "2x+3x+5x = 180 => 10x = 180 => x = 18°. Angles are 36°, 54°, 90° (Right-angled)."),
        createMcq("tri_q9", "In ΔABC, H is orthocenter. If ∠A = 70°, ∠BHC is:", "", "110°", "125°", "140°", "135°", 0, "∠BHC = 180° - ∠A = 180° - 70° = 110°."),
        createMcq("tri_q10", "Ratio of inradius to circumradius for equilateral triangle is:", "", "1:2", "1:3", "1:√2", "2:3", 0, "r = a/(2√3), R = a/√3. Ratio r : R = 1 : 2.")
      )
    ),
    // 23. Circles
    FormulaTopic(
      id = "math_circles",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Pure Geometry",
      title = "Circles & Tangents",
      hindiTitle = "वृत्त एवं स्पर्श रेखाएं",
      summary = "Chords, secants, tangents, alternate segment theorem, and cyclic quadrilaterals.",
      coreFormula = "Tangent Secant Theorem: PT² = PA * PB\nIntersecting Chords: PA * PB = PC * PD\nDirect Common Tangent (DCT) = √[d² - (r1 - r2)²]\nTransverse Common Tangent (TCT) = √[d² - (r1 + r2)²]\nCyclic Quadrilateral: ∠A + ∠C = 180°",
      symbolExplanations = listOf(
        "PT" to "Length of tangent from external point P to point of tangency T.",
        "PA, PB" to "Segments of secant from P passing through A and B.",
        "d" to "Distance between centers of two circles.",
        "r1, r2" to "Radii of two circles."
      ),
      importantIdentities = listOf(
        "Angle subtended by an arc at center is twice the angle subtended at circumference: ∠AOB = 2 * ∠APB.",
        "Angle in a semicircle is a right angle (90°).",
        "Angles in the same segment of a circle are equal."
      ),
      shortcutsAndTips = listOf(
        "DCT is always longer than TCT."
      ),
      commonMistakes = listOf(
        "Using (r1 - r2) in TCT formula instead of (r1 + r2)."
      ),
      solvedExamples = listOf(
        createExample(
          "circ_ex1",
          "From external point P, tangent PT of length 12 cm is drawn to a circle. A secant PAB passes through the center. If PA = 8 cm, find chord AB.",
          "बाह्य बिंदु P से 12 सेमी स्पर्श रेखा PT खींची गई है। एक छेदक रेखा PAB केंद्र से गुजरती है। यदि PA = 8 सेमी, तो जीवा AB ज्ञात कीजिए।",
          listOf(
            "Step 1: Apply theorem: PT² = PA * PB.",
            "Step 2: 12² = 8 * PB => 144 = 8 * PB => PB = 18 cm.",
            "Step 3: AB = PB - PA = 18 - 8 = 10 cm."
          ),
          "10 cm",
          "Tangent-secant power of a point."
        ),
        createExample(
          "circ_ex2",
          "Two circles of radii 8 cm and 3 cm have their centers 13 cm apart. Find length of direct common tangent (DCT).",
          "8 सेमी और 3 सेमी त्रिज्या वाले दो वृत्तों के केंद्र 13 सेमी दूरी पर हैं। उभयनिष्ठ अनुस्पर्श रेखा (DCT) की लंबाई ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: DCT = √[d² - (r1 - r2)²].",
            "Step 2: d = 13, r1 - r2 = 8 - 3 = 5.",
            "Step 3: DCT = √[13² - 5²] = √(169 - 25) = √144 = 12 cm."
          ),
          "12 cm",
          "DCT uses difference of radii."
        ),
        createExample(
          "circ_ex3",
          "In a cyclic quadrilateral ABCD, ∠A = (2x + 4)° and ∠C = (3x + 1)°. Find value of x.",
          "चक्रीय चतुर्भुज ABCD में, ∠A = 2x + 4 और ∠C = 3x + 1 है। x का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: Opposite angles of cyclic quadrilateral sum to 180°: ∠A + ∠C = 180°.",
            "Step 2: (2x + 4) + (3x + 1) = 180 => 5x + 5 = 180.",
            "Step 3: 5x = 175 => x = 35."
          ),
          "35",
          "Sum of opposite angles is 180°."
        )
      ),
      practiceMcqs = listOf(
        createMcq("circ_q1", "Distance between centers of two circles is 10 cm, radii are 4 cm and 2 cm. Transverse common tangent (TCT) is:", "", "8 cm", "6 cm", "9 cm", "7 cm", 0, "TCT = √[10² - (4+2)²] = √(100 - 36) = √64 = 8 cm."),
        createMcq("circ_q2", "A chord of length 16 cm is at distance 6 cm from center. Radius of circle is:", "", "10 cm", "8 cm", "12 cm", "9 cm", 0, "r = √(6² + 8²) = √(36 + 64) = 10 cm."),
        createMcq("circ_q3", "Angle in a major segment is always:", "", "Acute", "Right", "Obtuse", "Straight", 0, "Major segment angle is acute (<90°); minor segment angle is obtuse (>90°)."),
        createMcq("circ_q4", "Two chords AB and CD intersect at P inside circle. If AP=4, PB=6, CP=3, find PD:", "", "8 cm", "7 cm", "9 cm", "6 cm", 0, "AP * PB = CP * PD => 4 * 6 = 3 * PD => PD = 8 cm."),
        createMcq("circ_q5", "If radii of two concentric circles are 5 cm and 3 cm, length of chord of larger circle tangent to smaller circle is:", "", "8 cm", "6 cm", "10 cm", "4 cm", 0, "Half chord = √(5² - 3²) = 4 cm. Full chord = 2 * 4 = 8 cm."),
        createMcq("circ_q6", "Number of common tangents that can be drawn to two externally touching circles is:", "", "3", "2", "4", "1", 0, "Two direct and one transverse common tangent at point of contact = 3."),
        createMcq("circ_q7", "If two circles touch internally, number of common tangents is:", "", "1", "2", "0", "3", 0, "Only 1 common tangent can be drawn at the point of contact."),
        createMcq("circ_q8", "Angle subtended by diameter at circumference is:", "", "90°", "180°", "60°", "45°", 0, "Angle in semicircle is 90°."),
        createMcq("circ_q9", "In cyclic quadrilateral ABCD, if ∠B = 75°, then ∠D is:", "", "105°", "115°", "95°", "75°", 0, "Opposite angles sum to 180°: 180 - 75 = 105°."),
        createMcq("circ_q10", "A circle has radius 13 cm. Length of tangent from a point 17 cm away from center is:", "", "√120 cm", "12 cm", "10 cm", "√150 cm", 0, "PT = √(17² - 13²) = √(289 - 169) = √120 = 2√30 cm.")
      )
    ),
    // 24. Mensuration 2D
    FormulaTopic(
      id = "math_mensuration_2d",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Mensuration",
      title = "Mensuration 2D (Plane Figures)",
      hindiTitle = "क्षेत्रमिति 2D",
      summary = "Area and perimeter of square, rectangle, parallelogram, rhombus, trapezium, circle, and pathway areas.",
      coreFormula = "Rectangle: Area = l * b, Perimeter = 2(l + b), Diagonal = √(l² + b²)\nSquare: Area = a² = d²/2, Perimeter = 4a\nTrapezium: Area = 1/2 * (a + b) * h\nRhombus: Area = 1/2 * d1 * d2, Side = 1/2 * √(d1² + d2²)\nCircle: Area = π * r², Circumference = 2 * π * r",
      symbolExplanations = listOf(
        "a, b" to "Parallel sides of trapezium or sides of rectangle.",
        "h" to "Perpendicular distance between parallel sides.",
        "d1, d2" to "Diagonals of rhombus (intersect at 90°)."
      ),
      importantIdentities = listOf(
        "Area of pathway inside rectangle of dimensions L * B of width w = 2w(L + B - 2w)",
        "Area of pathway outside rectangle = 2w(L + B + 2w)",
        "Area of crossed pathways = w(L + B - w)"
      ),
      shortcutsAndTips = listOf(
        "If diagonal of square increases by x%, its area increases by (2x + x²/100)%."
      ),
      commonMistakes = listOf(
        "Forgetting that rhombus diagonals bisect each other at right angles."
      ),
      solvedExamples = listOf(
        createExample(
          "m2_ex1",
          "The diagonals of a rhombus are 16 cm and 12 cm. Find its area and perimeter.",
          "एक समचतुर्भुज के विकर्ण 16 सेमी और 12 सेमी हैं। इसका क्षेत्रफल और परिमाप ज्ञात कीजिए।",
          listOf(
            "Step 1: Area = 1/2 * d1 * d2 = 1/2 * 16 * 12 = 96 cm².",
            "Step 2: Diagonals bisect at 90° into halves: 8 cm and 6 cm.",
            "Step 3: Side a = √(8² + 6²) = √(64 + 36) = 10 cm.",
            "Step 4: Perimeter = 4 * a = 4 * 10 = 40 cm."
          ),
          "96 cm² and 40 cm",
          "Rhombus side = 1/2 * √(d1² + d2²)."
        ),
        createExample(
          "m2_ex2",
          "A lawn 60 m by 40 m has two roads each 5 m wide running through its center, one parallel to length and other to breadth. Find area of roads.",
          "60 मी * 40 मी के एक लॉन के केंद्र से होकर 5 मी चौड़े दो रास्ते जाते हैं। रास्तों का क्षेत्रफल ज्ञात कीजिए।",
          listOf(
            "Step 1: Road along length = 60 * 5 = 300 m².",
            "Step 2: Road along breadth = 40 * 5 = 200 m².",
            "Step 3: Common central square counted twice = 5 * 5 = 25 m².",
            "Step 4: Net area = 300 + 200 - 25 = 475 m²."
          ),
          "475 m²",
          "Formula: w(L + B - w) = 5(60 + 40 - 5) = 475 m²."
        ),
        createExample(
          "m2_ex3",
          "Find the area of a trapezium whose parallel sides are 14 cm and 20 cm, and distance between them is 8 cm.",
          "एक समलंब चतुर्भुज का क्षेत्रफल ज्ञात कीजिए जिसकी समानांतर भुजाएं 14 सेमी और 20 सेमी तथा ऊंचाई 8 सेमी है।",
          listOf(
            "Step 1: Formula: Area = 1/2 * (a + b) * h.",
            "Step 2: Area = 1/2 * (14 + 20) * 8 = 1/2 * 34 * 8 = 136 cm²."
          ),
          "136 cm²",
          "Half sum of parallel sides times height."
        )
      ),
      practiceMcqs = listOf(
        createMcq("m2_q1", "Area of square whose diagonal is 10 cm is:", "", "50 cm²", "100 cm²", "25 cm²", "75 cm²", 0, "Area = d²/2 = 100/2 = 50 cm²."),
        createMcq("m2_q2", "If radius of circle is increased by 50%, area increases by:", "", "125%", "100%", "150%", "75%", 0, "50 + 50 + (50*50)/100 = 125%."),
        createMcq("m2_q3", "Side of rhombus is 5 cm and one diagonal is 8 cm. Other diagonal is:", "", "6 cm", "8 cm", "10 cm", "7 cm", 0, "Half diagonal = 4. Other half = √(5² - 4²) = 3. Full diagonal = 6 cm."),
        createMcq("m2_q4", "A wire bent into square encloses 121 cm². If bent into circle, area is:", "", "154 cm²", "144 cm²", "160 cm²", "132 cm²", 0, "Side = 11 => perimeter = 44. 2πr = 44 => r = 7. Area = 22/7 * 49 = 154 cm²."),
        createMcq("m2_q5", "Area of ring between two concentric circles of radii 14 cm and 7 cm is:", "", "462 cm²", "440 cm²", "484 cm²", "500 cm²", 0, "π(14² - 7²) = 22/7 * 147 = 462 cm²."),
        createMcq("m2_q6", "Perimeter of semicircle of radius 7 cm is:", "", "36 cm", "22 cm", "44 cm", "29 cm", 0, "Perimeter = πr + 2r = 22 + 14 = 36 cm."),
        createMcq("m2_q7", "Ratio of area of incircle to circumcircle of square is:", "", "1:2", "1:4", "2:3", "1:√2", 0, "r = a/2, R = a/√2. Ratio = (a²/4) : (a²/2) = 1 : 2."),
        createMcq("m2_q8", "Length of rectangle is twice its breadth. If perimeter is 60 cm, area is:", "", "200 cm²", "180 cm²", "220 cm²", "150 cm²", 0, "2(2b + b) = 60 => 6b = 60 => b = 10, l = 20. Area = 200 cm²."),
        createMcq("m2_q9", "Area of parallelogram with base 15 cm and altitude 8 cm is:", "", "120 cm²", "60 cm²", "150 cm²", "90 cm²", 0, "Area = Base * Height = 15 * 8 = 120 cm²."),
        createMcq("m2_q10", "Number of revolutions made by wheel of diameter 70 cm in covering 1.1 km is:", "", "500", "400", "600", "250", 0, "Circumference = 22/7 * 0.7 m = 2.2 m. Revolutions = 1100 / 2.2 = 500.")
      )
    ),
    // 25. Mensuration 3D
    FormulaTopic(
      id = "math_mensuration_3d",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Mensuration",
      title = "Mensuration 3D (Solid Figures)",
      hindiTitle = "क्षेत्रमिति 3D",
      summary = "Volume, curved/total surface area of cuboid, cube, cylinder, cone, sphere, hemisphere, and melting-recasting.",
      coreFormula = "Cuboid: V = l * b * h, TSA = 2(lb + bh + hl), Diagonal = √(l² + b² + h²)\nCube: V = a³, TSA = 6a², Diagonal = a√3\nCylinder: V = πr²h, CSA = 2πrh, TSA = 2πr(h + r)\nCone: V = 1/3 πr²h, CSA = πrl, Slant height l = √(r² + h²)\nSphere: V = 4/3 πr³, Surface Area = 4πr²\nHemisphere: V = 2/3 πr³, CSA = 2πr², TSA = 3πr²",
      symbolExplanations = listOf(
        "r" to "Radius of circular base.",
        "h" to "Height of solid.",
        "l" to "Slant height of cone.",
        "TSA / CSA" to "Total Surface Area / Curved Surface Area."
      ),
      importantIdentities = listOf(
        "Melting and Recasting: Volume remains conserved: n * V_small = V_large.",
        "Longest rod placed in room = Diagonal of cuboid = √(l² + b² + h²)."
      ),
      shortcutsAndTips = listOf(
        "Ratio of volumes of two similar solids is the cube of ratio of their linear dimensions."
      ),
      commonMistakes = listOf(
        "Using 2πr² for total surface area of solid hemisphere (it is 3πr² including the flat circular base)."
      ),
      solvedExamples = listOf(
        createExample(
          "m3_ex1",
          "Find the length of the longest rod that can be placed in a room 12 m long, 9 m broad, and 8 m high.",
          "12 मी लंबे, 9 मी चौड़े और 8 मी ऊंचे कमरे में रखी जा सकने वाली सबसे लंबी छड़ की लंबाई ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: Diagonal = √(l² + b² + h²).",
            "Step 2: Diagonal = √(12² + 9² + 8²) = √(144 + 81 + 64) = √289 = 17 m."
          ),
          "17 m",
          "Room diagonal formula gives maximum rod length."
        ),
        createExample(
          "m3_ex2",
          "A solid metallic sphere of radius 6 cm is melted and recast into small spheres of radius 2 cm each. How many such spheres can be made?",
          "6 सेमी त्रिज्या वाले एक धातु के गोले को पिघलाकर 2 सेमी त्रिज्या वाले कितने छोटे गोले बनाए जा सकते हैं?",
          listOf(
            "Step 1: Number of spheres = Volume of large sphere / Volume of small sphere.",
            "Step 2: n = (R / r)³.",
            "Step 3: n = (6 / 2)³ = 3³ = 27."
          ),
          "27",
          "Volume ratio equals cube of radius ratio."
        ),
        createExample(
          "m3_ex3",
          "Find total surface area of a solid hemisphere of radius 7 cm.",
          "7 सेमी त्रिज्या वाले एक ठोस अर्धगोले का कुल पृष्ठीय क्षेत्रफल ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula for TSA of solid hemisphere = 3πr².",
            "Step 2: TSA = 3 * (22/7) * 7² = 3 * 22 * 7 = 462 cm²."
          ),
          "462 cm²",
          "Solid hemisphere includes base circle: 2πr² + πr² = 3πr²."
        )
      ),
      practiceMcqs = listOf(
        createMcq("m3_q1", "Volume of cone of base radius 6 cm and height 7 cm is:", "", "264 cm³", "312 cm³", "240 cm³", "280 cm³", 0, "V = 1/3 * 22/7 * 36 * 7 = 12 * 22 = 264 cm³."),
        createMcq("m3_q2", "If radius of sphere is doubled, its volume becomes:", "", "8 times", "4 times", "6 times", "2 times", 0, "Volume ∝ r³ => 2³ = 8 times."),
        createMcq("m3_q3", "Curved surface area of cylinder of radius 7 cm and height 10 cm is:", "", "440 cm²", "400 cm²", "480 cm²", "420 cm²", 0, "CSA = 2 * 22/7 * 7 * 10 = 440 cm²."),
        createMcq("m3_q4", "How many cubes of side 3 cm can be cut from a cube of side 12 cm?", "", "64", "32", "48", "16", 0, "(12 / 3)³ = 4³ = 64."),
        createMcq("m3_q5", "A cylindrical tank has capacity 6160 m³ and diameter 28 m. Its depth is:", "", "10 m", "12 m", "8 m", "14 m", 0, "r = 14. 22/7 * 14 * 14 * h = 6160 => 616 h = 6160 => h = 10 m."),
        createMcq("m3_q6", "Slant height of cone of radius 5 cm and height 12 cm is:", "", "13 cm", "14 cm", "15 cm", "12.5 cm", 0, "l = √(5² + 12²) = 13 cm."),
        createMcq("m3_q7", "Surface area of sphere of radius 10.5 cm is:", "", "1386 cm²", "1250 cm²", "1440 cm²", "1300 cm²", 0, "4 * 22/7 * (21/2)² = 1386 cm²."),
        createMcq("m3_q8", "If edge of cube is increased by 50%, surface area increases by:", "", "125%", "100%", "150%", "75%", 0, "Area ∝ a² => (1.5)² - 1 = 2.25 - 1 = 125%."),
        createMcq("m3_q9", "Ratio of volumes of two cones is 4:5 and radii in ratio 2:3. Ratio of heights is:", "", "9:5", "5:9", "4:5", "3:2", 0, "V1/V2 = (r1/r2)² * (h1/h2) => 4/5 = 4/9 * (h1/h2) => h1/h2 = 9/5."),
        createMcq("m3_q10", "Diameter of iron ball is 6 cm. If melted into a wire of diameter 0.2 cm, length of wire is:", "", "36 m", "30 m", "32 m", "40 m", 0, "4/3 π (3)³ = π (0.1)² L => 36 = 0.01 L => L = 3600 cm = 36 m.")
      )
    ),
    // 26. Trigonometry
    FormulaTopic(
      id = "math_trigonometry",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Trigonometry",
      title = "Trigonometric Ratios & Identities",
      hindiTitle = "त्रिकोणमितीय अनुपात एवं सर्वसमिकाएं",
      summary = "Basic ratios, standard table values, Pythagorean identities, and complementary angle rules.",
      coreFormula = "sin² θ + cos² θ = 1\n1 + tan² θ = sec² θ <=> sec² θ - tan² θ = 1\n1 + cot² θ = cosec² θ <=> cosec² θ - cot² θ = 1\nsin(90° - θ) = cos θ , cos(90° - θ) = sin θ\ntan(90° - θ) = cot θ , sec(90° - θ) = cosec θ",
      symbolExplanations = listOf(
        "θ" to "Angle in degrees or radians.",
        "sec θ - tan θ" to "Reciprocal of (sec θ + tan θ).",
        "cosec θ - cot θ" to "Reciprocal of (cosec θ + cot θ)."
      ),
      importantIdentities = listOf(
        "sin 0°=0, 30°=1/2, 45°=1/√2, 60°=√3/2, 90°=1",
        "cos 0°=1, 30°=√3/2, 45°=1/√2, 60°=1/2, 90°=0",
        "tan 0°=0, 30°=1/√3, 45°=1, 60°=√3, 90°=undefined"
      ),
      shortcutsAndTips = listOf(
        "If sec θ + tan θ = x, then sec θ - tan θ = 1/x, and sec θ = (x² + 1) / (2x)."
      ),
      commonMistakes = listOf(
        "Writing sin(A + B) = sin A + sin B (false; sin(A+B) = sinA cosB + cosA sinB)."
      ),
      solvedExamples = listOf(
        createExample(
          "trig_ex1",
          "If sec θ + tan θ = 3, find the value of sin θ.",
          "यदि sec θ + tan θ = 3 है, तो sin θ का मान ज्ञात कीजिए।",
          listOf(
            "Step 1: sec θ - tan θ = 1/3.",
            "Step 2: Add both: 2 sec θ = 3 + 1/3 = 10/3 => sec θ = 5/3.",
            "Step 3: Since cos θ = 3/5, by Pythagoras triplet (3, 4, 5), sin θ = 4/5."
          ),
          "4/5",
          "sec θ = (x² + 1)/(2x) = 10/6 = 5/3."
        ),
        createExample(
          "trig_ex2",
          "Evaluate: (sin 25° cos 65° + cos 25° sin 65°).",
          "मान ज्ञात कीजिए: sin 25° cos 65° + cos 25° sin 65°।",
          listOf(
            "Step 1: Formula: sin(A + B) = sin A cos B + cos A sin B.",
            "Step 2: Here A = 25° and B = 65°.",
            "Step 3: sin(25° + 65°) = sin 90° = 1."
          ),
          "1",
          "Angle addition identity sin(A + B)."
        ),
        createExample(
          "trig_ex3",
          "Find maximum value of 3 sin θ + 4 cos θ.",
          "3 sin θ + 4 cos θ का अधिकतम मान ज्ञात कीजिए।",
          listOf(
            "Step 1: For a sin θ + b cos θ, Maximum = √(a² + b²).",
            "Step 2: Maximum = √(3² + 4²) = √(9 + 16) = √25 = 5."
          ),
          "5",
          "Max is √(a² + b²); Min is -√(a² + b²)."
        )
      ),
      practiceMcqs = listOf(
        createMcq("trig_q1", "Value of (sin 30° + cos 60°) is:", "", "1", "1/2", "√3/2", "2", 0, "1/2 + 1/2 = 1."),
        createMcq("trig_q2", "If tan θ = 4/3, then (sin θ + cos θ) / (sin θ - cos θ) is:", "", "7", "-7", "1/7", "5", 0, "Divide by cos θ: (tan θ + 1) / (tan θ - 1) = (4/3 + 1) / (4/3 - 1) = 7."),
        createMcq("trig_q3", "Evaluate: tan 1° tan 2° tan 3° ... tan 89°:", "", "1", "0", "1/√3", "undefined", 0, "tan θ * tan(90° - θ) = 1. Middle term tan 45° = 1. Product = 1."),
        createMcq("trig_q4", "If cosec θ + cot θ = 2, then cosec θ is:", "", "1.25", "1.5", "2.5", "1.75", 0, "cosec θ = (2² + 1)/(2*2) = 5/4 = 1.25."),
        createMcq("trig_q5", "Minimum value of (sin² θ + cosec² θ) is:", "", "2", "1", "4", "0", 0, "By AM >= GM, minimum of x + 1/x is 2."),
        createMcq("trig_q6", "Value of (cos 1° cos 2° cos 3° ... cos 179°) is:", "", "0", "1", "-1", "1/2", 0, "Contains cos 90° = 0. Whole product = 0."),
        createMcq("trig_q7", "If sin θ = cos θ (0 < θ < 90°), value of θ is:", "", "45°", "30°", "60°", "0°", 0, "tan θ = 1 => θ = 45°."),
        createMcq("trig_q8", "Value of (1 - tan² 45°) / (1 + tan² 45°) is:", "", "0", "1", "cos 90°", "Both A and C", 3, "(1 - 1)/(1 + 1) = 0 = cos 90°."),
        createMcq("trig_q9", "If 5 tan θ = 4, then (5 sin θ - 3 cos θ) / (5 sin θ + 2 cos θ) is:", "", "1/6", "1/4", "1/5", "2/5", 0, "(5 tan θ - 3) / (5 tan θ + 2) = (4 - 3)/(4 + 2) = 1/6."),
        createMcq("trig_q10", "Maximum value of 12 sin θ - 5 cos θ is:", "", "13", "17", "7", "12", 0, "√(12² + (-5)²) = √(144 + 25) = √169 = 13.")
      )
    ),
    // 27. Heights and Distances
    FormulaTopic(
      id = "math_heights_distances",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Trigonometry",
      title = "Heights and Distances",
      hindiTitle = "ऊंचाई एवं दूरी",
      summary = "Angle of elevation and depression, standard 30-60-90 and 45-45-90 ratios.",
      coreFormula = "In right triangle: tan θ = Perpendicular / Base\nRatio for 30°: Sides opposite are 1 : √3 : 2\nRatio for 45°: Sides opposite are 1 : 1 : √2\nHeight of tower from two points on same line: h = [d * tan α * tan β] / (tan β - tan α)",
      symbolExplanations = listOf(
        "Angle of Elevation" to "Angle looking upward from horizontal.",
        "Angle of Depression" to "Angle looking downward from horizontal (equal to elevation by alternate angles).",
        "d" to "Distance between two observation points."
      ),
      importantIdentities = listOf(
        "If angles are complementary (α + β = 90°) at distances a and b from foot: h = √(ab)."
      ),
      shortcutsAndTips = listOf(
        "At 45°, Height = Base. At 30°, Base = Height * √3. At 60°, Height = Base * √3."
      ),
      commonMistakes = listOf(
        "Measuring angle of depression from vertical instead of horizontal."
      ),
      solvedExamples = listOf(
        createExample(
          "hd_ex1",
          "The angle of elevation of the top of a tower from a point 30 m away from its foot is 30°. Find height of the tower.",
          "एक मीनार के पाद से 30 मी दूर स्थित बिंदु से उसके शीर्ष का उन्नयन कोण 30° है। मीनार की ऊंचाई ज्ञात कीजिए।",
          listOf(
            "Step 1: tan 30° = Height / Base.",
            "Step 2: 1 / √3 = h / 30.",
            "Step 3: h = 30 / √3 = 10√3 m ≈ 17.32 m."
          ),
          "10√3 m",
          "Divide by √3 at 30° elevation."
        ),
        createExample(
          "hd_ex2",
          "The angles of elevation of the top of a tower from two points at distances a and b from foot and in the same straight line are complementary. Find height of tower.",
          "मीनार के आधार से a और b दूरी पर स्थित बिंदुओं से उन्नयन कोण पूरक हैं। मीनार की ऊंचाई ज्ञात कीजिए।",
          listOf(
            "Step 1: tan θ = h / a and tan(90° - θ) = cot θ = h / b.",
            "Step 2: Multiply both: tan θ * cot θ = (h / a) * (h / b).",
            "Step 3: 1 = h² / (ab) => h = √(ab)."
          ),
          "h = √(ab)",
          "Standard identity for complementary angles."
        ),
        createExample(
          "hd_ex3",
          "From top of 60 m cliff, angle of depression of a boat is 45°. How far is the boat from the foot of cliff?",
          "60 मी ऊंची पहाड़ी की चोटी से एक नाव का अवनमन कोण 45° है। नाव पहाड़ी के पाद से कितनी दूर है?",
          listOf(
            "Step 1: Angle of elevation from boat = angle of depression = 45°.",
            "Step 2: tan 45° = Height / Distance = 60 / d.",
            "Step 3: 1 = 60 / d => d = 60 m."
          ),
          "60 m",
          "At 45°, distance equals height."
        )
      ),
      practiceMcqs = listOf(
        createMcq("hd_q1", "A kite is flying at height 60 m with string inclined at 60° to horizontal. Length of string is:", "", "40√3 m", "30√3 m", "60√3 m", "80 m", 0, "sin 60° = 60 / L => √3/2 = 60/L => L = 120/√3 = 40√3 m."),
        createMcq("hd_q2", "Shadow of tower is √3 times its height. Sun's angle of elevation is:", "", "30°", "45°", "60°", "90°", 0, "tan θ = h / (h√3) = 1/√3 => θ = 30°."),
        createMcq("hd_q3", "Top of broken tree touches ground at distance 30 m at angle 30°. Original height was:", "", "30√3 m", "20√3 m", "10√3 m", "40√3 m", 0, "h1 = 30 tan 30° = 10√3. Broken part = 30 sec 30° = 20√3. Total = 30√3 m."),
        createMcq("hd_q4", "Complementary angles at 4 m and 9 m from foot of tower. Height of tower is:", "", "6 m", "5 m", "7 m", "6.5 m", 0, "h = √(4 * 9) = √36 = 6 m."),
        createMcq("hd_q5", "Angle changes from 30° to 45° as observer walks 20 m towards tower. Height is:", "", "10(√3 + 1) m", "20(√3 - 1) m", "10√3 m", "15 m", 0, "h = d / (cot 30° - cot 45°) = 20 / (√3 - 1) = 10(√3 + 1) m."),
        createMcq("hd_q6", "Two poles of height 6 m and 11 m stand 12 m apart. Distance between their tops is:", "", "13 m", "12 m", "14 m", "15 m", 0, "Difference in height = 5 m. Distance = √(12² + 5²) = 13 m."),
        createMcq("hd_q7", "From top of 7 m building, elevation of cable tower is 60° and depression of foot is 45°. Height of tower is:", "", "7(√3 + 1) m", "14 m", "7√3 m", "12 m", 0, "Base = 7 m. Tower extra = 7 tan 60° = 7√3. Total = 7 + 7√3 = 7(√3 + 1) m."),
        createMcq("hd_q8", "If elevation of sun increases from 30° to 60°, shadow of tower decreases by:", "", "2h / √3", "h√3", "h / √3", "h", 0, "h cot 30° - h cot 60° = h(√3 - 1/√3) = 2h / √3."),
        createMcq("hd_q9", "An aeroplane flying at 3000 m passes above another. Elevations from ground are 60° and 45°. Vertical distance between planes:", "", "3000(1 - 1/√3) m", "1500 m", "1000√3 m", "2000 m", 0, "Lower plane height = 3000 / √3. Distance = 3000 - 3000/√3 = 3000(1 - 1/√3) m."),
        createMcq("hd_q10", "Ladder rests against wall at 60°. Foot is 4.6 m away. Length of ladder is:", "", "9.2 m", "8.2 m", "7.8 m", "9.5 m", 0, "cos 60° = 4.6 / L => 1/2 = 4.6 / L => L = 9.2 m.")
      )
    ),
    // 28. Coordinate Geometry
    FormulaTopic(
      id = "math_coordinate_geometry",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Advanced Mathematics",
      title = "Coordinate Geometry",
      hindiTitle = "निर्देशांक ज्यामिति",
      summary = "Distance formula, section formula, slope, equation of line, and area of triangle.",
      coreFormula = "Distance = √[(x2 - x1)² + (y2 - y1)²]\nSection Formula: [(m*x2 + n*x1) / (m + n), (m*y2 + n*y1) / (m + n)]\nMidpoint = [(x1 + x2) / 2, (y1 + y2) / 2]\nSlope: m = (y2 - y1) / (x2 - x1) = -a / b\nArea of Triangle = 1/2 |x1(y2 - y3) + x2(y3 - y1) + x3(y1 - y2)|",
      symbolExplanations = listOf(
        "(x1, y1), (x2, y2)" to "Coordinates of points on Cartesian plane.",
        "m : n" to "Ratio of division in section formula.",
        "m" to "Slope / gradient of line."
      ),
      importantIdentities = listOf(
        "Parallel lines have equal slopes: m1 = m2.",
        "Perpendicular lines have product of slopes = -1 (m1 * m2 = -1).",
        "Centroid of triangle = [(x1 + x2 + x3)/3, (y1 + y2 + y3)/3]."
      ),
      shortcutsAndTips = listOf(
        "If area of triangle formed by 3 points is 0, the points are collinear."
      ),
      commonMistakes = listOf(
        "Forgetting the minus sign when computing slope from ax + by + c = 0 (slope is -a/b, not a/b)."
      ),
      solvedExamples = listOf(
        createExample(
          "cg_ex1",
          "Find the distance between the points (3, -2) and (-1, 1).",
          "बिंदुओं (3, -2) और (-1, 1) के बीच की दूरी ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: d = √[(x2 - x1)² + (y2 - y1)²].",
            "Step 2: d = √[(-1 - 3)² + (1 - (-2))²] = √[(-4)² + 3²].",
            "Step 3: d = √(16 + 9) = √25 = 5 units."
          ),
          "5 units",
          "Apply distance formula."
        ),
        createExample(
          "cg_ex2",
          "Find coordinates of point dividing line joining (1, 3) and (4, 6) in ratio 2:1 internally.",
          "(1, 3) और (4, 6) को मिलाने वाली रेखा को 2:1 के अनुपात में अंतर्विभाजित करने वाले बिंदु के निर्देशांक ज्ञात कीजिए।",
          listOf(
            "Step 1: Section formula: x = (m*x2 + n*x1)/(m+n), y = (m*y2 + n*y1)/(m+n).",
            "Step 2: x = (2*4 + 1*1) / (2+1) = (8+1)/3 = 3.",
            "Step 3: y = (2*6 + 1*3) / (2+1) = (12+3)/3 = 5."
          ),
          "(3, 5)",
          "Section formula: (mx2 + nx1)/(m+n)."
        ),
        createExample(
          "cg_ex3",
          "Find the slope of line perpendicular to 3x - 4y + 7 = 0.",
          "रेखा 3x - 4y + 7 = 0 के लंबवत रेखा की प्रवणता ज्ञात कीजिए।",
          listOf(
            "Step 1: Slope of given line m1 = -a / b = -3 / (-4) = 3/4.",
            "Step 2: For perpendicular line, m1 * m2 = -1.",
            "Step 3: m2 = -1 / (3/4) = -4/3."
          ),
          "-4/3",
          "Perpendicular slope is negative reciprocal."
        )
      ),
      practiceMcqs = listOf(
        createMcq("cg_q1", "Distance of point (6, -8) from origin is:", "", "10", "14", "8", "6", 0, "√(6² + (-8)²) = √(36 + 64) = 10."),
        createMcq("cg_q2", "Midpoint of line segment joining (-5, 4) and (7, -8) is:", "", "(1, -2)", "(2, -4)", "(-1, 2)", "(1, 2)", 0, "((-5+7)/2, (4-8)/2) = (1, -2)."),
        createMcq("cg_q3", "Slope of line 2x + 5y = 10 is:", "", "-2/5", "2/5", "-5/2", "5/2", 0, "Slope = -a/b = -2/5."),
        createMcq("cg_q4", "If points (1, 2), (0, 0), and (a, b) are collinear, then:", "", "2a = b", "a = 2b", "a = b", "a + b = 0", 0, "Slope: 2/1 = b/a => b = 2a."),
        createMcq("cg_q5", "Area of triangle with vertices (0, 0), (4, 0), (0, 6) is:", "", "12", "24", "10", "16", 0, "1/2 * 4 * 6 = 12 sq units."),
        createMcq("cg_q6", "Two lines 3x + 2ky = 2 and 2x + 5y + 1 = 0 are parallel. Value of k is:", "", "15/4", "12/5", "10/3", "5/3", 0, "3/2 = 2k/5 => 4k = 15 => k = 15/4."),
        createMcq("cg_q7", "Centroid of triangle with vertices (1, 4), (4, -3), (-2, 5) is:", "", "(1, 2)", "(1, 3)", "(2, 1)", "(2, 2)", 0, "((1+4-2)/3, (4-3+5)/3) = (3/3, 6/3) = (1, 2)."),
        createMcq("cg_q8", "Equation of line with slope 2 passing through (1, 3) is:", "", "2x - y + 1 = 0", "2x + y - 5 = 0", "x - 2y + 5 = 0", "2x - y - 1 = 0", 0, "y - 3 = 2(x - 1) => 2x - y + 1 = 0."),
        createMcq("cg_q9", "Perpendicular distance from origin to line 3x + 4y = 20 is:", "", "4", "5", "3", "2", 0, "|-20| / √(3² + 4²) = 20 / 5 = 4."),
        createMcq("cg_q10", "Point P divides (2, 1) and (5, -8) such that AP/AB = 1/3. Coordinates of P are:", "", "(3, -2)", "(3, 2)", "(2, -3)", "(4, -5)", 0, "Ratio AP:PB = 1:2. x = (1*5 + 2*2)/3 = 3; y = (1*-8 + 2*1)/3 = -2.")
      )
    ),
    // 29. Probability
    FormulaTopic(
      id = "math_probability",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Modern Mathematics",
      title = "Probability",
      hindiTitle = "प्रायिकता",
      summary = "Classical definition, coins, dice, playing cards, colored balls, and addition theorem.",
      coreFormula = "P(E) = Number of Favourable Outcomes / Total Number of Outcomes\n0 <= P(E) <= 1\nP(E) + P(not E) = 1\nP(A ∪ B) = P(A) + P(B) - P(A ∩ B)\nIndependent Events: P(A ∩ B) = P(A) * P(B)",
      symbolExplanations = listOf(
        "P(E)" to "Probability of event E.",
        "Mutually Exclusive Events" to "Events that cannot happen simultaneously: P(A ∩ B) = 0."
      ),
      importantIdentities = listOf(
        "Deck of 52 cards: 4 suits (Spades ♠, Clubs ♣ [Black 26]; Hearts ♥, Diamonds ♦ [Red 26]). 12 Face cards (4 Jacks, 4 Queens, 4 Kings). 4 Aces."
      ),
      shortcutsAndTips = listOf(
        "When finding 'at least one', use complementary probability: P(at least 1) = 1 - P(none)."
      ),
      commonMistakes = listOf(
        "Counting Aces as face cards (Aces have honor value but no face pictures)."
      ),
      solvedExamples = listOf(
        createExample(
          "prob_ex1",
          "Two dice are thrown simultaneously. What is the probability of getting a sum of 8?",
          "दो पासे एक साथ फेंके जाते हैं। योग 8 आने की प्रायिकता क्या है?",
          listOf(
            "Step 1: Total outcomes = 6 * 6 = 36.",
            "Step 2: Favourable outcomes for sum 8: (2,6), (3,5), (4,4), (5,3), (6,2) = 5 outcomes.",
            "Step 3: P(Sum = 8) = 5 / 36."
          ),
          "5/36",
          "List pairs where a + b = 8."
        ),
        createExample(
          "prob_ex2",
          "One card is drawn from a well-shuffled pack of 52 cards. What is probability of getting a queen or a heart?",
          "52 पत्तों की ताश की गड्डी में से एक पत्ता निकाला जाता है। बेगम या पान का पत्ता आने की प्रायिकता क्या है?",
          listOf(
            "Step 1: Number of Queens = 4. Number of Hearts = 13.",
            "Step 2: Queen of Hearts is common to both = 1 card.",
            "Step 3: Favourable = 4 + 13 - 1 = 16 cards.",
            "Step 4: Probability = 16 / 52 = 4 / 13."
          ),
          "4/13",
          "P(A ∪ B) = P(A) + P(B) - P(A ∩ B)."
        ),
        createExample(
          "prob_ex3",
          "A bag contains 4 red, 5 blue, and 6 green balls. Two balls are drawn at random. What is probability that both are red?",
          "एक थैले में 4 लाल, 5 नीली और 6 हरी गेंदें हैं। दो गेंदें निकाली जाती हैं। दोनों के लाल होने की प्रायिकता क्या है?",
          listOf(
            "Step 1: Total balls = 4 + 5 + 6 = 15.",
            "Step 2: Total ways to pick 2 balls = 15C2 = (15 * 14) / 2 = 105.",
            "Step 3: Favourable ways to pick 2 red balls = 4C2 = (4 * 3) / 2 = 6.",
            "Step 4: Probability = 6 / 105 = 2 / 35."
          ),
          "2/35",
          "Use combinations nCr."
        )
      ),
      practiceMcqs = listOf(
        createMcq("prob_q1", "Three unbiased coins are tossed. Probability of getting at least 2 heads:", "", "1/2", "3/8", "5/8", "7/8", 0, "Outcomes: 8. Favourable: HHH, HHT, HTH, THH = 4. P = 4/8 = 1/2."),
        createMcq("prob_q2", "Probability of leap year having 53 Sundays is:", "", "2/7", "1/7", "3/7", "5/7", 0, "Leap year has 366 days = 52 weeks + 2 odd days. P = 2/7."),
        createMcq("prob_q3", "Two cards drawn from 52 cards. Probability that both are kings is:", "", "1/221", "1/13", "2/13", "4/221", 0, "(4/52) * (3/51) = 1/221."),
        createMcq("prob_q4", "A die is thrown. Probability of getting a prime number is:", "", "1/2", "1/3", "2/3", "1/6", 0, "Primes are 2, 3, 5 (3 numbers). P = 3/6 = 1/2."),
        createMcq("prob_q5", "Two dice thrown. Probability that sum is a multiple of 5:", "", "7/36", "1/6", "5/36", "1/9", 0, "Sums 5 (4 ways) + 10 (3 ways) = 7/36."),
        createMcq("prob_q6", "Probability of drawing an ace or a king from 52 cards:", "", "2/13", "1/13", "4/13", "1/26", 0, "(4 + 4) / 52 = 8/52 = 2/13."),
        createMcq("prob_q7", "A problem is given to A and B. Chances of solving are 1/2 and 1/3. Probability problem is solved:", "", "2/3", "1/6", "5/6", "1/3", 0, "1 - P(neither) = 1 - (1/2 * 2/3) = 1 - 1/3 = 2/3."),
        createMcq("prob_q8", "A bag has 6 black and 8 white balls. One ball drawn. Probability it is white:", "", "4/7", "3/7", "1/2", "2/7", 0, "8 / 14 = 4/7."),
        createMcq("prob_q9", "Probability of getting total 7 when throwing two dice:", "", "1/6", "5/36", "1/12", "7/36", 0, "Pairs: 6. 6/36 = 1/6."),
        createMcq("prob_q10", "A box has 20 tickets numbered 1 to 20. Ticket drawn. Probability it is multiple of 3 or 5:", "", "9/20", "8/20", "1/2", "7/20", 0, "Multiples of 3 (6) + 5 (4) - 15 (1) = 9. P = 9/20.")
      )
    ),
    // 30. Permutation and Combination
    FormulaTopic(
      id = "math_permutation_combination",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Modern Mathematics",
      title = "Permutation and Combination",
      hindiTitle = "क्रमचय एवं संचय",
      summary = "Arrangement vs selection, fundamental counting principle, circular permutation, and grouping.",
      coreFormula = "Permutation (Arrangement): nPr = n! / (n - r)!\nCombination (Selection): nCr = n! / [r! * (n - r)!]\nCircular Permutations: (n - 1)!\nNecklace/Garland Circular: (n - 1)! / 2",
      symbolExplanations = listOf(
        "nPr" to "Order matters (e.g. word formations, seat arrangements).",
        "nCr" to "Order does NOT matter (e.g. team selection, committee, handshakes)."
      ),
      importantIdentities = listOf(
        "nCr = nC(n - r)",
        "nCr + nC(r - 1) = (n + 1)Cr (Pascal's Identity)",
        "Total subsets of n elements = 2^n"
      ),
      shortcutsAndTips = listOf(
        "Handshakes among n people = nC2 = [n(n - 1)] / 2."
      ),
      commonMistakes = listOf(
        "Using nPr when order doesn't matter (e.g. choosing a committee of 3 from 10 is 10C3, not 10P3)."
      ),
      solvedExamples = listOf(
        createExample(
          "pc_comb_ex1",
          "In how many different ways can the letters of the word 'LEADING' be arranged so that vowels always come together?",
          "शब्द 'LEADING' के अक्षरों को कितने विभिन्न तरीकों से व्यवस्थित किया जा सकता है ताकि स्वर हमेशा एक साथ आएं?",
          listOf(
            "Step 1: Word has 7 letters: Vowels are E, A, I (3 vowels); Consonants are L, D, N, G (4 consonants).",
            "Step 2: Bundle the 3 vowels as 1 single unit. Total units = 4 consonants + 1 bundle = 5 units.",
            "Step 3: 5 units can be arranged in 5! = 120 ways.",
            "Step 4: The 3 vowels in bundle can arrange among themselves in 3! = 6 ways.",
            "Step 5: Total ways = 120 * 6 = 720 ways."
          ),
          "720 ways",
          "Bundle method for 'always together'."
        ),
        createExample(
          "pc_comb_ex2",
          "Out of 7 men and 4 women, a committee of 5 is to be formed. In how many ways can this be done so that committee has at least 3 men?",
          "7 पुरुषों और 4 महिलाओं में से 5 की एक समिति बनानी है जिसमें कम से कम 3 पुरुष हों। यह कितने तरीकों से किया जा सकता है?",
          listOf(
            "Step 1: Cases: (3M, 2W), (4M, 1W), (5M, 0W).",
            "Step 2: Case 1: 7C3 * 4C2 = 35 * 6 = 210.",
            "Step 3: Case 2: 7C4 * 4C1 = 35 * 4 = 140.",
            "Step 4: Case 3: 7C5 * 4C0 = 21 * 1 = 21.",
            "Step 5: Total ways = 210 + 140 + 21 = 371 ways."
          ),
          "371 ways",
          "Break 'at least' into mutually exclusive cases."
        ),
        createExample(
          "pc_comb_ex3",
          "How many handshakes are exchanged if 12 people meet at a conference and everyone shakes hands with everyone else once?",
          "एक सम्मेलन में 12 व्यक्ति मिलते हैं और प्रत्येक एक दूसरे से हाथ मिलाते हैं। कुल कितने हैंडशेक होंगे?",
          listOf(
            "Step 1: Handshake requires 2 people: nC2.",
            "Step 2: 12C2 = (12 * 11) / 2 = 66 handshakes."
          ),
          "66",
          "Formula: n(n - 1) / 2."
        )
      ),
      practiceMcqs = listOf(
        createMcq("pc_comb_q1", "Value of 7P3 is:", "", "210", "35", "120", "5040", 0, "7 * 6 * 5 = 210."),
        createMcq("pc_comb_q2", "Value of 10C3 is:", "", "120", "720", "240", "60", 0, "(10 * 9 * 8) / 6 = 120."),
        createMcq("pc_comb_q3", "Ways to seat 6 people in a round table:", "", "120", "720", "24", "60", 0, "(6 - 1)! = 5! = 120."),
        createMcq("pc_comb_q4", "How many diagonals in a decagon (10-sided polygon)?", "", "35", "45", "25", "30", 0, "10C2 - 10 = 45 - 10 = 35."),
        createMcq("pc_comb_q5", "Number of arrangements of word 'MATHEMATICS':", "", "4,989,600", "11!", "1,200,000", "2,494,800", 0, "11! / (2! * 2! * 2!) = 4,989,600."),
        createMcq("pc_comb_q6", "In how many ways can 4 boys and 3 girls be seated in a row alternately?", "", "144", "288", "72", "576", 0, "Boys in 4! = 24. Girls in 3! = 6. Total = 24 * 6 = 144."),
        createMcq("pc_comb_q7", "If nC8 = nC2, then n is:", "", "10", "16", "8", "6", 0, "nCr = nCs => n = r + s = 8 + 2 = 10."),
        createMcq("pc_comb_q8", "Total number of 3-digit numbers that can be formed using digits 1, 2, 3, 4, 5 without repetition:", "", "60", "125", "20", "24", 0, "5P3 = 5 * 4 * 3 = 60."),
        createMcq("pc_comb_q9", "How many different signals can be given using any number of 5 flags of different colors?", "", "325", "120", "240", "300", 0, "5P1 + 5P2 + 5P3 + 5P4 + 5P5 = 325."),
        createMcq("pc_comb_q10", "A box has 5 red and 4 black marbles. Ways to pick 3 marbles such that at least 1 is black:", "", "74", "84", "64", "70", 0, "Total 9C3 - all red 5C3 = 84 - 10 = 74.")
      )
    ),
    // 31. Statistics
    FormulaTopic(
      id = "math_statistics",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Modern Mathematics",
      title = "Statistics & Dispersion",
      hindiTitle = "सांख्यिकी एवं प्रकीर्णन",
      summary = "Mean, median, mode empirical relationship, variance, and standard deviation.",
      coreFormula = "Empirical Relation: Mode = 3 * Median - 2 * Mean\nMedian for sorted data:\nIf n odd: Median = [(n + 1)/2]th term\nIf n even: Median = Average of (n/2)th and (n/2 + 1)th terms\nVariance (σ²) = [Σ(x - x̄)²] / n\nStandard Deviation (σ) = √Variance\nCoefficient of Variation (CV) = (σ / Mean) * 100%",
      symbolExplanations = listOf(
        "Mode" to "Most frequently occurring observation.",
        "Median" to "Middle value of ordered data.",
        "Mean (x̄)" to "Arithmetic average.",
        "σ" to "Standard deviation, measure of data dispersion."
      ),
      importantIdentities = listOf(
        "Range = Maximum Value - Minimum Value",
        "If every observation is increased by k, Mean increases by k, but Variance and SD remain UNCHANGED."
      ),
      shortcutsAndTips = listOf(
        "Mode = 3 Median - 2 Mean is one of the most tested formulas in SSC CGL & RRB."
      ),
      commonMistakes = listOf(
        "Taking square of SD to get CV instead of σ / Mean * 100."
      ),
      solvedExamples = listOf(
        createExample(
          "stat_ex1",
          "If the mean of a distribution is 25 and median is 24, find the mode.",
          "यदि किसी वितरण का माध्य 25 और माध्यिका 24 है, तो बहुलक ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: Mode = 3 * Median - 2 * Mean.",
            "Step 2: Mode = 3(24) - 2(25) = 72 - 50 = 22."
          ),
          "22",
          "Mode = 3 Median - 2 Mean."
        ),
        createExample(
          "stat_ex2",
          "Find median of data set: 13, 18, 12, 14, 19, 16, 21.",
          "आंकड़ों 13, 18, 12, 14, 19, 16, 21 की माध्यिका ज्ञात कीजिए।",
          listOf(
            "Step 1: Arrange in ascending order: 12, 13, 14, 16, 18, 19, 21.",
            "Step 2: Number of items n = 7 (odd).",
            "Step 3: Median is (7+1)/2 = 4th term = 16."
          ),
          "16",
          "Always arrange in ascending order first."
        ),
        createExample(
          "stat_ex3",
          "If the variance of a data set is 144, find its standard deviation.",
          "यदि प्रसरण 144 है, तो मानक विचलन ज्ञात कीजिए।",
          listOf(
            "Step 1: Formula: Standard Deviation = √Variance.",
            "Step 2: SD = √144 = 12."
          ),
          "12",
          "SD is positive square root of variance."
        )
      ),
      practiceMcqs = listOf(
        createMcq("stat_q1", "If median = 15 and mean = 12, mode is:", "", "21", "18", "24", "19", 0, "3(15) - 2(12) = 45 - 24 = 21."),
        createMcq("stat_q2", "Standard deviation of a data set is 9. Variance is:", "", "81", "18", "3", "27", 0, "Variance = σ² = 9² = 81."),
        createMcq("stat_q3", "Range of 15, 22, 18, 27, 31, 9, 14 is:", "", "22", "16", "20", "24", 0, "Max (31) - Min (9) = 22."),
        createMcq("stat_q4", "If every observation in a data set is multiplied by 2, standard deviation becomes:", "", "2 times", "4 times", "Unchanged", "Half", 0, "SD scales linearly with multiplication by constant: 2 times."),
        createMcq("stat_q5", "Median of 2, 4, 6, 8, 10, 12 is:", "", "7", "6", "8", "6.5", 0, "n=6 (even). Average of 3rd and 4th: (6 + 8)/2 = 7."),
        createMcq("stat_q6", "Mode of data: 4, 3, 2, 5, 3, 7, 3, 8 is:", "", "3", "4", "5", "7", 0, "3 appears 3 times (highest frequency)."),
        createMcq("stat_q7", "Mean of first 10 prime numbers is:", "", "12.9", "11.5", "13.2", "10.8", 0, "Primes: 2,3,5,7,11,13,17,19,23,29. Sum = 129. Mean = 129/10 = 12.9."),
        createMcq("stat_q8", "If mean is 20 and standard deviation is 5, coefficient of variation (CV) is:", "", "25%", "20%", "40%", "15%", 0, "CV = (5 / 20) * 100 = 25%."),
        createMcq("stat_q9", "Sum of deviations of a set of observations from their arithmetic mean is always:", "", "0", "1", "Positive", "Negative", 0, "Σ(x - x̄) = 0 always by definition of mean."),
        createMcq("stat_q10", "Mean of 5 numbers is 18. If one number is excluded, mean is 16. Excluded number is:", "", "26", "24", "22", "28", 0, "5 * 18 - 4 * 16 = 90 - 64 = 26.")
      )
    ),
    // 32. Data Interpretation
    FormulaTopic(
      id = "math_data_interpretation",
      subject = FormulaSubject.MATHEMATICS,
      chapter = "Data Analysis",
      title = "Data Interpretation (DI)",
      hindiTitle = "आंकड़ों का विश्लेषण (DI)",
      summary = "Pie charts, bar graphs, radar graphs, line graphs, percentage growth, and table analysis.",
      coreFormula = "Pie Chart Angle = (Value / Total) * 360°\nPercentage Share in Pie Chart = (Angle / 360°) * 100%\nPercentage Growth = [(Final - Initial) / Initial] * 100%\nCAGR = (Final / Initial)^(1 / n) - 1",
      symbolExplanations = listOf(
        "360°" to "Total degree representation of 100% in a circular pie chart.",
        "1%" to "Equivalent to 3.6° in a pie chart.",
        "Initial" to "Base year value in growth calculations."
      ),
      importantIdentities = listOf(
        "10% = 36°, 25% = 90°, 50% = 180° in a pie chart.",
        "Growth is always calculated on previous/initial period baseline."
      ),
      shortcutsAndTips = listOf(
        "Degree to % conversion: Divide angle by 3.6.",
        "% to Degree conversion: Multiply percentage by 3.6."
      ),
      commonMistakes = listOf(
        "Calculating percentage growth using the final year in denominator instead of base year."
      ),
      solvedExamples = listOf(
        createExample(
          "di_ex1",
          "In a pie chart, the sector angle for food expenditure is 108°. If total monthly expenditure is ₹40,000, find expenditure on food.",
          "एक पाई चार्ट में भोजन का केंद्रीय कोण 108° है। यदि कुल मासिक व्यय ₹40,000 है, तो भोजन पर व्यय ज्ञात कीजिए।",
          listOf(
            "Step 1: Fraction of total = Angle / 360°.",
            "Step 2: Fraction = 108° / 360° = 3 / 10 = 30%.",
            "Step 3: Food expenditure = 30% of ₹40,000 = ₹12,000."
          ),
          "₹12,000",
          "108 / 3.6 = 30%."
        ),
        createExample(
          "di_ex2",
          "Company sales increased from ₹80 lakhs in 2022 to ₹100 lakhs in 2023. Find percentage increase.",
          "कंपनी की बिक्री 2022 में ₹80 लाख से बढ़कर 2023 में ₹100 लाख हो गई। प्रतिशत वृद्धि ज्ञात कीजिए।",
          listOf(
            "Step 1: Increase = 100 - 80 = ₹20 lakhs.",
            "Step 2: % Increase = (Increase / Base Value) * 100 = (20 / 80) * 100 = 25%."
          ),
          "25%",
          "Base is always initial year 2022."
        ),
        createExample(
          "di_ex3",
          "In a school, 360 students are divided into 4 houses: Red (90), Blue (120), Green (60), Yellow (90). Find the central angle for Blue house.",
          "360 विद्यार्थियों में से 120 नीले सदन में हैं। इसका केंद्रीय कोण क्या होगा?",
          listOf(
            "Step 1: Angle = (Value / Total) * 360°.",
            "Step 2: Angle = (120 / 360) * 360° = 120°."
          ),
          "120°",
          "Direct degree mapping when total is 360."
        )
      ),
      practiceMcqs = listOf(
        createMcq("di_q1", "In a pie chart, 15% corresponds to an angle of:", "", "54°", "45°", "60°", "48°", 0, "15 * 3.6 = 54°."),
        createMcq("di_q2", "Angle of 72° in a pie chart represents what percentage?", "", "20%", "25%", "15%", "18%", 0, "72 / 3.6 = 20%."),
        createMcq("di_q3", "If export rises from 400 to 500 tonnes, percentage growth is:", "", "25%", "20%", "30%", "15%", 0, "(100 / 400) * 100 = 25%."),
        createMcq("di_q4", "If production dropped from 250 units to 200 units, percentage decline is:", "", "20%", "25%", "15%", "18%", 0, "(50 / 250) * 100 = 20%."),
        createMcq("di_q5", "Total sales = 1800 units. If Sector A angle is 60°, units in Sector A are:", "", "300", "250", "360", "200", 0, "(60/360) * 1800 = 1/6 * 1800 = 300 units."),
        createMcq("di_q6", "Ratio of two sections in pie chart is 3:2. Difference between their angles is:", "", "72°", "60°", "36°", "54°", 0, "Total 5 parts = 360° => 1 part = 72°. Difference is 1 part = 72°."),
        createMcq("di_q7", "Expenditure on education is 18° in pie chart. What % of total income is spent on education?", "", "5%", "6%", "4.5%", "7.5%", 0, "18 / 3.6 = 5%."),
        createMcq("di_q8", "A bar chart shows production of 4 years: 50, 60, 75, 90. Average annual production is:", "", "68.75", "70", "65", "72", 0, "(50 + 60 + 75 + 90)/4 = 275/4 = 68.75."),
        createMcq("di_q9", "If ratio of boys to girls is 4:5 in a total student strength of 900, number of girls is:", "", "500", "400", "450", "550", 0, "5/9 * 900 = 500."),
        createMcq("di_q10", "In a line graph, value in 2020 was 120 and in 2024 it was 180. Absolute increase is:", "", "60", "50%", "30", "40", 0, "180 - 120 = 60 units.")
      )
    )
  )
}
