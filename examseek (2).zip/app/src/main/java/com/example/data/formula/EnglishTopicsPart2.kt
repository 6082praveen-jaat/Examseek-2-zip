package com.example.data.formula

import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.data.formula.FormulaTopicBuilder.createExample
import com.example.data.formula.FormulaTopicBuilder.createMcq

object EnglishTopicsPart2 {
  val topics: List<FormulaTopic> = listOf(
    // 15. Direct and Indirect Speech
    FormulaTopic(
      id = "eng_direct_indirect_speech",
      subject = FormulaSubject.ENGLISH,
      chapter = "Advanced Grammar",
      title = "Direct and Indirect Speech",
      hindiTitle = "प्रत्यक्ष एवं अप्रत्यक्ष कथन",
      summary = "Rules for reporting speech: tense shift, pronoun shift (SON rule), change of time/place markers, and question conversions.",
      coreFormula = "SON Rule: 1st person -> Subject of RV; 2nd person -> Object; 3rd person -> No change (N).\nTense Shift: Simple Present -> Simple Past; Present Cont. -> Past Cont.; Present Perf. -> Past Perf.; Simple Past -> Past Perf.\nWill -> Would | Can -> Could | May -> Might",
      symbolExplanations = listOf(
        "Reporting Verb (RV)" to "Said, said to (changes to told), asked, commanded, advised.",
        "Reported Speech (RS)" to "The actual words inside quotation marks.",
        "SON Formula" to "1 = Subject, 2 = Object, 3 = No change."
      ),
      importantIdentities = listOf(
        "Universal truth or scientific fact NEVER undergoes tense change in reported speech.",
        "If reporting verb is in Present or Future tense (says, will say), tense of reported speech does NOT change.",
        "Inverted commas become 'that' in assertive, 'if/whether' in yes/no questions, same wh-word in wh-questions."
      ),
      shortcutsAndTips = listOf(
        "In questions, invert inverted question structure (verb + subject) to assertive structure (subject + verb)."
      ),
      commonMistakes = listOf(
        "Using 'that' along with 'if/whether' or 'wh-word' (e.g. 'He asked that if I was ready' is INCORRECT; omit 'that')."
      ),
      solvedExamples = listOf(
        createExample(
          "narr_ex1",
          "Convert to indirect: He said to me, \"I am reading your book today.\"",
          "अप्रत्यक्ष कथन में बदलिए: He said to me, \"I am reading your book today.\"",
          listOf(
            "Step 1: 'said to' -> 'told'; comma becomes 'that'.",
            "Step 2: Pronouns: 'I' -> 'he'; 'your' -> 'my'.",
            "Step 3: Tense: 'am reading' -> 'was reading'.",
            "Step 4: Time marker: 'today' -> 'that day'.",
            "Step 5: Result: 'He told me that he was reading my book that day.'"
          ),
          "He told me that he was reading my book that day.",
          "Apply SON pronoun rule + past tense shift + today -> that day."
        ),
        createExample(
          "narr_ex2",
          "Convert: The teacher said, \"The sun rises in the east.\"",
          "बदलिए: The teacher said, \"The sun rises in the east.\"",
          listOf(
            "Step 1: 'The sun rises in the east' is a universal truth.",
            "Step 2: Exception rule applies: Universal truths retain their original tense.",
            "Step 3: Result: 'The teacher said that the sun rises in the east.'"
          ),
          "The teacher said that the sun rises in the east.",
          "Universal truths do not change tense."
        ),
        createExample(
          "narr_ex3",
          "Convert: She said to him, \"Where are you living now?\"",
          "बदलिए: She said to him, \"Where are you living now?\"",
          listOf(
            "Step 1: Interrogative sentence -> 'said to' becomes 'asked'.",
            "Step 2: Wh-word 'where' acts as connector.",
            "Step 3: Change word order to affirmative: 'you are living' -> 'he was living'; 'now' -> 'then'.",
            "Step 4: Result: 'She asked him where he was living then.'"
          ),
          "She asked him where he was living then.",
          "Assertive order (where + subject + verb)."
        )
      ),
      practiceMcqs = listOf(
        createMcq("narr_q1", "Indirect: He said, \"I have finished my work.\"", "", "He said that he had finished his work.", "He said that he has finished his work.", "He said that I had finished my work.", "He said he finished his work.", 0, "Present Perfect 'have finished' changes to Past Perfect 'had finished'."),
        createMcq("narr_q2", "Indirect: She said to me, \"Do you know French?\"", "", "She asked me if I knew French.", "She asked me that if I know French.", "She told me do I know French.", "She asked me whether do I know French.", 0, "Yes/no questions use 'if/whether' + assertive past order 'I knew'."),
        createMcq("narr_q3", "Indirect: The doctor said to the patient, \"Take this medicine daily.\"", "", "The doctor advised the patient to take that medicine daily.", "The doctor said to take this medicine.", "The doctor ordered that take medicine.", "The doctor told patient taking medicine.", 0, "Imperatives use reporting verb 'advised' + 'to + V1'."),
        createMcq("narr_q4", "Indirect: Ram says, \"I am very busy today.\"", "", "Ram says that he is very busy today.", "Ram said that he was very busy that day.", "Ram says that he was busy that day.", "Ram told that he is busy.", 0, "When reporting verb is present ('says'), tense of reported speech does not change!"),
        createMcq("narr_q5", "Indirect: She said, \"Alas! I have lost my purse.\"", "", "She exclaimed with sorrow that she had lost her purse.", "She said with sorrow that I lost purse.", "She cried that she lost purse.", "She exclaimed that alas her purse was lost.", 0, "Exclamations with 'Alas!' become 'exclaimed with sorrow that'."),
        createMcq("narr_q6", "'Yesterday' in direct speech becomes what in indirect speech?", "", "The previous day / the day before", "Tomorrow", "The next day", "That day", 0, "Time shift: yesterday -> the previous day / the day before."),
        createMcq("narr_q7", "Indirect: He said to her, \"Why are you sad?\"", "", "He asked her why she was sad.", "He asked her that why was she sad.", "He inquired why was she sad.", "He told her why she is sad.", 0, "Wh-question word order in indirect speech is Wh + Subject + Verb."),
        createMcq("narr_q8", "What does 'SON' stand for in narration pronoun rules?", "", "1st person -> Subject, 2nd -> Object, 3rd -> No change", "Subject, Object, Noun", "Single, Opposite, Neutral", "Simple, Objective, Nominative", 0, "1st=Subject, 2nd=Object, 3rd=No change."),
        createMcq("narr_q9", "Indirect: The teacher said, \"Water boils at 100°C.\"", "", "The teacher said that water boils at 100°C.", "The teacher said that water boiled at 100°C.", "The teacher said water had boiled.", "The teacher told water boils at 100°C.", 0, "Scientific facts retain present tense."),
        createMcq("narr_q10", "Indirect: \"Don't make noise,\" the librarian said.", "", "The librarian forbade them to make noise.", "The librarian told not make noise.", "The librarian said that don't make noise.", "The librarian ordered to not make noise.", 0, "'Forbade' incorporates the negative; followed by 'to + V1'.")
      )
    ),
    // 16. Conditional Sentences
    FormulaTopic(
      id = "eng_conditional_sentences",
      subject = FormulaSubject.ENGLISH,
      chapter = "Advanced Grammar",
      title = "Conditional Sentences",
      hindiTitle = "शर्तबोधक वाक्य",
      summary = "Zero, 1st, 2nd, 3rd, and Mixed conditionals governing tense pairing between If-clause and Main clause.",
      coreFormula = "Zero Conditional: If + Simple Present, Simple Present (Truth)\nFirst Conditional (Real): If + Simple Present, will/can/may + V1\nSecond Conditional (Hypothetical): If + Simple Past (were/V2), would/could/might + V1\nThird Conditional (Unfulfilled Past): If + Past Perfect (had + V3), would/could/might + have + V3\nInversion: Had + Subject + V3, Subject + would have + V3",
      symbolExplanations = listOf(
        "If-clause" to "Subordinate clause presenting condition.",
        "Main clause" to "Result clause showing outcome.",
        "Subjunctive 'were'" to "Used with all subjects in hypothetical second conditional: 'If I were a king'."
      ),
      importantIdentities = listOf(
        "Never use 'will' or 'would' inside the If-clause itself.",
        "Third conditional inversion replaces 'If': 'If he had studied' = 'Had he studied'."
      ),
      shortcutsAndTips = listOf(
        "Check tense pairing: had + V3 requires would have + V3; simple past requires would + V1."
      ),
      commonMistakes = listOf(
        "Writing 'If I was you' (Formal grammar requires subjunctive 'If I were you')."
      ),
      solvedExamples = listOf(
        createExample(
          "cond_ex1",
          "Identify and correct: 'If he had worked hard, he would pass the exam.'",
          "सुधारें: 'If he had worked hard, he would pass the exam.'",
          listOf(
            "Step 1: If-clause uses 'had worked' (Past Perfect -> Third Conditional).",
            "Step 2: Third Conditional formula: If + had + V3, would have + V3.",
            "Step 3: Result: 'he would have passed the exam.'"
          ),
          "If he had worked hard, he would have passed the exam.",
          "Past Perfect in If-clause mandates 'would have + V3'."
        ),
        createExample(
          "cond_ex2",
          "Complete: 'If I _____ (be) a bird, I would fly around the world.'",
          "पूर्ण करें: 'If I _____ a bird, I would fly around the world.'",
          listOf(
            "Step 1: Hypothetical/unreal present condition (Second Conditional).",
            "Step 2: Main clause has 'would fly' (would + V1).",
            "Step 3: Subjunctive mood requires 'were' for all persons.",
            "Step 4: Answer: 'were'."
          ),
          "were",
          "Subjunctive condition uses 'were' with singular subjects."
        ),
        createExample(
          "cond_ex3",
          "Rewrite using Inversion: 'If they had invited us, we would have attended.'",
          "व्युत्क्रम (Inversion) का उपयोग करके पुनः लिखें:",
          listOf(
            "Step 1: Drop 'If'.",
            "Step 2: Invert auxiliary 'had' before subject 'they'.",
            "Step 3: Result: 'Had they invited us, we would have attended.'"
          ),
          "Had they invited us, we would have attended.",
          "Inversion pattern: Had + Subject + V3."
        )
      ),
      practiceMcqs = listOf(
        createMcq("cond_q1", "If it rains tomorrow, we _____ the picnic.", "", "will cancel", "would cancel", "cancelled", "would have cancelled", 0, "First conditional: If + Simple Present, will + V1."),
        createMcq("cond_q2", "If I _____ rich, I would help the needy.", "", "were", "was", "am", "have been", 0, "Second conditional imaginary: use subjunctive 'were'."),
        createMcq("cond_q3", "Had she known about the meeting, she _____ it.", "", "would have attended", "would attend", "will attend", "had attended", 0, "Third conditional inversion: Had + V3 -> would have + V3."),
        createMcq("cond_q4", "Which sentence is grammatically INCORRECT?", "", "If you will come, I will help you.", "If you come, I will help you.", "Unless you study, you will fail.", "If water reaches 100°C, it boils.", 0, "'Will' is not used in the condition clause."),
        createMcq("cond_q5", "If you heat ice, it _____.", "", "melts", "will melt", "melted", "would melt", 0, "Zero conditional for universal physical truths takes simple present in both clauses."),
        createMcq("cond_q6", "If I had had money, I _____ a new car.", "", "would have bought", "would buy", "bought", "will buy", 0, "'had had' = past perfect of 'have'; requires would have + V3."),
        createMcq("cond_q7", "Unless you apologize, he _____ forgive you.", "", "will not", "will", "would not", "does not", 0, "Unless = if not; main clause retains negative meaning."),
        createMcq("cond_q8", "What conditional type is: 'If I won a lottery, I would travel the globe'?", "", "Second Conditional (Hypothetical)", "First Conditional", "Zero Conditional", "Third Conditional", 0, "Simple Past + would + V1 = Second conditional."),
        createMcq("cond_q9", "Had he informed in advance, arrangements _____ made.", "", "could have been", "can be", "will be", "could be", 0, "Passive third conditional: could have been + V3."),
        createMcq("cond_q10", "As soon as he arrives, we _____ the meeting.", "", "will start", "would start", "started", "start", 0, "Time clause condition: Present simple followed by future simple.")
      )
    ),
    // 17. Question Tags
    FormulaTopic(
      id = "eng_question_tags",
      subject = FormulaSubject.ENGLISH,
      chapter = "Grammar Mechanics",
      title = "Question Tags",
      hindiTitle = "प्रश्न पुछल्ले",
      summary = "Short confirmation questions appended to statements: positive statements take negative tags, negative statements take positive tags.",
      coreFormula = "Positive Statement + Negative Tag (Auxiliary + n't + Pronoun?)\nNegative Statement + Positive Tag (Auxiliary + Pronoun?)\nI am -> aren't I?\nLet's -> shall we?\nImperatives -> will you? / won't you?\nSentences with negative words (hardly, scarcely, seldom, never, few, little) -> Positive Tag",
      symbolExplanations = listOf(
        "Auxiliary verb" to "Do, does, did, is, are, was, were, has, have, can, will, etc.",
        "Pronoun" to "Must always be a personal pronoun matching the subject; never a noun."
      ),
      importantIdentities = listOf(
        "Words like 'hardly, seldom, scarcely, barely, rarely, nobody, nothing, few, little' are inherently negative; tag MUST BE POSITIVE.",
        "'A few' and 'a little' are positive; tag MUST BE NEGATIVE.",
        "Indefinite pronouns for persons (everyone, someone, nobody) take plural pronoun 'they' in the question tag."
      ),
      shortcutsAndTips = listOf(
        "For 'I am late', the standard question tag is 'aren't I?' (not 'amn't I')."
      ),
      commonMistakes = listOf(
        "Using negative tag after words like 'seldom' or 'barely' (correct: 'does he?')."
      ),
      solvedExamples = listOf(
        createExample(
          "tag_ex1",
          "Add question tag: 'She hardly speaks during meetings, _____?'",
          "प्रश्न टैग जोड़ें: 'She hardly speaks during meetings, _____?'",
          listOf(
            "Step 1: 'hardly' makes the statement semantically NEGATIVE.",
            "Step 2: Negative statement requires a POSITIVE tag.",
            "Step 3: Verb 'speaks' is Simple Present (takes auxiliary 'does').",
            "Step 4: Result: 'does she?'"
          ),
          "does she?",
          "'hardly' is negative, so tag must be positive."
        ),
        createExample(
          "tag_ex2",
          "Add question tag: 'Everybody has finished the task, _____?'",
          "प्रश्न टैग जोड़ें: 'Everybody has finished the task, _____?'",
          listOf(
            "Step 1: 'Everybody' takes pronoun 'they' in question tag.",
            "Step 2: With pronoun 'they', auxiliary 'has' changes to plural form 'have'.",
            "Step 3: Positive statement takes negative tag: 'haven't they?'."
          ),
          "haven't they?",
          "'Everybody' converts to 'they', which requires plural auxiliary 'haven't'."
        ),
        createExample(
          "tag_ex3",
          "Add question tag: 'Let's go for an evening walk, _____?'",
          "प्रश्न टैग जोड़ें: 'Let's go for an evening walk, _____?'",
          listOf(
            "Step 1: 'Let's' expresses a proposal/suggestion.",
            "Step 2: Standard rule for 'Let's': the tag is always 'shall we?'.",
            "Step 3: Result: 'shall we?'."
          ),
          "shall we?",
          "Rule: Suggestions with 'Let's' always take 'shall we?'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("tag_q1", "I am right, _____?", "", "aren't I?", "am not I?", "isn't I?", "don't I?", 0, "Standard contraction for 'am I not' in tags is 'aren't I?'."),
        createMcq("tag_q2", "He seldom comes here on Sundays, _____?", "", "does he?", "doesn't he?", "is he?", "isn't he?", 0, "'Seldom' makes the statement negative; tag is positive."),
        createMcq("tag_q3", "Close the door, _____?", "", "will you?", "can't you?", "shall we?", "do you?", 0, "Imperative sentences take 'will you?'."),
        createMcq("tag_q4", "Nobody called for me, _____?", "", "did they?", "didn't they?", "did he?", "didn't he?", 0, "'Nobody' is negative and takes pronoun 'they' -> positive tag 'did they?'."),
        createMcq("tag_q5", "You have a car, _____?", "", "don't you? / haven't you?", "have you?", "do you?", "isn't it?", 0, "Possessive 'have' takes 'don't you?' or 'haven't you?'."),
        createMcq("tag_q6", "Let us participate in the competition, _____?", "", "shall we?", "will we?", "can we?", "don't we?", 0, "Proposals with 'Let us' take 'shall we?'."),
        createMcq("tag_q7", "There are twenty students in the hall, _____?", "", "aren't there?", "are there?", "aren't they?", "isn't it?", 0, "Introductory 'there' is repeated in the tag as 'there'."),
        createMcq("tag_q8", "She has little hope of success, _____?", "", "has she?", "hasn't she?", "does she?", "doesn't she?", 0, "'Little' is negative; tag is positive 'has she?'."),
        createMcq("tag_q9", "She has a little hope of recovery, _____?", "", "hasn't she?", "has she?", "isn't it?", "doesn't she?", 0, "'A little' is positive; tag is negative 'hasn't she?'."),
        createMcq("tag_q10", "Don't spit on the floor, _____?", "", "will you?", "won't you?", "shall you?", "do you?", 0, "Negative imperative 'Don't...' takes positive tag 'will you?'.")
      )
    ),
    // 18. Clauses
    FormulaTopic(
      id = "eng_clauses",
      subject = FormulaSubject.ENGLISH,
      chapter = "Sentence Structure",
      title = "Clauses",
      hindiTitle = "उपवाक्य",
      summary = "Independent and Dependent clauses: Noun Clauses, Adjective Clauses, and Adverb Clauses.",
      coreFormula = "Clause = Subject + Finite Verb\nMain Clause (Independent): Can stand alone as complete sentence.\nSubordinate Clause (Dependent): Introduced by subordinating conjunction; cannot stand alone.\n1. Noun Clause: Answers 'What?' about verb.\n2. Adjective Clause: Modifies preceding noun (who, whom, whose, which, that).\n3. Adverb Clause: Modifies verb/adjective (when, where, why, how, condition).",
      symbolExplanations = listOf(
        "Relative Pronoun" to "Who, whom, whose, which, that.",
        "Subordinating Conjunction" to "Because, although, since, unless, while, where, as if."
      ),
      importantIdentities = listOf(
        "A phrase has no subject-verb combination; a clause MUST have both.",
        "Restrictive relative clauses use 'that' and NO commas; non-restrictive clauses use 'which/who' WITH commas."
      ),
      shortcutsAndTips = listOf(
        "Substitute the entire clause with 'something'. If it makes sense, it is a Noun Clause."
      ),
      commonMistakes = listOf(
        "Using comma splice (joining two independent clauses with only a comma)."
      ),
      solvedExamples = listOf(
        createExample(
          "clause_ex1",
          "Identify the type of underlined clause: 'I know the girl *who won the gold medal*.'",
          "उपवाक्य का प्रकार पहचानिए: 'I know the girl who won the gold medal.'",
          listOf(
            "Step 1: The clause 'who won the gold medal' describes the noun 'the girl'.",
            "Step 2: A clause qualifying a noun is an ADJECTIVE (RELATIVE) CLAUSE.",
            "Step 3: Answer: Adjective Clause."
          ),
          "Adjective Clause",
          "Modifies the antecedent noun 'the girl'."
        ),
        createExample(
          "clause_ex2",
          "Identify: 'He said *that he was feeling unwell*.'",
          "पहचानिए: 'He said that he was feeling unwell.'",
          listOf(
            "Step 1: Ask: What did he say?",
            "Step 2: The clause acts as the direct object of the transitive verb 'said'.",
            "Step 3: A clause functioning as an object is a NOUN CLAUSE."
          ),
          "Noun Clause",
          "Functions as direct object of transitive verb 'said'."
        ),
        createExample(
          "clause_ex3",
          "Identify: 'We cannot start the match *unless the rain stops*.'",
          "पहचानिए: 'We cannot start the match unless the rain stops.'",
          listOf(
            "Step 1: The clause expresses a condition for the action 'start'.",
            "Step 2: A clause indicating condition is an ADVERB CLAUSE OF CONDITION.",
            "Step 3: Answer: Adverb Clause."
          ),
          "Adverb Clause of Condition",
          "Modifies the main verb 'start' by stating condition."
        )
      ),
      practiceMcqs = listOf(
        createMcq("clause_q1", "'What you say is completely true.' What type of clause is 'What you say'?", "", "Noun Clause (Subject)", "Adjective Clause", "Adverb Clause", "Coordinate Clause", 0, "Acts as the subject of verb 'is' -> Noun Clause."),
        createMcq("clause_q2", "'This is the house *where Tagore was born*.' The clause is:", "", "Adjective Clause", "Noun Clause", "Adverb Clause of Place", "Prepositional Clause", 0, "Modifies noun 'the house' -> Adjective clause."),
        createMcq("clause_q3", "'Work hard *lest you should fail*.' The clause is an Adverb Clause of:", "", "Purpose", "Condition", "Reason", "Concession", 0, "'Lest... should' indicates negative purpose."),
        createMcq("clause_q4", "Which conjunction introduces an Adverb Clause of Concession?", "", "Although / Even though", "Because", "Unless", "So that", 0, "'Although' and 'even though' show concession/contrast."),
        createMcq("clause_q5", "Difference between a phrase and a clause is:", "", "A clause has a subject and finite verb, a phrase does not.", "A phrase has a subject, clause does not.", "Both are identical.", "Phrases are always longer.", 0, "Clauses require both subject and finite verb."),
        createMcq("clause_q6", "'He failed *because he did not study*.' Type of clause:", "", "Adverb Clause of Reason", "Noun Clause", "Adjective Clause", "Relative Clause", 0, "States the cause/reason for failing."),
        createMcq("clause_q7", "Which relative pronoun is used for non-restrictive parenthetical clauses?", "", "Which / Who (with commas)", "That", "What", "Whichever", 0, "Non-restrictive relative clauses use 'which/who' with commas."),
        createMcq("clause_q8", "'I will call you *as soon as I arrive*.' Type:", "", "Adverb Clause of Time", "Noun Clause", "Adjective Clause", "Condition Clause", 0, "Indicates time of occurrence."),
        createMcq("clause_q9", "'He talks *as if he knew everything*.' The clause indicates:", "", "Manner / Comparison", "Time", "Place", "Reason", 0, "'As if' introduces adverb clause of manner."),
        createMcq("clause_q10", "'The news *that he died* shocked us.' The clause is:", "", "Noun Clause in Apposition to 'news'", "Adjective Clause", "Adverb Clause", "Coordinate Clause", 0, "Explains the content of noun 'news' in apposition.")
      )
    ),
    // 19. Sentence Correction
    FormulaTopic(
      id = "eng_sentence_correction",
      subject = FormulaSubject.ENGLISH,
      chapter = "Applied Grammar & Error Elimination",
      title = "Sentence Correction",
      hindiTitle = "वाक्य सुधार",
      summary = "Systematic elimination strategy: parallelism, dangling modifiers, redundant phrasing, and idioms.",
      coreFormula = "Three Golden Pillars of Correction:\n1. Parallelism: Elements connected by and/or/than must share identical grammatical form.\n2. Modifier Placement: Modifying phrase must immediately follow or precede the noun it actually modifies.\n3. Redundancy Elimination: Omit tautological expressions (return back -> return; blunder mistake -> blunder).",
      symbolExplanations = listOf(
        "Parallelism" to "She likes reading, writing, and dancing (all V+ing).",
        "Dangling Modifier" to "A modifier whose intended subject is missing or detached from it.",
        "Redundancy" to "Unnecessary repetition of meaning."
      ),
      importantIdentities = listOf(
        "'Not only... but also' parallelism: Structure following 'not only' must match structure following 'but also'."
      ),
      shortcutsAndTips = listOf(
        "Scan options for subject-verb agreement first, then parallelism, then modifier position."
      ),
      commonMistakes = listOf(
        "Writing 'Walking down the road, a car hit him.' (This wrongly implies the car was walking down the road!)."
      ),
      solvedExamples = listOf(
        createExample(
          "sc_ex1",
          "Correct: 'Walking in the park, a snake bit him.'",
          "सुधारें: 'Walking in the park, a snake bit him.'",
          listOf(
            "Step 1: 'Walking in the park' attaches to subject 'a snake' (absurd).",
            "Step 2: Fix by providing the logical subject: 'While he was walking in the park, a snake bit him.'"
          ),
          "While he was walking in the park, a snake bit him.",
          "Fixes dangling modifier by supplying the true agent."
        ),
        createExample(
          "sc_ex2",
          "Correct: 'She not only visited London but also Paris.'",
          "सुधारें: 'She not only visited London but also Paris.'",
          listOf(
            "Step 1: Check elements linked: 'London' and 'Paris' (nouns).",
            "Step 2: Move verb outside: 'She visited not only London but also Paris.'"
          ),
          "She visited not only London but also Paris.",
          "Parallelism: 'not only [Noun] but also [Noun]'."
        ),
        createExample(
          "sc_ex3",
          "Correct: 'He will return back from New Delhi tomorrow.'",
          "सुधारें: 'He will return back from New Delhi tomorrow.'",
          listOf(
            "Step 1: 'Return' already means 'come back'.",
            "Step 2: Using 'back' with 'return' is redundant.",
            "Step 3: Correct sentence: 'He will return from New Delhi tomorrow.'"
          ),
          "He will return from New Delhi tomorrow.",
          "Eliminate redundant word 'back'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("sc_q1", "Correct: 'She enjoys swimming, jogging, and to cycle.'", "", "She enjoys swimming, jogging, and cycling.", "She enjoys to swim, jogging, and cycling.", "She enjoys swim, jog, and cycle.", "No correction needed.", 0, "Parallel structure requires all gerunds: swimming, jogging, and cycling."),
        createMcq("sc_q2", "Correct: 'Being a rainy day, we decided to stay at home.'", "", "It being a rainy day, we decided to stay at home.", "We being a rainy day, decided to stay.", "Since a rainy day, we stayed.", "No correction needed.", 0, "'Being a rainy day' is a dangling participle; needs pronoun 'It'."),
        createMcq("sc_q3", "Correct: 'He is taller than any boy in the class.'", "", "He is taller than any other boy in the class.", "He is taller than all boys.", "He is the tallest than any boy.", "No correction needed.", 0, "Comparative exclusion requires 'any other boy'."),
        createMcq("sc_q4", "Identify redundancy: 'Please repeat the question again.'", "", "Omit 'again'", "Omit 'repeat'", "Omit 'please'", "Change to 're-repeat'", 0, "'Repeat' already means say again; 'again' is redundant."),
        createMcq("sc_q5", "Correct: 'Neither he nor his friends has arrived.'", "", "Neither he nor his friends have arrived.", "Neither he or his friends has arrived.", "Neither him nor his friends have arrived.", "No correction needed.", 0, "Verb agrees with nearest subject 'friends' (plural) -> 'have arrived'."),
        createMcq("sc_q6", "Correct: 'He is both intelligent as well as hardworking.'", "", "He is both intelligent and hardworking.", "He is both intelligent but hardworking.", "He is intelligent as well as both hardworking.", "No correction needed.", 0, "Correlative pair of 'both' is 'and'."),
        createMcq("sc_q7", "Correct: 'I prefer coffee than tea.'", "", "I prefer coffee to tea.", "I prefer coffee over tea.", "I prefer coffee more than tea.", "No correction needed.", 0, "'Prefer' and 'preferable' take preposition 'to'."),
        createMcq("sc_q8", "Identify redundant phrase in: 'He made a blunder mistake.'", "", "'Blunder mistake' -> use only 'blunder'", "'Made a'", "'He made'", "No redundancy", 0, "A 'blunder' is by definition a big mistake; 'blunder mistake' is redundant."),
        createMcq("sc_q9", "Correct: 'No sooner did he arrive then the meeting started.'", "", "No sooner did he arrive than the meeting started.", "No sooner had he arrived then...", "No sooner did he arrive when...", "No correction needed.", 0, "Correlative partner of 'No sooner' is 'than'."),
        createMcq("sc_q10", "Correct: 'Scarcely had he reached the station than the train left.'", "", "Scarcely had he reached the station when the train left.", "Scarcely did he reach then...", "Scarcely had he reached before...", "No correction needed.", 0, "'Scarcely' pairs with 'when'.")
      )
    ),
    // 20. Error Spotting
    FormulaTopic(
      id = "eng_error_spotting",
      subject = FormulaSubject.ENGLISH,
      chapter = "Applied Grammar & Error Elimination",
      title = "Error Spotting",
      hindiTitle = "त्रुटि पहचानना",
      summary = "Systematic protocol for spotting grammatical errors: SV agreement, tense consistency, pronoun-antecedent agreement.",
      coreFormula = "5-Step Error Spotting Protocol:\n1. Check Subject-Verb Agreement\n2. Inspect Tenses\n3. Verify Pronoun References\n4. Inspect Prepositions\n5. Check Articles & Parallelism",
      symbolExplanations = listOf(
        "Subjective Case" to "I, he, she, they, who.",
        "Objective Case" to "Me, him, her, them, whom."
      ),
      importantIdentities = listOf(
        "Between you and me (NEVER 'between you and I').",
        "'One of the + Plural Noun + Singular Verb' UNLESS preceded by relative pronoun 'who/that'."
      ),
      shortcutsAndTips = listOf(
        "Ignore parenthetical prepositional phrases between subject and verb to avoid distraction."
      ),
      commonMistakes = listOf(
        "Using objective pronoun after 'than' in comparative formal sentences."
      ),
      solvedExamples = listOf(
        createExample(
          "es_ex1",
          "Spot error: 'One of the issue (A) / raised by members (B) / was ignored (C) / No error (D)'",
          "त्रुटि पहचानिए: 'One of the issue (A) / raised by members (B) / was ignored (C)'",
          listOf(
            "Step 1: Formula: 'One of the + Plural Noun + Singular Verb'.",
            "Step 2: Here part (A) contains singular noun 'issue' instead of plural 'issues'.",
            "Step 3: Error is in part (A)."
          ),
          "Part (A): 'issue' should be 'issues'",
          "Rule: 'One of the' must be followed by a plural noun."
        ),
        createExample(
          "es_ex2",
          "Spot error: 'This secret is strictly (A) / between you and I (B) / so do not disclose it (C)'",
          "त्रुटि पहचानिए: 'between you and I'",
          listOf(
            "Step 1: 'Between' is a preposition.",
            "Step 2: Prepositions govern OBJECTIVE case.",
            "Step 3: Objective case of 'I' is 'me'.",
            "Step 4: Error is in part (B): 'between you and me'."
          ),
          "Part (B): 'you and I' should be 'you and me'",
          "Prepositions must be followed by objective case pronouns."
        ),
        createExample(
          "es_ex3",
          "Spot error: 'The police has arrested (A) / two suspects (B) / in the robbery (C)'",
          "त्रुटि पहचानिए: 'The police has arrested'",
          listOf(
            "Step 1: 'Police' is an inherently PLURAL collective noun.",
            "Step 2: It must take a plural auxiliary verb 'have'.",
            "Step 3: Error is in part (A): 'The police have arrested'."
          ),
          "Part (A): 'has' should be 'have'",
          "'Police' is plural in English grammar."
        )
      ),
      practiceMcqs = listOf(
        createMcq("es_q1", "Spot error: 'He is one of those men who (A) / always supports (B) / the truth (C)'", "", "Part (B) 'supports' -> 'support'", "Part (A)", "Part (C)", "No error (D)", 0, "Antecedent of 'who' is plural 'men', so verb must be plural 'support'."),
        createMcq("es_q2", "Spot error: 'Unless you do not give up bad habits (A) / you will suffer (B)'", "", "Part (A) 'do not give up' -> 'give up'", "Part (B)", "Part (C)", "No error (D)", 0, "'Unless' already means 'if not'; double negative error."),
        createMcq("es_q3", "Spot error: 'The cattle is grazing (A) / in pastures (B)'", "", "Part (A) 'is' -> 'are'", "Part (B)", "Part (C)", "No error (D)", 0, "'Cattle' is inherently plural."),
        createMcq("es_q4", "Spot error: 'Each of the girls (A) / have brought (B) / their books (C)'", "", "Part (B) & (C) -> 'has brought her book'", "Part (A)", "Part (C) only", "No error (D)", 0, "'Each of' takes singular verb 'has' and singular pronoun 'her'."),
        createMcq("es_q5", "Spot error: 'The scenery of Kashmir (A) / are more beautiful (B) / than Shimla (C)'", "", "Part (B) 'are' -> 'is'", "Part (A)", "Part (C)", "No error (D)", 0, "'Scenery' is uncountable and singular."),
        createMcq("es_q6", "Spot error: 'She insisted to go (A) / to cinema (B)'", "", "Part (A) 'insisted to go' -> 'insisted on going'", "Part (B)", "Part (C)", "No error (D)", 0, "Verb 'insist' takes preposition 'on + Gerund'."),
        createMcq("es_q7", "Spot error: 'He did not knew (A) / the answer (B)'", "", "Part (A) 'did not knew' -> 'did not know'", "Part (B)", "Part (C)", "No error (D)", 0, "Auxiliary 'did' must be followed by base form V1 ('know')."),
        createMcq("es_q8", "Spot error: 'He is senior than me (A) / in service (B)'", "", "Part (A) 'senior than' -> 'senior to'", "Part (B)", "Part (C)", "No error (D)", 0, "Latin adjectives ending in -ior take 'to'."),
        createMcq("es_q9", "Spot error: 'Suppose if you fail, (A) / what will you do (B)'", "", "Part (A) 'Suppose if' -> use either 'Suppose' or 'If'", "Part (B)", "Part (C)", "No error (D)", 0, "'Suppose if' is redundant."),
        createMcq("es_q10", "Spot error: 'I prefer tea (A) / than coffee (B) / in the morning (C)'", "", "Part (B) 'than' -> 'to'", "Part (A)", "Part (C)", "No error (D)", 0, "'Prefer' takes 'to'.")
      )
    ),
    // 21. Degrees of Comparison
    FormulaTopic(
      id = "eng_degrees_of_comparison",
      subject = FormulaSubject.ENGLISH,
      chapter = "Adjective & Adverb Formations",
      title = "Degrees of Comparison",
      hindiTitle = "तुलना की अवस्थाएं",
      summary = "Positive, Comparative, and Superlative degrees of adjectives and adverbs; transformation rules.",
      coreFormula = "Degrees Structure:\n1. Positive: as + Adj + as (affirmative) | so/as + Adj + as (negative)\n2. Comparative: Adj-er + than | more + Adj + than\n3. Superlative: the + Adj-est | the most + Adj\nTransformation:\nSuperlative: Subject + is the + Superlative + of all\nComparative: Subject + is + Comparative + than any other + singular noun\nPositive: No other + singular noun + is as + Positive + as + Subject",
      symbolExplanations = listOf(
        "Monosyllabic" to "Take -er and -est (tall -> taller -> tallest).",
        "Polysyllabic" to "Take more and most (beautiful -> more beautiful -> most beautiful)."
      ),
      importantIdentities = listOf(
        "Never use double comparative or double superlative (e.g. 'more taller' is INCORRECT).",
        "When comparing two things, use Comparative degree ('He is the taller of the two brothers')."
      ),
      shortcutsAndTips = listOf(
        "In comparisons within same group, always use 'any other' ('Iron is more useful than any other metal')."
      ),
      commonMistakes = listOf(
        "Omitting 'other' when comparing a member with its own class."
      ),
      solvedExamples = listOf(
        createExample(
          "deg_ex1",
          "Convert to Positive degree: 'Lead is the heaviest of all metals.'",
          "पॉजिटिव डिग्री में बदलिए: 'Lead is the heaviest of all metals.'",
          listOf(
            "Step 1: Superlative is 'the heaviest'.",
            "Step 2: Formula for Positive: 'No other + singular noun + is as + positive adjective + as + subject'.",
            "Step 3: Result: 'No other metal is as heavy as lead.'"
          ),
          "No other metal is as heavy as lead.",
          "Superlative converts to 'No other... as heavy as'."
        ),
        createExample(
          "deg_ex2",
          "Convert to Comparative: 'No other boy in the team is as energetic as Rohan.'",
          "कम्पैरेटिव डिग्री में बदलिए:",
          listOf(
            "Step 1: Positive degree is 'as energetic as'.",
            "Step 2: Formula for Comparative: 'Subject + is more energetic than any other boy'.",
            "Step 3: Result: 'Rohan is more energetic than any other boy in the team.'"
          ),
          "Rohan is more energetic than any other boy in the team.",
          "Use 'more energetic than any other'."
        ),
        createExample(
          "deg_ex3",
          "Choose correct form: 'Of the two options, this one is the _____ (good / better / best).'",
          "सही रूप चुनिए:",
          listOf(
            "Step 1: The comparison is strictly between TWO items.",
            "Step 2: When choosing between exactly two, use the COMPARATIVE degree preceded by 'the'.",
            "Step 3: Correct adjective form is 'better'."
          ),
          "the better",
          "Comparison of two takes 'the + comparative degree'."
        )
      ),
      practiceMcqs = listOf(
        createMcq("deg_q1", "Positive degree of 'Mount Everest is the highest peak in the world':", "", "No other peak in the world is as high as Mount Everest.", "Mount Everest is higher than any peak.", "Very few peaks are as high as Mount Everest.", "Mount Everest is high peak.", 0, "Standard transformation: 'No other peak... is as high as'."),
        createMcq("deg_q2", "Identify the grammatically correct comparative sentence:", "", "Gold is more precious than any other metal.", "Gold is more precious than any metal.", "Gold is more precious than all metal.", "Gold is much precious than any other metal.", 0, "'Any other' excludes gold from the category of metals."),
        createMcq("deg_q3", "Which sentence contains a double comparative error?", "", "She is more cleverer than her sister.", "She is cleverer than her sister.", "She is more clever than her sister.", "She is the cleverest of all.", 0, "'More cleverer' is an erroneous double comparative."),
        createMcq("deg_q4", "Comparative degree of 'bad':", "", "worse", "badder", "worst", "more bad", 0, "Irregular: bad -> worse -> worst."),
        createMcq("deg_q5", "'He is the _____ of the two candidates.'", "", "better", "best", "good", "more best", 0, "When comparing exactly two, use 'the + comparative'."),
        createMcq("deg_q6", "Superlative of 'little':", "", "least", "less", "littlest", "lesser", 0, "Irregular: little -> less/lesser -> least."),
        createMcq("deg_q7", "'Very few cities in India are as large as Mumbai.' Comparative form:", "", "Mumbai is larger than most other cities in India.", "Mumbai is larger than any other city.", "Mumbai is the largest city.", "Mumbai is not larger than other cities.", 0, "'Very few... as large as' transforms into 'larger than most other'."),
        createMcq("deg_q8", "What is the difference between 'farther' and 'further'?", "", "Farther refers to physical distance; further refers to additional advancement.", "Both are strictly identical.", "Farther is time; further is distance.", "Farther is superlative.", 0, "Farther = physical distance; further = figurative advancement/additional."),
        createMcq("deg_q9", "'He is as strong as his brother.' Meaning:", "", "Both have equal strength.", "He is stronger than his brother.", "His brother is stronger.", "Neither is strong.", 0, "'as... as' denotes equal degree."),
        createMcq("deg_q10", "'This is the most unique opportunity.' What is wrong?", "", "'Unique' is an absolute adjective that cannot take 'most'.", "Nothing is wrong.", "'Unique' should be 'uniquer'.", "'Most' should be 'more'.", 0, "Absolute adjectives do not take comparative/superlative modifiers.")
      )
    ),
    // 22. Transformation of Sentences
    FormulaTopic(
      id = "eng_transformation_of_sentences",
      subject = FormulaSubject.ENGLISH,
      chapter = "Advanced Grammar",
      title = "Transformation of Sentences",
      hindiTitle = "वाक्यों का रूपांतरण",
      summary = "Converting sentence structures without changing meaning: Simple, Compound, Complex; Affirmative to Negative; Removing 'too... to'.",
      coreFormula = "Key Transformation Patterns:\n1. Too... to -> So... that... cannot: 'He is too weak to walk' = 'He is so weak that he cannot walk'.\n2. As soon as... -> No sooner did/had... than...\n3. Simple -> Complex: Expand word/phrase into a subordinate clause.\n4. Affirmative -> Negative: Use antonym + not ('He is honest' = 'He is not dishonest').",
      symbolExplanations = listOf(
        "Simple Sentence" to "One independent clause with one finite verb.",
        "Compound Sentence" to "Two independent clauses joined by coordinating conjunction (FANBOYS).",
        "Complex Sentence" to "One main clause and at least one subordinate clause."
      ),
      importantIdentities = listOf(
        "Meaning must remain 100% invariant; only the syntactic form alters.",
        "When removing 'too... to', check tense: present tense uses 'cannot'; past tense uses 'could not'."
      ),
      shortcutsAndTips = listOf(
        "Remember FANBOYS for compound sentences: For, And, Nor, But, Or, Yet, So."
      ),
      commonMistakes = listOf(
        "Using 'when' instead of 'than' with 'No sooner' during transformation."
      ),
      solvedExamples = listOf(
        createExample(
          "trans_ex1",
          "Remove 'too' without changing meaning: 'He is too proud to beg.'",
          "'Too' हटाएं: 'He is too proud to beg.'",
          listOf(
            "Step 1: Replace 'too' with 'so'.",
            "Step 2: Replace infinitive 'to beg' with 'that he cannot beg' (present tense).",
            "Step 3: Result: 'He is so proud that he cannot beg.'"
          ),
          "He is so proud that he cannot beg.",
          "Formula: too + adj + to + V1 -> so + adj + that + cannot + V1."
        ),
        createExample(
          "trans_ex2",
          "Transform into negative: 'Every rose has a thorn.'",
          "नकारात्मक में बदलें: 'Every rose has a thorn.'",
          listOf(
            "Step 1: Universal affirmative statement.",
            "Step 2: Rule: 'There is no rose without a thorn'.",
            "Step 3: Result: 'There is no rose without a thorn.'"
          ),
          "There is no rose without a thorn.",
          "Meaning remains identical while form becomes negative."
        ),
        createExample(
          "trans_ex3",
          "Convert simple into complex: 'Hearing the loud noise, the child woke up.'",
          "जटिल वाक्य में बदलें:",
          listOf(
            "Step 1: Identify participial phrase 'Hearing the loud noise'.",
            "Step 2: Expand phrase into an adverb clause of time using 'When'.",
            "Step 3: Result: 'When the child heard the loud noise, he woke up.'"
          ),
          "When the child heard the loud noise, he woke up.",
          "Expands participial phrase into an adverbial time clause."
        )
      ),
      practiceMcqs = listOf(
        createMcq("trans_q1", "Remove 'too': 'She was too tired to walk.'", "", "She was so tired that she could not walk.", "She was so tired that she cannot walk.", "She was very tired to walk.", "She is tired so cannot walk.", 0, "Past tense 'was' requires 'could not'."),
        createMcq("trans_q2", "Assertive of: 'Who can challenge the law of nature?'", "", "Nobody can challenge the law of nature.", "Anybody can challenge the law of nature.", "Everybody can challenge the law of nature.", "Can anyone challenge nature?", 0, "Rhetorical positive interrogative transforms into negative assertive ('Nobody')."),
        createMcq("trans_q3", "Negative of 'He is always punctual':", "", "He is never late.", "He is not always punctual.", "He is punctual never.", "He was not late.", 0, "Affirmative to negative via antonym: always punctual -> never late."),
        createMcq("trans_q4", "Transform into compound: 'Besides being hardworking, he is intelligent.'", "", "He is not only hardworking but also intelligent.", "He is hardworking because he is intelligent.", "Although he is hardworking, he is intelligent.", "Being hardworking, he is intelligent.", 0, "'Not only... but also' coordinates two independent statements into compound."),
        createMcq("trans_q5", "Assertive of: 'What a beautiful sunset it is!'", "", "It is a very beautiful sunset.", "It is a beautiful sunset?", "What is this beautiful sunset.", "It is sunset beautiful.", 0, "Exclamatory 'What a...' transforms into 'It is a very...'."),
        createMcq("trans_q6", "Transform 'As soon as the bell rang, students entered class' using 'No sooner':", "", "No sooner did the bell ring than the students entered class.", "No sooner did the bell ring when...", "No sooner had the bell ring then...", "No sooner the bell rang than...", 0, "Formula: No sooner did + Subject + V1 + than..."),
        createMcq("trans_q7", "Convert to complex: 'He admitted his guilt.'", "", "He admitted that he was guilty.", "He admitted his being guilty.", "He was guilty and admitted it.", "Admitting his guilt, he spoke.", 0, "Expands object noun into noun clause 'that he was guilty'."),
        createMcq("trans_q8", "Negative of 'Only graduates can apply for this post':", "", "None but graduates can apply for this post.", "Graduates cannot apply.", "Everyone except graduates can apply.", "No graduates can apply.", 0, "'Only' for persons transforms into 'None but'."),
        createMcq("trans_q9", "Remove 'too': 'The news is too good to be true.'", "", "The news is so good that it cannot be true.", "The news is good and cannot be true.", "The news is so good that it can be true.", "The news is very good to be true.", 0, "Formula: so good that it cannot be true."),
        createMcq("trans_q10", "A sentence containing one main clause and two coordinate clauses joined by 'and' is:", "", "Compound", "Simple", "Negative", "Conditional", 0, "Sentences with multiple independent clauses joined by coordinating conjunctions are Compound.")
      )
    ),
    // 23. Common Grammar Rules
    FormulaTopic(
      id = "eng_common_grammar_rules",
      subject = FormulaSubject.ENGLISH,
      chapter = "Applied Grammar & Error Elimination",
      title = "Common Grammar Rules",
      hindiTitle = "सामान्य व्याकरण नियम",
      summary = "High-frequency grammar rules repeatedly tested in competitive exams (SSC CGL, Banking, CDS, NDA).",
      coreFormula = "Top Exam Rules:\nRule 1: 'Prefer / Preferable' takes preposition 'to' (never 'than').\nRule 2: 'Lest' is followed by 'should'; never takes 'not'.\nRule 3: 'Until' indicates time; 'Unless' indicates condition; neither takes negative words.\nRule 4: Inverted word order after negative introductory adverbs (Seldom, Rarely, Hardly, Scarcely, Barely, Never).\nRule 5: 'Although / Though' pairs with 'yet' or a comma (never with 'but').\nRule 6: 'Make, hear, see, watch, let' take bare infinitive (V1) in active voice.",
      symbolExplanations = listOf(
        "Bare Infinitive" to "Base verb without 'to' (e.g. 'He made me cry').",
        "Inversion" to "Placing auxiliary verb before subject for dramatic emphasis."
      ),
      importantIdentities = listOf(
        "Preposition 'to' is followed by gerund (V+ing) in fixed phrases: 'look forward to', 'used to', 'accustomed to', 'with a view to', 'addicted to'.",
        "Hyphenated compound adjectives never take plural form (e.g. 'a five-star hotel', NOT 'a five-stars hotel')."
      ),
      shortcutsAndTips = listOf(
        "Check whether 'to' is an infinitive marker (followed by V1) or a preposition (followed by V+ing in idioms)."
      ),
      commonMistakes = listOf(
        "Writing 'I look forward to meet you' instead of 'I look forward to meeting you'."
      ),
      solvedExamples = listOf(
        createExample(
          "cgr_ex1",
          "Identify and fix: 'Walk carefully lest you should not fall.'",
          "सुधारें: 'Walk carefully lest you should not fall.'",
          listOf(
            "Step 1: 'Lest' inherently expresses negative purpose ('so that... not').",
            "Step 2: Using 'not' after 'lest' creates an erroneous double negative.",
            "Step 3: Correct sentence: 'Walk carefully lest you should fall.'"
          ),
          "Walk carefully lest you should fall.",
          "'Lest' is inherently negative and never takes 'not'."
        ),
        createExample(
          "cgr_ex2",
          "Correct: 'She gave me a five-hundred-rupees note.'",
          "सुधारें: 'She gave me a five-hundred-rupees note.'",
          listOf(
            "Step 1: 'five-hundred-rupee' acts as a compound hyphenated adjective modifying 'note'.",
            "Step 2: Adjectives in English never take plural forms.",
            "Step 3: Correct: 'She gave me a five-hundred-rupee note.'"
          ),
          "She gave me a five-hundred-rupee note.",
          "Hyphenated numeral compound adjectives remain singular."
        ),
        createExample(
          "cgr_ex3",
          "Correct: 'Hardly I had entered the room when the lights went out.'",
          "सुधारें: 'Hardly I had entered the room when the lights went out.'",
          listOf(
            "Step 1: When a sentence begins with negative adverb 'Hardly', inverted word order is mandatory.",
            "Step 2: Auxiliary 'had' must precede subject 'I'.",
            "Step 3: Result: 'Hardly had I entered the room when the lights went out.'"
          ),
          "Hardly had I entered the room when the lights went out.",
          "Inversion rule: Negative adverb at start forces Auxiliary + Subject."
        )
      ),
      practiceMcqs = listOf(
        createMcq("cgr_q1", "I am looking forward to _____ from you.", "", "hearing", "hear", "heard", "have heard", 0, "'Look forward to' is a fixed prepositional idiom taking Gerund (-ing)."),
        createMcq("cgr_q2", "Milk is preferable _____ tea.", "", "to", "than", "over", "more than", 0, "'Preferable' takes preposition 'to'."),
        createMcq("cgr_q3", "Although he worked hard, _____ he could not clear the cutoff.", "", "yet / comma", "but", "still", "so", 0, "'Although' pairs with 'yet' or a comma, never 'but'."),
        createMcq("cgr_q4", "Wait here _____ I return.", "", "until", "unless", "since", "while", 0, "'Until' expresses time limit."),
        createMcq("cgr_q5", "The teacher made him _____ the entire poem.", "", "recite", "to recite", "recited", "reciting", 0, "Causative verb 'make' takes bare infinitive (recite) in active voice."),
        createMcq("cgr_q6", "He stayed at a _____ hotel in Mumbai.", "", "five-star", "five-stars", "five's-star", "fifth-star", 0, "Compound adjective remains singular: five-star."),
        createMcq("cgr_q7", "Seldom _____ such an inspiring speech.", "", "have I heard", "I have heard", "I had heard", "heard I", 0, "Initial 'Seldom' mandates inverted auxiliary-first order."),
        createMcq("cgr_q8", "He went to the library with a view to _____ books.", "", "borrowing", "borrow", "borrowed", "to borrow", 0, "'With a view to' is followed by gerund (-ing)."),
        createMcq("cgr_q9", "She is accustomed to _____ up early.", "", "waking", "wake", "woke", "woken", 0, "'Accustomed to' takes gerund (-ing)."),
        createMcq("cgr_q10", "No sooner did the train arrive _____ the passengers rushed.", "", "than", "then", "when", "as", 0, "'No sooner' strictly pairs with 'than'.")
      )
    ),
    // 24. Vocabulary (Building & Roots)
    FormulaTopic(
      id = "eng_vocabulary",
      subject = FormulaSubject.ENGLISH,
      chapter = "Lexical Studies",
      title = "Vocabulary",
      hindiTitle = "शब्दावली (मूल शब्द एवं प्रत्यय)",
      summary = "Etymological word breakdown: Greek and Latin roots, prefixes (anti-, mal-, bene-), and suffixes (-phobia, -cide, -cracy).",
      coreFormula = "Word Equation: Prefix + Root + Suffix = Meaning\nExamples of Roots:\n'Bene' (Good/Well) -> Benevolent, Benefactor, Beneficiary\n'Mal' (Bad/Evil) -> Malevolent, Malicious, Malign\n'Chron' (Time) -> Chronicle, Chronology, Synchronize\n'Phil' (Love) -> Philanthropist, Philosophy, Bibliophile\n'Path' (Feeling) -> Empathy, Sympathy, Apathy",
      symbolExplanations = listOf(
        "-cide" to "Killing (Suicide, Homicide, Regicide, Patricide).",
        "-cracy" to "Form of government (Democracy, Plutocracy, Autocracy).",
        "-phobia" to "Extreme fear (Claustrophobia, Acrophobia, Hydrophobia).",
        "-phil" to "Lover or enthusiast (Bibliophile, Philomath)."
      ),
      importantIdentities = listOf(
        "Root 'Omni' means 'All': Omnipotent, Omnipresent, Omniscient.",
        "Prefix 'In-/Im-/Un-/Dis-' denotes negation or reversal."
      ),
      shortcutsAndTips = listOf(
        "Break unfamiliar multisyllabic exam words into root and affixes to deduce definition."
      ),
      commonMistakes = listOf(
        "Confusing 'Altruist' (selfless lover of humanity) with 'Egoist' (self-centered individual)."
      ),
      solvedExamples = listOf(
        createExample(
          "voc_ex1",
          "Deduce meaning of 'Misanthrope' using root breakdown.",
          "मूल शब्द विश्लेषण से 'Misanthrope' का अर्थ ज्ञात कीजिए:",
          listOf(
            "Step 1: Prefix 'Mis' (Greek) = to hate.",
            "Step 2: Root 'Anthropos' (Greek) = mankind.",
            "Step 3: Synthesis: One who hates mankind.",
            "Step 4: Opposite: Philanthropist (Phil = love + anthropos)."
          ),
          "A person who dislikes and distrusts humankind.",
          "Mis (hate) + Anthropos (mankind) = Hater of mankind."
        ),
        createExample(
          "voc_ex2",
          "Deduce 'Plutocracy' from its roots.",
          "'Plutocracy' का अर्थ विश्लेषण करें:",
          listOf(
            "Step 1: Root 'Ploutos' (Greek) = wealth / rich.",
            "Step 2: Suffix '-cracy' = rule or governance.",
            "Step 3: Synthesis: Government ruled by the wealthy class."
          ),
          "Government by the wealthy.",
          "Pluto (wealth) + cracy (rule) = Rule by the rich."
        ),
        createExample(
          "voc_ex3",
          "Deduce 'Somnambulist'.",
          "'Somnambulist' का अर्थ विश्लेषण करें:",
          listOf(
            "Step 1: Root 'Somnus' = sleep.",
            "Step 2: Root 'Ambulare' = to walk.",
            "Step 3: Suffix '-ist' = one who practices.",
            "Step 4: Synthesis: A sleepwalker."
          ),
          "A sleepwalker (one who walks in sleep).",
          "Somnus (sleep) + Ambul (walk) + ist."
        )
      ),
      practiceMcqs = listOf(
        createMcq("voc_q1", "What does the root 'BENE' mean in words like 'benevolent' and 'beneficial'?", "", "Good / Well", "Bad / Evil", "Time", "Light", 0, "Latin 'bene' means good, well, or honorable."),
        createMcq("voc_q2", "A government governed by religious leaders is called:", "", "Theocracy", "Autocracy", "Democracy", "Aristocracy", 0, "Theo (God/Religion) + cracy (rule) = Theocracy."),
        createMcq("voc_q3", "One who knows everything is:", "", "Omniscient", "Omnipotent", "Omnipresent", "Omnivorous", 0, "Omni (all) + Scient (knowing) = Omniscient."),
        createMcq("voc_q4", "Fear of confined, enclosed spaces is:", "", "Claustrophobia", "Acrophobia", "Hydrophobia", "Agoraphobia", 0, "Claustrum (shut in) + phobia (fear) = Claustrophobia."),
        createMcq("voc_q5", "The murder of a king is termed:", "", "Regicide", "Homicide", "Fratricide", "Patricide", 0, "Rex/Regis (King) + cide (killing) = Regicide."),
        createMcq("voc_q6", "A person who loves books is a:", "", "Bibliophile", "Bibliophobe", "Philologist", "Biographer", 0, "Biblio (book) + phile (lover) = Bibliophile."),
        createMcq("voc_q7", "The root 'CHRON' relates to:", "", "Time", "Color", "Sound", "Earth", 0, "Greek 'chronos' denotes time."),
        createMcq("voc_q8", "What is the meaning of 'Loquacious'?", "", "Very talkative", "Extremely silent", "Generous", "Greedy", 0, "Root 'Loqu/Locut' means to speak."),
        createMcq("voc_q9", "One who is indifferent to pleasure or pain is a:", "", "Stoic", "Epicurean", "Cynic", "Hedonist", 0, "A stoic person remains unaffected by pain or joy."),
        createMcq("voc_q10", "Prefix 'MAL-' in 'malnutrition' indicates:", "", "Bad / Deficient", "Abundant", "Pure", "Equal", 0, "Latin 'mal' means bad, wrong, or ill.")
      )
    ),
    // 25. Synonyms and Antonyms
    FormulaTopic(
      id = "eng_synonyms_antonyms",
      subject = FormulaSubject.ENGLISH,
      chapter = "Lexical Studies",
      title = "Synonyms and Antonyms",
      hindiTitle = "समानार्थी एवं विलोम शब्द",
      summary = "High-yield vocabulary pairs, contextual connotation, and elimination techniques for multiple-choice options.",
      coreFormula = "Contextual Mapping Formula:\nWord = Core Meaning + Connotation (+ / - / neutral)\nKey High-Frequency Exam Triads:\n1. Ephemeral -> Syn: Transient, Fleeting | Ant: Permanent, Eternal\n2. Candid -> Syn: Frank, Forthright | Ant: Deceitful, Evasive\n3. Gregarious -> Syn: Sociable | Ant: Introverted, Reclusive\n4. Meticulous -> Syn: Scrupulous, Painstaking | Ant: Careless, Sloppy",
      symbolExplanations = listOf(
        "Synonym" to "Word having same or nearly identical meaning in given context.",
        "Antonym" to "Word expressing directly opposite or contradictory meaning.",
        "Connotation" to "Emotional tone or associative baggage of a word."
      ),
      importantIdentities = listOf(
        "Tone Matching Rule: If target word is negative, its synonym must have a negative valence, and its antonym must have a positive valence.",
        "Part of Speech Rule: A noun requires a noun synonym/antonym; an adjective requires an adjective."
      ),
      shortcutsAndTips = listOf(
        "If three options are synonyms of each other, the fourth (odd one out) is frequently the antonym or correct answer."
      ),
      commonMistakes = listOf(
        "Choosing an antonym when the exam question asked for a synonym due to rushed reading."
      ),
      solvedExamples = listOf(
        createExample(
          "sa_ex1",
          "Find SYNONYM of 'ABUNDANT': (A) Scarce (B) Plentiful (C) Minute (D) Petty",
          "'ABUNDANT' का समानार्थी चुनिए:",
          listOf(
            "Step 1: 'Abundant' means existing or available in large quantities (positive valence).",
            "Step 2: 'Scarce' and 'Minute' mean tiny/scanty (opposites).",
            "Step 3: 'Plentiful' means ample/copious.",
            "Step 4: Answer: (B) Plentiful."
          ),
          "Plentiful",
          "Abundant and Plentiful both denote copiousness."
        ),
        createExample(
          "sa_ex2",
          "Find ANTONYM of 'TRANSIENT': (A) Temporal (B) Fleeting (C) Perpetual (D) Ephemeral",
          "'TRANSIENT' का विलोम चुनिए:",
          listOf(
            "Step 1: 'Transient' means lasting only for a short time.",
            "Step 2: Options (A) Temporal, (B) Fleeting, and (D) Ephemeral are synonyms.",
            "Step 3: 'Perpetual' means never-ending or everlasting (direct opposite).",
            "Step 4: Answer: (C) Perpetual."
          ),
          "Perpetual",
          "Transient (temporary) is the exact opposite of Perpetual (everlasting)."
        ),
        createExample(
          "sa_ex3",
          "Find SYNONYM of 'LACONIC': (A) Verbose (B) Concise (C) Garrulous (D) Diffuse",
          "'LACONIC' का समानार्थी चुनिए:",
          listOf(
            "Step 1: 'Laconic' describes a style using very few words.",
            "Step 2: (A) Verbose and (C) Garrulous mean using too many words (antonyms).",
            "Step 3: 'Concise' means brief and to the point (synonym).",
            "Step 4: Answer: (B) Concise."
          ),
          "Concise",
          "Laconic means brief, succinct, concise."
        )
      ),
      practiceMcqs = listOf(
        createMcq("sa_q1", "Synonym of 'PRAGMATIC':", "", "Practical", "Idealistic", "Vague", "Theoretical", 0, "Pragmatic means dealing with matters practically."),
        createMcq("sa_q2", "Antonym of 'METICULOUS':", "", "Careless", "Thorough", "Scrupulous", "Cautious", 0, "Meticulous = extremely careful; antonym = careless."),
        createMcq("sa_q3", "Synonym of 'CANDID':", "", "Frank / Honest", "Deceitful", "Secretive", "Shy", 0, "Candid means straightforward, open, and frank."),
        createMcq("sa_q4", "Antonym of 'HOSTILE':", "", "Friendly / Amicable", "Antagonistic", "Aggressive", "Bitter", 0, "Hostile = antagonistic; opposite is friendly/amicable."),
        createMcq("sa_q5", "Synonym of 'UBIQUITOUS':", "", "Omnipresent", "Rare", "Scarce", "Hidden", 0, "Ubiquitous means found everywhere."),
        createMcq("sa_q6", "Antonym of 'BENEVOLENT':", "", "Malevolent", "Generous", "Kind", "Helpful", 0, "Benevolent = well-wishing; Malevolent = ill-wishing."),
        createMcq("sa_q7", "Synonym of 'EPHEMERAL':", "", "Short-lived / Transient", "Permanent", "Everlasting", "Sturdy", 0, "Ephemeral means lasting a very short time."),
        createMcq("sa_q8", "Antonym of 'MITIGATE':", "", "Aggravate / Worsen", "Alleviate", "Assuage", "Relieve", 0, "Mitigate = make less severe; Aggravate = worsen."),
        createMcq("sa_q9", "Synonym of 'OBSTINATE':", "", "Stubborn / Tenacious", "Flexible", "Yielding", "Submissive", 0, "Obstinate means stubbornly refusing to change."),
        createMcq("sa_q10", "Antonym of 'APATHY':", "", "Enthusiasm / Empathy", "Indifference", "Lethargy", "Disregard", 0, "Apathy = lack of interest; opposite is enthusiasm.")
      )
    ),
    // 26. Idioms and Phrases
    FormulaTopic(
      id = "eng_idioms_and_phrases",
      subject = FormulaSubject.ENGLISH,
      chapter = "Idiomatic Usage",
      title = "Idioms and Phrases",
      hindiTitle = "मुहावरे एवं लोकोक्तियां",
      summary = "Figurative meanings of high-frequency English idioms across categories: body parts, colors, animals, food, and conflicts.",
      coreFormula = "Idiom Equation: Literal Phrasing != Real Meaning (Figurative Definition)\nTop Exam Idioms by Theme:\n1. Body Parts: At arm's length (Keep distance) | Bite the bullet (Face courageously)\n2. Colors: Once in a blue moon (Very rarely) | Red tape (Bureaucratic delay)\n3. Animals: A dark horse (Unexpected winner) | Bell the cat (Take lead in facing danger)",
      symbolExplanations = listOf(
        "Idiom" to "An expression whose meaning is not deducible from the literal words.",
        "Phrasal Verb" to "Verb + Preposition/Adverb yielding a unique idiomatic meaning."
      ),
      importantIdentities = listOf(
        "Never choose an option that gives the literal word-for-word translation of the idiom."
      ),
      shortcutsAndTips = listOf(
        "Look for the figurative metaphor underlying the phrase."
      ),
      commonMistakes = listOf(
        "Confusing 'Break a leg' (Good luck!) with literal injury."
      ),
      solvedExamples = listOf(
        createExample(
          "idm_ex1",
          "Identify meaning: 'He proved to be a dark horse in the selection test.'",
          "अर्थ पहचानिए: 'He proved to be a dark horse in the selection test.'",
          listOf(
            "Step 1: The phrase is 'a dark horse'.",
            "Step 2: Literal meaning (a black animal) is an exam distractor.",
            "Step 3: Figurative origin: A little-known competitor who unexpectedly triumphs.",
            "Step 4: Meaning: An unforeseen or unexpected competitor who wins."
          ),
          "An unexpected competitor who wins.",
          "Metaphor for an unforeseen contender who reveals hidden abilities."
        ),
        createExample(
          "idm_ex2",
          "Identify meaning: 'To leave no stone unturned.'",
          "अर्थ पहचानिए: 'To leave no stone unturned.'",
          listOf(
            "Step 1: Figurative metaphor of searching under every possible stone.",
            "Step 2: Represents exhaustive, tireless effort.",
            "Step 3: Meaning: To try every possible means to achieve a goal."
          ),
          "To use every possible means or effort.",
          "Signifies exhaustive, thorough efforts."
        ),
        createExample(
          "idm_ex3",
          "Identify meaning: 'To burn the candle at both ends.'",
          "अर्थ पहचानिए: 'To burn the candle at both ends.'",
          listOf(
            "Step 1: Lighting both ends exhausts resources rapidly.",
            "Step 2: Refers to working late nights and early mornings without rest.",
            "Step 3: Meaning: Overworking or exhausting one's physical energy."
          ),
          "To work extremely hard, often late into the night.",
          "Refers to excessive work and inadequate rest."
        )
      ),
      practiceMcqs = listOf(
        createMcq("idm_q1", "Meaning of 'Once in a blue moon':", "", "Very rarely", "Every month", "Frequently", "On full moon day", 0, "Signifies an event that happens extremely rarely."),
        createMcq("idm_q2", "Meaning of 'Bite the bullet':", "", "To face a grim situation with fortitude", "To eat something hard", "To commit suicide", "To start a war", 0, "Originates from wounded soldiers biting bullets during surgery."),
        createMcq("idm_q3", "Meaning of 'To bell the cat':", "", "To take a great personal risk for the group", "To feed a pet", "To ring an alarm", "To punish an enemy", 0, "From Aesop's fable: attempting an impossible risky act."),
        createMcq("idm_q4", "Meaning of 'At sixes and sevens':", "", "In a state of total confusion and disarray", "In good numerical order", "Calculating accounts", "Very happy", 0, "Denotes utter disorder and chaos."),
        createMcq("idm_q5", "Meaning of 'Spill the beans':", "", "To disclose a secret prematurely", "To cook food", "To drop groceries", "To tell a lie", 0, "Idiom for revealing confidential information."),
        createMcq("idm_q6", "Meaning of 'To hit the nail on the head':", "", "To state the exact truth or find the precise answer", "To work as a carpenter", "To hurt someone", "To make a mistake", 0, "Signifies doing or saying the exact right thing."),
        createMcq("idm_q7", "Meaning of 'Gift of the gab':", "", "Ability to speak eloquently and persuasively", "Receiving costly gifts", "Talking too loudly", "Having good voice", 0, "Denotes natural talent for persuasive speech."),
        createMcq("idm_q8", "Meaning of 'Burn the midnight oil':", "", "To study or work late into the night", "To waste kerosene", "To set fire to fuel", "To sleep early", 0, "Refers to working late by oil lamp."),
        createMcq("idm_q9", "Meaning of 'A blessing in disguise':", "", "An apparent misfortune that yields good results", "A religious prayer", "A masked gift", "A dangerous person", 0, "Something positive that seemed bad at first."),
        createMcq("idm_q10", "Meaning of 'Through thick and thin':", "", "Under all circumstances, good and bad", "Through heavy forest", "Gaining and losing weight", "Only in prosperous times", 0, "Means standing loyal through all fortunes and hardships.")
      )
    ),
    // 27. One-Word Substitution
    FormulaTopic(
      id = "eng_one_word_substitution",
      subject = FormulaSubject.ENGLISH,
      chapter = "Lexical Studies",
      title = "One-Word Substitution",
      hindiTitle = "अनेक शब्दों के लिए एक शब्द",
      summary = "Concise single-word replacements for complex descriptions, professions, habits, beliefs, and conditions.",
      coreFormula = "Core Conceptual Groups:\n1. Beliefs: Atheist (No God) vs Theist (Believes in God) vs Agnostic (Doubtful)\n2. Lifestyle: Ascetic (Severe self-discipline) | Altruist (Selfless helper) | Ephemeral (Short-lived)\n3. Habits: Teetotaler (No alcohol) | Polyglot (Many languages) | Somniloquist (Talks in sleep)",
      symbolExplanations = listOf(
        "Agnostic" to "Believes that nothing can be known about existence of God.",
        "Atheist" to "Denies existence of God outright.",
        "Altruist" to "Selfless promoter of others' wellbeing.",
        "Egoist" to "Self-centered person obsessed with self-advancement."
      ),
      importantIdentities = listOf(
        "Distinguish between 'Infallible' (never makes mistakes) and 'Invincible' (cannot be defeated).",
        "'Fastidious' means one who is very difficult to please and pays excessive attention to details."
      ),
      shortcutsAndTips = listOf(
        "Memorize categorized sets: Phobias, Manias, Specialist Doctors, and Government forms."
      ),
      commonMistakes = listOf(
        "Confusing 'Emigrant' (one who leaves their own country) with 'Immigrant' (one who enters a new country)."
      ),
      solvedExamples = listOf(
        createExample(
          "ows_ex1",
          "One who completely abstains from alcoholic drinks is called: (A) Teetotaler (B) Drunkard (C) Gourmet (D) Stoic",
          "मदिरा का पूर्ण त्याग करने वाला कहलाता है:",
          listOf(
            "Step 1: (A) Teetotaler = person who totally abstains from alcoholic beverages.",
            "Step 2: (B) Drunkard = habitual drinker.",
            "Step 3: (C) Gourmet = food connoisseur.",
            "Step 4: (D) Stoic = indifferent to pain/pleasure.",
            "Step 5: Answer: (A) Teetotaler."
          ),
          "Teetotaler",
          "Teetotaler is one who never touches alcoholic beverages."
        ),
        createExample(
          "ows_ex2",
          "One who cannot be corrected or reformed is: (A) Incorrigible (B) Infallible (C) Indelible (D) Invulnerable",
          "जिसे सुधारा न जा सके:",
          listOf(
            "Step 1: Root 'corrigere' = to correct.",
            "Step 2: Prefix 'In-' = not.",
            "Step 3: 'Incorrigible' = not capable of being reformed or corrected.",
            "Step 4: Answer: (A) Incorrigible."
          ),
          "Incorrigible",
          "Incorrigible = beyond reform or correction."
        ),
        createExample(
          "ows_ex3",
          "A remedy for all diseases or difficulties: (A) Panacea (B) Antidote (C) Placebo (D) Antibiotic",
          "सभी रोगों की अचूक दवा:",
          listOf(
            "Step 1: 'Pan' = all; 'Akos' = remedy/cure.",
            "Step 2: 'Panacea' = a universal cure-all or universal solution.",
            "Step 3: Answer: (A) Panacea."
          ),
          "Panacea",
          "Panacea is a universal remedy for all ills."
        )
      ),
      practiceMcqs = listOf(
        createMcq("ows_q1", "A person who loves and collects books:", "", "Bibliophile", "Bibliographer", "Philatelist", "Numismatist", 0, "Biblio (book) + phile (lover) = Bibliophile."),
        createMcq("ows_q2", "A speech made without any prior preparation:", "", "Extempore", "Maiden speech", "Eulogy", "Monologue", 0, "An unprepared impromptu speech is 'Extempore'."),
        createMcq("ows_q3", "One who speaks many languages fluently:", "", "Polyglot", "Linguist", "Bilingual", "Interpreter", 0, "Poly (many) + glot (tongues/languages) = Polyglot."),
        createMcq("ows_q4", "One who collects stamps as a hobby:", "", "Philatelist", "Numismatist", "Ornithologist", "Anthropologist", 0, "Philatelist is a stamp collector."),
        createMcq("ows_q5", "A post for which no salary is paid:", "", "Honorary", "Voluntary", "Sinecure", "Temporary", 0, "Honorary positions carry honor without regular salary."),
        createMcq("ows_q6", "An office with high salary but no work:", "", "Sinecure", "Honorary", "Bureaucracy", "Autocracy", 0, "Sinecure = a job with remuneration but little work."),
        createMcq("ows_q7", "One who eats human flesh:", "", "Cannibal", "Carnivore", "Herbivore", "Omnivore", 0, "Cannibal eats flesh of its own species."),
        createMcq("ows_q8", "That which cannot be heard:", "", "Inaudible", "Audible", "Silent", "Deaf", 0, "Inaudible = sound unable to be heard."),
        createMcq("ows_q9", "A person who is indifferent to pain or pleasure:", "", "Stoic", "Ascetic", "Epicurean", "Hermit", 0, "Stoic bears pain or pleasure without display of feeling."),
        createMcq("ows_q10", "A person who leaves his country to settle in another:", "", "Emigrant", "Immigrant", "Refugee", "Exile", 0, "Emigrant exits his native country; immigrant enters new country.")
      )
    )
  )
}
