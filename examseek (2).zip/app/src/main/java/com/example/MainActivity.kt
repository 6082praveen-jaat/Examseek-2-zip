package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.AiDoubtSolverScreen
import com.example.ui.screens.DailyLearningScreen
import com.example.ui.screens.FormulaTopicDetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.PyqVaultScreen
import com.example.ui.screens.SolutionReviewScreen
import com.example.ui.screens.TestListScreen
import com.example.ui.screens.TestResultScreen
import com.example.ui.screens.TestTakingScreen
import com.example.ui.screens.TrustAndLegalScreen
import com.example.ui.theme.ExamSeekTheme
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.DailyLearningViewModel
import com.example.ui.viewmodel.DoubtSolverViewModel
import com.example.ui.viewmodel.ExamViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      ExamSeekTheme {
        ExamSeekApp()
      }
    }
  }
}

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector? = null) {
  object Home : Screen("home", "Home", Icons.Default.Home)
  object Tests : Screen("tests", "15-Q Tests", Icons.Default.Quiz)
  object DoubtSolver : Screen("doubt_solver", "AI Guru", Icons.Default.AutoAwesome)
  object PyqVault : Screen("pyq_vault", "PYQs", Icons.Default.HistoryEdu)
  object Daily : Screen("daily", "Revision", Icons.Default.MenuBook)
  object TestTaking : Screen("test_taking", "Active Test")
  object TestResult : Screen("test_result", "Result")
  object SolutionReview : Screen("solution_review", "Solutions")
  object FormulaDetail : Screen("formula_detail/{topicId}", "Formula Detail") {
    fun createRoute(topicId: String) = "formula_detail/$topicId"
  }
  object Profile : Screen("profile", "Profile", Icons.Default.Person)
  object TrustLegal : Screen("trust_legal", "Trust & Legal")
}

@Composable
fun ExamSeekApp() {
  val navController = rememberNavController()
  val examViewModel: ExamViewModel = viewModel()
  val doubtSolverViewModel: DoubtSolverViewModel = viewModel()
  val dailyLearningViewModel: DailyLearningViewModel = viewModel()

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val bottomNavItems = listOf(
    Screen.Home,
    Screen.Tests,
    Screen.DoubtSolver,
    Screen.PyqVault,
    Screen.Daily
  )

  val shouldShowBottomBar = currentRoute in listOf(
    Screen.Home.route,
    Screen.Tests.route,
    Screen.DoubtSolver.route,
    Screen.PyqVault.route,
    Screen.Daily.route,
    Screen.Profile.route
  )

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      if (shouldShowBottomBar) {
        NavigationBar(
          containerColor = MaterialTheme.colorScheme.surface,
          tonalElevation = 8.dp
        ) {
          bottomNavItems.forEach { screen ->
            val isSelected = currentRoute == screen.route
            NavigationBarItem(
              selected = isSelected,
              onClick = {
                if (currentRoute != screen.route) {
                  navController.navigate(screen.route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                      saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                  }
                }
              },
              icon = {
                screen.icon?.let {
                  Icon(
                    imageVector = it,
                    contentDescription = screen.title,
                    modifier = Modifier.size(22.dp)
                  )
                }
              },
              label = {
                Text(
                  text = screen.title,
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                  )
                )
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyPrimary,
                selectedTextColor = NavyPrimary,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                indicatorColor = IndigoAccent.copy(alpha = 0.15f)
              ),
              modifier = Modifier.testTag("nav_item_${screen.route}")
            )
          }
        }
      }
    }
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = Screen.Home.route,
      modifier = Modifier.padding(innerPadding)
    ) {
      composable(Screen.Home.route) {
        HomeScreen(
          examViewModel = examViewModel,
          onNavigateToTests = { navController.navigate(Screen.Tests.route) },
          onStartTest = { testItem ->
            examViewModel.startTest(testItem)
            navController.navigate(Screen.TestTaking.route)
          },
          onNavigateToDoubtSolver = { navController.navigate(Screen.DoubtSolver.route) },
          onNavigateToPyqVault = { navController.navigate(Screen.PyqVault.route) },
          onNavigateToDaily = { navController.navigate(Screen.Daily.route) },
          onNavigateToProfile = { navController.navigate(Screen.Profile.route) }
        )
      }

      composable(Screen.Tests.route) {
        TestListScreen(
          viewModel = examViewModel,
          onNavigateBack = { navController.popBackStack() },
          onStartTest = { testItem ->
            examViewModel.startTest(testItem)
            navController.navigate(Screen.TestTaking.route)
          }
        )
      }

      composable(Screen.DoubtSolver.route) {
        AiDoubtSolverScreen(
          viewModel = doubtSolverViewModel,
          onNavigateBack = { navController.popBackStack() }
        )
      }

      composable(Screen.PyqVault.route) {
        PyqVaultScreen(
          viewModel = examViewModel,
          onNavigateBack = { navController.popBackStack() },
          onStartPyqDrill = {
            navController.navigate(Screen.TestTaking.route)
          }
        )
      }

      composable(Screen.Daily.route) {
        DailyLearningScreen(
          viewModel = dailyLearningViewModel,
          onNavigateBack = { navController.popBackStack() },
          onTopicSelected = { topicId ->
            dailyLearningViewModel.selectTopic(topicId)
            navController.navigate(Screen.FormulaDetail.createRoute(topicId))
          }
        )
      }

      composable(
        route = Screen.FormulaDetail.route,
        arguments = listOf(navArgument("topicId") { type = NavType.StringType })
      ) { backStackEntry ->
        val topicId = backStackEntry.arguments?.getString("topicId") ?: ""
        FormulaTopicDetailScreen(
          viewModel = dailyLearningViewModel,
          topicId = topicId,
          onNavigateBack = { navController.popBackStack() }
        )
      }

      composable(Screen.TestTaking.route) {
        TestTakingScreen(
          viewModel = examViewModel,
          onTestSubmitted = {
            navController.navigate(Screen.TestResult.route) {
              popUpTo(Screen.TestTaking.route) { inclusive = true }
            }
          },
          onExitTest = {
            navController.popBackStack()
          }
        )
      }

      composable(Screen.TestResult.route) {
        TestResultScreen(
          viewModel = examViewModel,
          onReviewSolutions = {
            navController.navigate(Screen.SolutionReview.route)
          },
          onRetakeOrNewTest = {
            navController.navigate(Screen.Tests.route) {
              popUpTo(Screen.TestResult.route) { inclusive = true }
            }
          },
          onNavigateHome = {
            navController.navigate(Screen.Home.route) {
              popUpTo(Screen.Home.route) { inclusive = true }
            }
          }
        )
      }

      composable(Screen.SolutionReview.route) {
        SolutionReviewScreen(
          viewModel = examViewModel,
          onNavigateBack = { navController.popBackStack() }
        )
      }

      composable(Screen.Profile.route) {
        ProfileScreen(
          viewModel = examViewModel,
          onNavigateBack = { navController.popBackStack() },
          onNavigateToTrustLegal = {
            navController.navigate(Screen.TrustLegal.route)
          }
        )
      }

      composable(Screen.TrustLegal.route) {
        TrustAndLegalScreen(
          onNavigateBack = { navController.popBackStack() }
        )
      }
    }
  }
}
