package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.ai.AiDoubtSolverService
import com.example.domain.model.MultiApproachDoubtSolution
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DoubtSolverUiState(
  val questionInput: String = "",
  val selectedSubject: String = "Mathematics",
  val attachedBitmap: Bitmap? = null,
  val isLoading: Boolean = false,
  val isApiKeyConfigured: Boolean = true,
  val solution: MultiApproachDoubtSolution? = null,
  val errorMessage: String? = null,
  val history: List<MultiApproachDoubtSolution> = emptyList()
)

class DoubtSolverViewModel(application: Application) : AndroidViewModel(application) {

  private val doubtService = AiDoubtSolverService()

  private val _uiState = MutableStateFlow(DoubtSolverUiState())
  val uiState: StateFlow<DoubtSolverUiState> = _uiState.asStateFlow()

  val availableSubjects = listOf(
    "Mathematics",
    "Reasoning",
    "English",
    "General Knowledge",
    "Current Affairs",
    "Science",
    "Computer Knowledge"
  )

  init {
    checkApiKey()
  }

  fun checkApiKey() {
    val key = try {
      BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
    } catch (_: Exception) {
      null
    }
    _uiState.update { it.copy(isApiKeyConfigured = !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY") }
  }

  fun onQuestionInputChanged(input: String) {
    _uiState.update { it.copy(questionInput = input, errorMessage = null) }
  }

  fun onSubjectSelected(subject: String) {
    _uiState.update { it.copy(selectedSubject = subject) }
  }

  fun onImageAttached(bitmap: Bitmap?) {
    _uiState.update { it.copy(attachedBitmap = bitmap, errorMessage = null) }
  }

  fun clearAttachedImage() {
    _uiState.update { it.copy(attachedBitmap = null) }
  }

  fun solveDoubt() {
    val state = _uiState.value
    if (state.questionInput.isBlank() && state.attachedBitmap == null) {
      _uiState.update { it.copy(errorMessage = "Please enter your question text or attach a question image.") }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, errorMessage = null) }
      try {
        val solution = doubtService.solveDoubtWithThreeMethods(
          questionText = state.questionInput,
          imageBitmap = state.attachedBitmap,
          subject = state.selectedSubject
        )

        _uiState.update { current ->
          current.copy(
            isLoading = false,
            solution = solution,
            history = listOf(solution) + current.history.take(9)
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            isLoading = false,
            errorMessage = "Failed to solve doubt: ${e.localizedMessage ?: "Unknown error"}. You can tap Retry."
          )
        }
      }
    }
  }

  fun retry() {
    solveDoubt()
  }

  fun reset() {
    _uiState.update {
      it.copy(
        questionInput = "",
        attachedBitmap = null,
        solution = null,
        errorMessage = null
      )
    }
  }
}
