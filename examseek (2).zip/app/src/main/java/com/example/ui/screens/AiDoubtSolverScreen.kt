package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MethodExplanation
import com.example.domain.model.MultiApproachDoubtSolution
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedLight
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ReviewPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenLight
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberLight
import com.example.ui.viewmodel.DoubtSolverViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiDoubtSolverScreen(
  viewModel: DoubtSolverViewModel,
  onNavigateBack: () -> Unit = {}
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsState()

  // Photo Picker (Android 13+ zero-permission standard photo picker)
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      val bitmap = loadBitmapFromUri(context, uri)
      if (bitmap != null) {
        viewModel.onImageAttached(bitmap)
      } else {
        Toast.makeText(context, "Could not load selected image.", Toast.LENGTH_SHORT).show()
      }
    }
  }

  // Camera Capture
  val cameraLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.TakePicturePreview()
  ) { bitmap: Bitmap? ->
    if (bitmap != null) {
      viewModel.onImageAttached(bitmap)
    } else {
      // User cancelled camera capture
    }
  }

  // Camera Permission Launcher
  val cameraPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted: Boolean ->
    if (isGranted) {
      cameraLauncher.launch(null)
    } else {
      Toast.makeText(
        context,
        "Camera permission is required to capture question photos.",
        Toast.LENGTH_LONG
      ).show()
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "AI Doubt Guru",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = "3-Method Competitive Exam Solver",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("doubt_solver_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
        },
        actions = {
          IconButton(
            onClick = { viewModel.reset() },
            modifier = Modifier.testTag("doubt_solver_reset_button")
          ) {
            Icon(
              imageVector = Icons.Default.Refresh,
              contentDescription = "Reset Form",
              tint = Color.White
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyPrimary)
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

      // Missing API Key Guidance Banner
      if (!uiState.isApiKeyConfigured) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth().testTag("api_key_notice_card"),
            colors = CardDefaults.cardColors(containerColor = WarningAmberLight),
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.Top
            ) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Info",
                tint = WarningAmber,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Live AI Mode Setup",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFF92400E)
                )
                Text(
                  text = "GEMINI_API_KEY is not configured yet. Configure your API key via the Secrets panel in AI Studio. In the meantime, ExamSeek uses built-in academic multi-approach reasoning engines.",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFF78350F)
                )
              }
            }
          }
        }
      }

      // Subject Selector Chips
      item {
        Column {
          Text(
            text = "Select Question Subject",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(8.dp))
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(viewModel.availableSubjects) { subj ->
              val isSelected = uiState.selectedSubject == subj
              FilterChip(
                selected = isSelected,
                onClick = { viewModel.onSubjectSelected(subj) },
                label = { Text(subj) },
                leadingIcon = if (isSelected) {
                  {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                } else null,
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NavyPrimary,
                  selectedLabelColor = Color.White
                )
              )
            }
          }
        }
      }

      // Question Input Box
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Question Details",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = uiState.questionInput,
              onValueChange = { viewModel.onQuestionInputChanged(it) },
              modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .testTag("doubt_question_input"),
              placeholder = {
                Text(
                  text = "Type or paste your question here... (e.g., 'Find the compound interest on ₹12,000 for 2 years at 10% per annum' or Reasoning analogy questions)",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
              },
              shape = RoundedCornerShape(12.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NavyPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
              )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Attached Image Preview
            AnimatedVisibility(visible = uiState.attachedBitmap != null) {
              uiState.attachedBitmap?.let { bmp ->
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF1F5F9))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                ) {
                  Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Attached Question Image",
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(160.dp)
                  )
                  IconButton(
                    onClick = { viewModel.clearAttachedImage() },
                    modifier = Modifier
                      .align(Alignment.TopEnd)
                      .padding(8.dp)
                      .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                      .size(32.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.Close,
                      contentDescription = "Remove Image",
                      tint = Color.White,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
              }
            }

            // Media Action Buttons
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedButton(
                onClick = {
                  photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                },
                modifier = Modifier
                  .weight(1f)
                  .testTag("attach_gallery_button"),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Image,
                  contentDescription = "Gallery",
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Gallery")
              }

              OutlinedButton(
                onClick = {
                  cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                },
                modifier = Modifier
                  .weight(1f)
                  .testTag("capture_camera_button"),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.CameraAlt,
                  contentDescription = "Camera",
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Camera")
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Primary Solve Button
            Button(
              onClick = { viewModel.solveDoubt() },
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("solve_doubt_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
              enabled = !uiState.isLoading && (uiState.questionInput.isNotBlank() || uiState.attachedBitmap != null)
            ) {
              if (uiState.isLoading) {
                CircularProgressIndicator(
                  modifier = Modifier.size(20.dp),
                  color = Color.White,
                  strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Analyzing 3 Approaches...")
              } else {
                Icon(
                  imageVector = Icons.Default.AutoAwesome,
                  contentDescription = null,
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Solve with 3 Approaches")
              }
            }
          }
        }
      }

      // Error and Retry State
      if (uiState.errorMessage != null) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth().testTag("error_card"),
            colors = CardDefaults.cardColors(containerColor = ErrorRedLight),
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Error",
                tint = ErrorRed
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Unable to Solve",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFF991B1B)
                )
                Text(
                  text = uiState.errorMessage ?: "",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFF7F1D1D)
                )
              }
              Button(
                onClick = { viewModel.retry() },
                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text("Retry")
              }
            }
          }
        }
      }

      // Solution Display
      uiState.solution?.let { solution ->
        item {
          SolutionCard(solution = solution)
        }
      }

      // Quick Helpful Examples
      if (uiState.solution == null && !uiState.isLoading) {
        item {
          CompetitiveExamplesCard(
            onSelectExample = { question, subject ->
              viewModel.onSubjectSelected(subject)
              viewModel.onQuestionInputChanged(question)
            }
          )
        }
      }
    }
  }
}

@Composable
fun SolutionCard(solution: MultiApproachDoubtSolution) {
  var selectedTab by remember { mutableIntStateOf(0) }

  Column(
    modifier = Modifier.fillMaxWidth().testTag("solution_card"),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {

    // Unclear Image Warning if applicable
    if (solution.isImageUnclear) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = WarningAmberLight),
        shape = RoundedCornerShape(12.dp)
      ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = WarningAmber
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Notice: The image was blurry or partially cut off. Please upload a clearer, well-lit photo for an exact optical read.",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF92400E)
          )
        }
      }
    }

    // Final Answer Highlight Box
    Card(
      modifier = Modifier.fillMaxWidth(),
      colors = CardDefaults.cardColors(containerColor = SuccessGreenLight),
      shape = RoundedCornerShape(14.dp),
      border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SuccessGreen))
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = SuccessGreen,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Final Answer",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFF065F46)
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = solution.finalAnswer,
          style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
          color = Color(0xFF047857)
        )
      }
    }

    // Formulas & Rules Used Chips
    if (solution.formulasUsed.isNotEmpty()) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "Formulas & Rules Used",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = NavyPrimary
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            solution.formulasUsed.forEach { formula ->
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color.White)
                  .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(8.dp))
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text(
                  text = formula,
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace
                  ),
                  color = NavyPrimary
                )
              }
            }
          }
        }
      }
    }

    // 3 Approaches Tabs
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column {
        ScrollableTabRow(
          selectedTabIndex = selectedTab,
          containerColor = MaterialTheme.colorScheme.surface,
          edgePadding = 8.dp
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("Method 1: Step-by-Step", fontWeight = FontWeight.SemiBold) },
            icon = { Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(18.dp)) }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("Method 2: Short Trick", fontWeight = FontWeight.SemiBold) },
            icon = { Icon(Icons.Default.ElectricBolt, contentDescription = null, modifier = Modifier.size(18.dp)) }
          )
          Tab(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            text = { Text("Method 3: Alternative", fontWeight = FontWeight.SemiBold) },
            icon = { Icon(Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(18.dp)) }
          )
        }

        Box(modifier = Modifier.padding(16.dp)) {
          when (selectedTab) {
            0 -> MethodDetailContent(solution.method1Beginner, badgeColor = NavyPrimary, badgeText = "Beginner Step-by-Step")
            1 -> MethodDetailContent(solution.method2ShortTrick, badgeColor = IndigoAccent, badgeText = "Exam Short Trick")
            2 -> MethodDetailContent(solution.method3Alternative, badgeColor = ReviewPurple, badgeText = "Alternative Angle")
          }
        }
      }
    }

    // Verification Section
    if (solution.verification.isNotBlank()) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = SuccessGreen,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Answer Verification",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = Color(0xFF1E293B)
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = solution.verification,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF334155)
          )
        }
      }
    }

    // Subject Nuance (Grammar rules / Logic / GK distinction)
    if (solution.subjectNuance.isNotBlank()) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF5FF)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Psychology,
              contentDescription = null,
              tint = ReviewPurple,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Exam Logic & Rule Nuance",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = ReviewPurple
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = solution.subjectNuance,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF4C1D95)
          )
        }
      }
    }

    // Model Provenance Badge
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Engine: ${solution.sourceModel}",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      if (solution.isFallback) {
        Text(
          text = "Local Academic Mode",
          style = MaterialTheme.typography.labelSmall,
          color = WarningAmber
        )
      }
    }
  }
}

@Composable
fun MethodDetailContent(method: MethodExplanation, badgeColor: Color, badgeText: String) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(badgeColor.copy(alpha = 0.12f))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text(
          text = badgeText,
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = badgeColor
        )
      }

      Text(
        text = "Avg Time: ${method.speedTimeSeconds}",
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    Text(
      text = method.title,
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
    )

    Text(
      text = method.summary,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = "Step-by-Step Procedure:",
      style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
    )

    method.steps.forEachIndexed { idx, step ->
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
      ) {
        Box(
          modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(badgeColor)
            .padding(2.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "${idx + 1}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = step,
          style = MaterialTheme.typography.bodySmall,
          modifier = Modifier.weight(1f),
          color = MaterialTheme.colorScheme.onSurface
        )
      }
    }
  }
}

@Composable
fun CompetitiveExamplesCard(onSelectExample: (String, String) -> Unit) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = "Try Asking These Exam Doubts:",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
      )
      Spacer(modifier = Modifier.height(8.dp))

      val examples = listOf(
        Pair("A sum of ₹12,000 becomes ₹15,972 in 3 years at compound interest compounded annually. Find the rate per annum.", "Mathematics"),
        Pair("Pointing to a photograph, a woman says, 'He is the son of the only daughter-in-law of my father-in-law.' How is the man in the photograph related to the woman?", "Reasoning"),
        Pair("Identify the grammatical error: 'Neither the principal nor the teachers was present in the auditorium when the ceremony began.'", "English"),
        Pair("Under which Article of the Indian Constitution can the President proclaim a Financial Emergency, and has it ever been declared?", "General Knowledge")
      )

      examples.forEach { (text, subj) ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable { onSelectExample(text, subj) }
            .padding(10.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = IndigoAccent
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2
              )
              Text(
                text = subj,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = NavyPrimary
              )
            }
          }
        }
      }
    }
  }
}

fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
  return try {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      val source = ImageDecoder.createSource(context.contentResolver, uri)
      ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
        decoder.isMutableRequired = true
      }
    } else {
      @Suppress("DEPRECATION")
      MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
    }
  } catch (e: Exception) {
    null
  }
}
