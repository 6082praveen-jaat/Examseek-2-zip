package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ExamRegistry
import com.example.domain.model.TestQuestion
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ReviewPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberLight
import com.example.ui.viewmodel.ExamViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PyqVaultScreen(
  viewModel: ExamViewModel,
  onNavigateBack: () -> Unit,
  onStartPyqDrill: () -> Unit
) {
  val state by viewModel.pyqVaultState.collectAsState()
  var showImportModal by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Year-Wise PYQ Vault",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = "Verified Official Previous Year Papers & Shift Keys",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("pyq_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        actions = {
          IconButton(onClick = { showImportModal = true }) {
            Icon(Icons.Default.FileUpload, contentDescription = "Import PYQ", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

      // Exam Selector Dropdown / Chips
      item {
        Column {
          Text(
            text = "Select Exam:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(6.dp))
          val popularExams = listOf("SSC CGL", "SSC CHSL", "RRB NTPC", "IBPS PO", "SBI PO", "UPSC Prelims", "CTET Paper 1")
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(popularExams) { examName ->
              val isSelected = state.selectedExam == examName
              FilterChip(
                selected = isSelected,
                onClick = { viewModel.setPyqExam(examName) },
                label = { Text(examName) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NavyPrimary,
                  selectedLabelColor = Color.White
                )
              )
            }
          }
        }
      }

      // Year & Shift Filter Rows
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Year row
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("Year: ", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
              Spacer(modifier = Modifier.width(6.dp))
              LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.availableYears) { year ->
                  FilterChip(
                    selected = state.selectedYear == year,
                    onClick = { viewModel.setPyqYear(year) },
                    label = { Text(year) },
                    modifier = Modifier.height(32.dp)
                  )
                }
              }
            }

            // Shift row
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("Shift: ", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
              Spacer(modifier = Modifier.width(6.dp))
              LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.availableShifts) { shift ->
                  FilterChip(
                    selected = state.selectedShift == shift,
                    onClick = { viewModel.setPyqShift(shift) },
                    label = { Text(shift) },
                    modifier = Modifier.height(32.dp)
                  )
                }
              }
            }

            // Subject row
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("Subject: ", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
              Spacer(modifier = Modifier.width(6.dp))
              LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.availableSubjects) { subj ->
                  FilterChip(
                    selected = state.selectedSubject == subj,
                    onClick = { viewModel.setPyqSubject(subj) },
                    label = { Text(subj) },
                    modifier = Modifier.height(32.dp)
                  )
                }
              }
            }
          }
        }
      }

      // "Start 15-Q Drill" from this filter
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = NavyPrimary)
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Practice ${state.selectedExam} ${state.selectedYear}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = "Generate a timed 15-question CBT test attempt from this year's paper.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.85f)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                viewModel.startPyqDrill(onStarted = onStartPyqDrill)
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color.White),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("start_pyq_drill_button")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NavyDark, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("15-Q Drill", color = NavyDark, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // Provenance & Legal Truthfulness Notice
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
          border = CardDefaults.outlinedCardBorder()
        ) {
          Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Security, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "ExamSeek strict provenance policy: All questions display official answer-key citations. We never fabricate fake official questions.",
              style = MaterialTheme.typography.bodySmall,
              color = Color(0xFF334155),
              fontSize = 11.sp
            )
          }
        }
      }

      // Count badge
      item {
        Text(
          text = "Showing ${state.questions.size} of ${state.totalMatchingCount} questions for ${state.selectedExam} (${state.selectedYear})",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Questions List
      if (state.isLoading) {
        item {
          Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = NavyPrimary)
          }
        }
      } else if (state.questions.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp)
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(36.dp))
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "No verified questions found for ${state.selectedExam} ${state.selectedYear} ${state.selectedShift}.",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Official papers for this shift are being digitized by the academic team. You can also import verified questions using the top import tool.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(state.questions) { question ->
          PyqQuestionItem(
            question = question,
            onToggleBookmark = { viewModel.toggleBookmark(question) }
          )
        }
      }
    }
  }

  // Import Dialog
  if (showImportModal) {
    ImportQuestionsDialog(
      onDismiss = { showImportModal = false },
      onImport = { json ->
        showImportModal = false
        viewModel.importQuestionsFromJson(json)
      }
    )
  }
}

@Composable
fun PyqQuestionItem(
  question: TestQuestion,
  onToggleBookmark: () -> Unit
) {
  var isExpanded by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {

      // Top Provenance Tag
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        val (tagBg, tagText, tagColor) = when (question.sourceLabel) {
          "OFFICIAL_VERIFIED_PYQ" -> Triple(Color(0xFFD1FAE5), "Official Verified PYQ", SuccessGreen)
          "UNOFFICIAL_MEMORY_BASED" -> Triple(Color(0xFFFEF3C7), "Memory-Based Recall", WarningAmber)
          "AI_GENERATED_PRACTICE" -> Triple(Color(0xFFDBEAFE), "AI-Generated Practice", IndigoAccent)
          else -> Triple(Color(0xFFF1F5F9), "Verified Bank", Color(0xFF475569))
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(tagBg)
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(
            text = tagText,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
            color = tagColor
          )
        }

        IconButton(onClick = onToggleBookmark, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.BookmarkBorder, contentDescription = "Bookmark", tint = NavyPrimary, modifier = Modifier.size(18.dp))
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Exam Metadata
      Text(
        text = "${question.targetExam} • ${question.year} • ${question.shift} • ${question.subject}",
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Question Text
      Text(
        text = question.questionText,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Options
      question.options.forEachIndexed { idx, opt ->
        val isCorrect = idx == question.correctOptionIndex
        val letter = listOf("A", "B", "C", "D")[idx]

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isCorrect) Color(0xFFECFDF5) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "$letter.",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (isCorrect) SuccessGreen else Color(0xFF64748B)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = opt,
            style = MaterialTheme.typography.bodySmall,
            color = if (isCorrect) Color(0xFF065F46) else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
          )
          if (isCorrect) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
          }
        }
      }

      // Solution Toggle
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { isExpanded = !isExpanded }
          .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isExpanded) "Hide Solution" else "View Detailed Solution & Key",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = IndigoAccent
        )
        Icon(
          imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
          contentDescription = null,
          tint = IndigoAccent,
          modifier = Modifier.size(18.dp)
        )
      }

      // Expanded Solution
      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF8FAFC))
            .padding(10.dp)
        ) {
          Text(
            text = "Official Answer Key Ref: ${question.officialAnswerKeyRef.ifEmpty { "SSC / Board Master Key" }}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFF0F172A)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = question.explanation,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF334155)
          )
        }
      }
    }
  }
}
