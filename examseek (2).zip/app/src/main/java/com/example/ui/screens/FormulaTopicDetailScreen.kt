package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.formula.SolvedExample
import com.example.domain.formula.TopicPracticeMcq
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.DailyLearningViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormulaTopicDetailScreen(
  viewModel: DailyLearningViewModel,
  topicId: String,
  onNavigateBack: () -> Unit
) {
  val uiState by viewModel.uiState.collectAsState()
  val topic = uiState.selectedTopic

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Formulas, 1: Solved Examples, 2: Practice Quiz

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = topic?.title ?: "Topic Master Sheet",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = topic?.hindiTitle?.ifEmpty { "High-Yield Formulas & Exam Shortcuts" } ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("formula_detail_back")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    }
  ) { paddingValues ->
    if (topic == null) {
      Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
        Text("Topic details not found.")
      }
    } else {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
      ) {

        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = MaterialTheme.colorScheme.surface,
          contentColor = NavyPrimary
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("Formulas & Rules", fontWeight = FontWeight.SemiBold) }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("Examples (${topic.solvedExamples.size})", fontWeight = FontWeight.SemiBold) }
          )
          Tab(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            text = { Text("Quiz (${topic.practiceMcqs.size})", fontWeight = FontWeight.SemiBold) }
          )
        }

        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

          // Topic Concept Summary
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
              border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFBFDBFE)))
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Lightbulb, contentDescription = null, tint = IndigoAccent, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Core Concept & Chapter Overview",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = NavyPrimary
                  )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = topic.summary,
                  style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                  color = Color(0xFF1E3A8A)
                )
              }
            }
          }

          // Tab content
          when (selectedTab) {
            0 -> {
              // Master Core Formula
              item {
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                  elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                  Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                      text = "Primary Formula / Identity",
                      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFF1F5F9))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                    ) {
                      Text(
                        text = topic.coreFormula,
                        style = MaterialTheme.typography.bodyLarge.copy(
                          fontFamily = FontFamily.Monospace,
                          fontWeight = FontWeight.Bold
                        ),
                        color = NavyPrimary
                      )
                    }

                    if (topic.symbolExplanations.isNotEmpty()) {
                      Spacer(modifier = Modifier.height(8.dp))
                      Text(
                        text = "Variable Definitions:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = NavyDark
                      )
                      topic.symbolExplanations.forEach { (sym, desc) ->
                        Text(
                          text = "• $sym = $desc",
                          style = MaterialTheme.typography.bodySmall,
                          color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                      }
                    }
                  }
                }
              }

              // Important Identities
              if (topic.importantIdentities.isNotEmpty()) {
                item {
                  Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                  ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                      Text(
                        text = "Important Identities & Results",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                      )
                      Spacer(modifier = Modifier.height(8.dp))
                      topic.importantIdentities.forEachIndexed { i, identity ->
                        Box(
                          modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                        ) {
                          Text(
                            text = "${i + 1}. $identity",
                            style = MaterialTheme.typography.bodySmall.copy(
                              fontFamily = FontFamily.Monospace,
                              fontWeight = FontWeight.SemiBold
                            ),
                            color = Color(0xFF1E293B)
                          )
                        }
                      }
                    }
                  }
                }
              }

              // Speed Hacks & Shortcuts
              if (topic.shortcutsAndTips.isNotEmpty()) {
                item {
                  Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(WarningAmber))
                  ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = "Exam Speed Tricks & Shortcuts",
                          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                          color = Color(0xFF92400E)
                        )
                      }
                      Spacer(modifier = Modifier.height(6.dp))
                      topic.shortcutsAndTips.forEach { tip ->
                        Text(
                          text = "⚡ $tip",
                          style = MaterialTheme.typography.bodySmall,
                          color = Color(0xFF78350F)
                        )
                      }
                    }
                  }
                }
              }
            }
            1 -> {
              itemsIndexed(topic.solvedExamples) { index, ex ->
                SolvedExampleCard(example = ex, index = index + 1)
              }
            }
            2 -> {
              itemsIndexed(topic.practiceMcqs) { index, mcq ->
                PracticeMcqCard(mcq = mcq, index = index + 1)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun SolvedExampleCard(example: SolvedExample, index: Int) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = "Example $index: ${example.problem}",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
      )
      Spacer(modifier = Modifier.height(8.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xFFF8FAFC))
          .padding(10.dp)
      ) {
        Column {
          Text(
            text = "Step-by-Step Solution:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = NavyPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          example.stepByStepSolution.forEachIndexed { i, step ->
            Text(
              text = "${i + 1}. $step",
              style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
              color = Color(0xFF334155)
            )
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Answer: ${example.finalAnswer}",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = SuccessGreen
          )

          if (example.shortcutTip.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Shortcut: ${example.shortcutTip}",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFF92400E)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun PracticeMcqCard(mcq: TopicPracticeMcq, index: Int) {
  var selectedOption by remember { mutableStateOf<Int?>(null) }
  var isSubmitted by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = "Q$index. ${mcq.question}",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
      )
      Spacer(modifier = Modifier.height(10.dp))

      mcq.options.forEachIndexed { idx, opt ->
        val isThisSelected = selectedOption == idx
        val isCorrect = idx == mcq.correctOptionIndex

        val (optBg, optBorder) = when {
          isSubmitted && isCorrect -> Pair(Color(0xFFD1FAE5), SuccessGreen)
          isSubmitted && isThisSelected && !isCorrect -> Pair(Color(0xFFFEE2E2), ErrorRed)
          isThisSelected -> Pair(Color(0xFFEFF6FF), NavyPrimary)
          else -> Pair(Color(0xFFF8FAFC), Color(0xFFE2E8F0))
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(optBg)
            .border(1.dp, optBorder, RoundedCornerShape(8.dp))
            .clickable(enabled = !isSubmitted) { selectedOption = idx }
            .padding(10.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${listOf("A", "B", "C", "D")[idx]}.",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = opt,
              style = MaterialTheme.typography.bodySmall,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      if (!isSubmitted) {
        Button(
          onClick = { isSubmitted = true },
          enabled = selectedOption != null,
          modifier = Modifier.align(Alignment.End),
          colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Check Answer")
        }
      } else {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF1F5F9))
            .padding(10.dp)
        ) {
          Text(
            text = if (selectedOption == mcq.correctOptionIndex) "Correct! +1 Mark" else "Incorrect!",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = if (selectedOption == mcq.correctOptionIndex) SuccessGreen else ErrorRed
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = mcq.explanation,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF334155)
          )
        }
      }
    }
  }
}
