package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TestResult
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ReviewPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.ExamViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestResultScreen(
  viewModel: ExamViewModel,
  onReviewSolutions: () -> Unit,
  onRetakeOrNewTest: () -> Unit,
  onNavigateHome: () -> Unit
) {
  val state by viewModel.testTakingState.collectAsState()
  val result: TestResult? = state.testResult

  BackHandler {
    onNavigateHome()
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Test Analysis & Scorecard",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateHome) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Home", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    }
  ) { paddingValues ->
    if (result == null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("No active test result found.")
          Spacer(modifier = Modifier.height(12.dp))
          Button(onClick = onNavigateHome) { Text("Back to Home") }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {

        // Hero Score Card
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = NavyPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
          ) {
            Column(
              modifier = Modifier.padding(20.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = result.testTitle,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "15-Question Standard Practice Attempt",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.8f)
              )

              Spacer(modifier = Modifier.height(16.dp))

              // Big Score Circle
              Box(
                modifier = Modifier
                  .size(110.dp)
                  .clip(CircleShape)
                  .background(Color.White.copy(alpha = 0.15f))
                  .border(3.dp, SuccessGreen, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = String.format(Locale.getDefault(), "%.1f", result.marksObtained),
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                  )
                  Text(
                    text = "/ ${result.totalMarks.toInt()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.85f)
                  )
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Percentile & Accuracy Row
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = "${String.format(Locale.getDefault(), "%.1f", result.accuracyPercentage)}%",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                  )
                  Text(
                    text = "Accuracy",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                  )
                }

                Box(
                  modifier = Modifier
                    .width(1.dp)
                    .height(36.dp)
                    .background(Color.White.copy(alpha = 0.3f))
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = "${String.format(Locale.getDefault(), "%.1f", result.percentileEstimate)} %ile",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = WarningAmber
                  )
                  Text(
                    text = "Est. Percentile",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                  )
                }
              }
            }
          }
        }

        // Question Breakdown Card
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "Question Breakdown (Total 15 Questions)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                BreakdownStat(
                  icon = Icons.Default.CheckCircle,
                  color = SuccessGreen,
                  label = "Correct",
                  count = result.correctAnswersCount
                )
                BreakdownStat(
                  icon = Icons.Default.Cancel,
                  color = ErrorRed,
                  label = "Incorrect",
                  count = result.incorrectAnswersCount
                )
                BreakdownStat(
                  icon = Icons.Default.HelpOutline,
                  color = Color(0xFF64748B),
                  label = "Unattempted",
                  count = result.unattemptedCount
                )
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Negative Marking Note
              if (result.negativeMarkingApplied && result.negativeMarksDeducted > 0) {
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFFEF2F2))
                    .padding(10.dp)
                ) {
                  Text(
                    text = "Negative penalty: -${String.format(Locale.getDefault(), "%.2f", result.negativeMarksDeducted)} marks deducted for ${result.incorrectAnswersCount} incorrect questions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrorRed
                  )
                }
              }
            }
          }
        }

        // Action Buttons
        item {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
              onClick = onReviewSolutions,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("review_solutions_button"),
              colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Review Detailed Solutions", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = onRetakeOrNewTest,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("take_another_test_button"),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Take Another 15-Q Mock")
            }

            TextButton(
              onClick = onNavigateHome,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("Back to Dashboard")
            }
          }
        }
      }
    }
  }
}

@Composable
fun BreakdownStat(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  color: Color,
  label: String,
  count: Int
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = "$count",
      style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      color = color
    )
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}
