package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TestQuestion
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.ExamViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolutionReviewScreen(
  viewModel: ExamViewModel,
  onNavigateBack: () -> Unit
) {
  val state by viewModel.testTakingState.collectAsState()
  val result = state.testResult
  val questions = result?.questions ?: emptyList()
  val userAnswers = result?.userAnswers ?: emptyMap()

  var filterMode by remember { mutableStateOf("ALL") } // ALL, INCORRECT, UNATTEMPTED

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Detailed Solutions Review",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = "${questions.size} Questions • Academic Step-by-Step",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

      // Filter chips
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = filterMode == "ALL",
            onClick = { filterMode = "ALL" },
            label = { Text("All (${questions.size})") }
          )
          FilterChip(
            selected = filterMode == "INCORRECT",
            onClick = { filterMode = "INCORRECT" },
            label = { Text("Incorrect (${result?.incorrectAnswersCount ?: 0})") }
          )
          FilterChip(
            selected = filterMode == "UNATTEMPTED",
            onClick = { filterMode = "UNATTEMPTED" },
            label = { Text("Unattempted (${result?.unattemptedCount ?: 0})") }
          )
        }
      }

      // Filtered questions
      val filtered = questions.filterIndexed { idx, q ->
        val userOpt = userAnswers[q.id]
        when (filterMode) {
          "INCORRECT" -> userOpt != null && userOpt != q.correctOptionIndex
          "UNATTEMPTED" -> userOpt == null
          else -> true
        }
      }

      if (filtered.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
          ) {
            Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
              Text("No questions under this filter.")
            }
          }
        }
      } else {
        itemsIndexed(filtered) { index, question ->
          val userOpt = userAnswers[question.id]
          SolutionQuestionItem(
            questionNumber = index + 1,
            question = question,
            userSelectedOption = userOpt,
            onToggleBookmark = { viewModel.toggleBookmark(question) }
          )
        }
      }
    }
  }
}

@Composable
fun SolutionQuestionItem(
  questionNumber: Int,
  question: TestQuestion,
  userSelectedOption: Int?,
  onToggleBookmark: () -> Unit
) {
  var isExpanded by remember { mutableStateOf(true) }
  var isBookmarked by remember { mutableStateOf(false) }

  val isCorrect = userSelectedOption == question.correctOptionIndex
  val isUnattempted = userSelectedOption == null

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {

      // Header row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(
                when {
                  isCorrect -> SuccessGreen
                  isUnattempted -> Color(0xFF94A3B8)
                  else -> ErrorRed
                }
              ),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "$questionNumber",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = when {
              isCorrect -> "Correct (+2.0)"
              isUnattempted -> "Unattempted (0.0)"
              else -> "Incorrect (-0.5)"
            },
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = when {
              isCorrect -> SuccessGreen
              isUnattempted -> Color(0xFF64748B)
              else -> ErrorRed
            }
          )
        }

        Row {
          IconButton(
            onClick = {
              isBookmarked = !isBookmarked
              onToggleBookmark()
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Bookmark",
              tint = NavyPrimary,
              modifier = Modifier.size(20.dp)
            )
          }

          IconButton(
            onClick = { isExpanded = !isExpanded },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
              contentDescription = "Toggle Expand",
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Question Statement
      Text(
        text = question.questionText,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(12.dp))

      // 4 Options review
      question.options.forEachIndexed { optIdx, optText ->
        val isThisCorrect = optIdx == question.correctOptionIndex
        val isThisUserChoice = optIdx == userSelectedOption

        val (optBg, optBorder, optLabelColor) = when {
          isThisCorrect -> Triple(Color(0xFFD1FAE5), SuccessGreen, SuccessGreen)
          isThisUserChoice && !isThisCorrect -> Triple(Color(0xFFFEE2E2), ErrorRed, ErrorRed)
          else -> Triple(Color(0xFFF8FAFC), Color(0xFFE2E8F0), Color(0xFF64748B))
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(optBg)
            .border(1.dp, optBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${listOf("A", "B", "C", "D")[optIdx]}.",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = optLabelColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = optText,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f)
            )
            if (isThisCorrect) {
              Text(
                text = "Correct Answer",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = SuccessGreen
              )
            } else if (isThisUserChoice) {
              Text(
                text = "Your Choice",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = ErrorRed
              )
            }
          }
        }
      }

      // Expandable Solution Explanation
      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFF1F5F9))
            .padding(12.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Detailed Academic Solution",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
              color = NavyDark
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = question.explanation,
            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
            color = Color(0xFF334155)
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Provenance Tag
          Text(
            text = "Official Reference: ${question.officialAnswerKeyRef.ifEmpty { "${question.source} Master Key" }}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
