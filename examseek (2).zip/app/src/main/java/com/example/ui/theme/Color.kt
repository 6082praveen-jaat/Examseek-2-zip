package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Primary & Accents
val NavyPrimary = Color(0xFF1E3A8A)
val NavyDark = Color(0xFF0F172A)
val IndigoAccent = Color(0xFF3B82F6)
val IndigoLight = Color(0xFFDBEAFE)

// Semantic State Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenLight = Color(0xFFD1FAE5)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberLight = Color(0xFFFEF3C7)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedLight = Color(0xFFFEE2E2)
val ReviewPurple = Color(0xFF8B5CF6)
val ReviewPurpleLight = Color(0xFFEDE9FE)

// Surfaces & Backgrounds
val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val BorderLight = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)

// Dark Theme Variants
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF131C31)
val DarkCard = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
