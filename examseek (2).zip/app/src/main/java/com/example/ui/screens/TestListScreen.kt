package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.ExamCategory
import com.example.domain.model.ExamRegistry
import com.example.domain.model.TestItem
import com.example.domain.model.TestType
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.ExamViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestListScreen(
  viewModel: ExamViewModel,
  onNavigateBack: () -> Unit,
  onStartTest: (TestItem) -> Unit
) {
  val selectedCategory by viewModel.selectedCategory.collectAsState()
  val testsList by viewModel.testsList.collectAsState()
  val bankState by viewModel.questionBankState.collectAsState()

  var selectedTypeFilter by remember { mutableStateOf<TestType?>(null) }
  var showGenerateDialog by remember { mutableStateOf(false) }
  var showImportDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "15-Question Test Series",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = "All tests standard 15 Qs • Strict Exam Pattern",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("test_list_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
        },
        actions = {
          IconButton(
            onClick = { showGenerateDialog = true },
            modifier = Modifier.testTag("add_custom_test_button")
          ) {
            Icon(
              imageVector = Icons.Default.Add,
              contentDescription = "Generate 15-Q Test",
              tint = Color.White
            )
          }
          IconButton(
            onClick = { showImportDialog = true },
            modifier = Modifier.testTag("import_bank_button")
          ) {
            Icon(
              imageVector = Icons.Default.FileUpload,
              contentDescription = "Import Questions",
              tint = Color.White
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyPrimary)
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

      // Notification if bank import/generation happened
      bankState.lastImportResult?.let { msg ->
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFD1FAE5)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text(
              text = msg,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
              color = Color(0xFF065F46),
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }

      bankState.aiGenerationMessage?.let { msg ->
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text(
              text = msg,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
              color = Color(0xFF1E40AF),
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }

      // Exam Categories Horizontal Chips
      item {
        Column {
          Text(
            text = "Select Exam Category",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
          )
          Spacer(modifier = Modifier.height(8.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ExamCategory.values()) { cat ->
              val isSelected = selectedCategory == cat
              FilterChip(
                selected = isSelected,
                onClick = { viewModel.selectCategory(cat) },
                label = { Text(cat.displayName) },
                leadingIcon = if (isSelected) {
                  { Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                } else null,
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NavyPrimary,
                  selectedLabelColor = Color.White
                )
              )
            }
          }
        }
      }

      // Test Type Filters (All, Full Mock, Sectional, PYQ)
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = selectedTypeFilter == null,
            onClick = { selectedTypeFilter = null },
            label = { Text("All Mocks") }
          )
          FilterChip(
            selected = selectedTypeFilter == TestType.FULL_MOCK,
            onClick = { selectedTypeFilter = TestType.FULL_MOCK },
            label = { Text("Full Mocks (15 Qs)") }
          )
          FilterChip(
            selected = selectedTypeFilter == TestType.SECTIONAL_TEST,
            onClick = { selectedTypeFilter = TestType.SECTIONAL_TEST },
            label = { Text("Sectional") }
          )
          FilterChip(
            selected = selectedTypeFilter == TestType.PYQ_PAPER,
            onClick = { selectedTypeFilter = TestType.PYQ_PAPER },
            label = { Text("PYQ Papers") }
          )
        }
      }

      // Filtered Test Items
      val filteredList = testsList.filter { test ->
        selectedTypeFilter == null || test.type == selectedTypeFilter
      }

      if (filteredList.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(14.dp)
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "No tests listed for this filter.",
                style = MaterialTheme.typography.bodyMedium
              )
              Spacer(modifier = Modifier.height(10.dp))
              Button(
                onClick = {
                  viewModel.startStandard15QuestionExam(
                    examName = "${selectedCategory.displayName} Master",
                    category = selectedCategory
                  )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
              ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Generate 15-Q Mock with AI")
              }
            }
          }
        }
      } else {
        items(filteredList) { test ->
          Standard15TestCard(
            test = test,
            onStart = { onStartTest(test) }
          )
        }
      }
    }
  }

  // Dialog for generating custom 15-question test
  if (showGenerateDialog) {
    CustomTestGeneratorDialog(
      category = selectedCategory,
      onDismiss = { showGenerateDialog = false },
      onGenerate = { examName, subject ->
        showGenerateDialog = false
        viewModel.startStandard15QuestionExam(
          examName = examName,
          category = selectedCategory,
          subject = subject
        )
      }
    )
  }

  // Dialog for importing question bank JSON
  if (showImportDialog) {
    ImportQuestionsDialog(
      onDismiss = { showImportDialog = false },
      onImport = { json ->
        showImportDialog = false
        viewModel.importQuestionsFromJson(json)
      }
    )
  }
}

@Composable
fun Standard15TestCard(
  test: TestItem,
  onStart: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(NavyPrimary.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "EXACTLY 15 QUESTIONS",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = NavyPrimary
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "${test.durationMinutes} Mins",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = test.title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )

      Text(
        text = test.description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              text = "+${test.marksPerQuestion.toInt()} M",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = SuccessGreen
            )
            Text(
              text = "-${test.negativeMarkingRate} M",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = ErrorRed
            )
            Text(
              text = "Total: ${test.totalMarks.toInt()} Marks",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Text(
            text = "Subject: ${test.subject}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(
          onClick = onStart,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
          modifier = Modifier.testTag("test_list_start_${test.id}")
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Start")
        }
      }
    }
  }
}

@Composable
fun CustomTestGeneratorDialog(
  category: ExamCategory,
  onDismiss: () -> Unit,
  onGenerate: (String, String) -> Unit
) {
  val exams = ExamRegistry.getExamsForCategory(category)
  var selectedExam by remember { mutableStateOf(exams.firstOrNull()?.name ?: "${category.displayName} Exam") }
  var selectedSubject by remember { mutableStateOf("All Subjects") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Generate 15-Question Test",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Choose target exam and subject. Exactly 15 questions will be assembled with deduplication and negative marking.",
          style = MaterialTheme.typography.bodySmall
        )

        Text("Target Exam:", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(exams) { ex ->
            FilterChip(
              selected = selectedExam == ex.name,
              onClick = { selectedExam = ex.name },
              label = { Text(ex.name) }
            )
          }
        }

        Text("Subject Focus:", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
        val subjects = listOf("All Subjects", "Quantitative Aptitude", "Reasoning", "English Comprehension", "General Awareness")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(subjects) { subj ->
            FilterChip(
              selected = selectedSubject == subj,
              onClick = { selectedSubject = subj },
              label = { Text(subj) }
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onGenerate(selectedExam, selectedSubject) },
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
      ) {
        Text("Generate 15-Q Mock")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

@Composable
fun ImportQuestionsDialog(
  onDismiss: () -> Unit,
  onImport: (String) -> Unit
) {
  var jsonInput by remember {
    mutableStateOf(
      """[
  {
    "questionText": "If a train traveling at 72 km/h crosses a 200m platform in 22 seconds, what is the length of the train?",
    "options": ["240 m", "200 m", "220 m", "260 m"],
    "correctOptionIndex": 0,
    "explanation": "Speed = 72 * 5/18 = 20 m/s. Total distance = 20 * 22 = 440 m. Train length = 440 - 200 = 240 m.",
    "subject": "Quantitative Aptitude",
    "topic": "Speed, Time & Distance",
    "targetExam": "SSC CGL",
    "year": "2024",
    "shift": "Shift-1",
    "sourceLabel": "OFFICIAL_VERIFIED_PYQ",
    "officialAnswerKeyRef": "SSC CGL 2024 Tier-1 Master Key Q.42"
  }
]"""
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text("Import Questions to Bank", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Paste JSON formatted questions to import. Duplicates are strictly filtered via SHA-256 content hashing.",
          style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
          value = jsonInput,
          onValueChange = { jsonInput = it },
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
          textStyle = MaterialTheme.typography.bodySmall
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onImport(jsonInput) },
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
      ) {
        Text("Import to Bank")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
