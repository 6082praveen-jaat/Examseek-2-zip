package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.domain.model.CurrentAffairsCategory
import com.example.domain.model.FeedStatus
import com.example.domain.model.LiveCurrentAffairsItem
import com.example.ui.theme.BorderLight
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ReviewPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.DailyLearningViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyLearningScreen(
  viewModel: DailyLearningViewModel,
  onNavigateBack: () -> Unit,
  onTopicSelected: (String) -> Unit
) {
  val uiState by viewModel.uiState.collectAsState()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Daily Revision & Current Affairs",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = "Verified Exam Feeds & 72 Revision Topics",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("daily_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        actions = {
          if (uiState.selectedTab == 0) {
            IconButton(onClick = { viewModel.refreshCurrentAffairs() }) {
              Icon(Icons.Default.Refresh, contentDescription = "Refresh Feeds", tint = Color.White)
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {

      // Tab selector: Current Affairs vs Formula Vault
      TabRow(
        selectedTabIndex = uiState.selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = NavyPrimary
      ) {
        Tab(
          selected = uiState.selectedTab == 0,
          onClick = { viewModel.setTab(0) },
          text = { Text("Live Current Affairs", fontWeight = FontWeight.Bold) },
          icon = { Icon(Icons.Default.Newspaper, contentDescription = null, modifier = Modifier.size(18.dp)) }
        )
        Tab(
          selected = uiState.selectedTab == 1,
          onClick = { viewModel.setTab(1) },
          text = { Text("Formula & Logic Vault", fontWeight = FontWeight.Bold) },
          icon = { Icon(Icons.Default.Functions, contentDescription = null, modifier = Modifier.size(18.dp)) }
        )
      }

      when (uiState.selectedTab) {
        0 -> CurrentAffairsTabContent(
          uiState = uiState,
          onSelectCategory = { viewModel.setCategory(it) },
          onToggleBookmark = { viewModel.toggleBookmarkFeed(it) }
        )
        1 -> FormulaVaultTabContent(
          uiState = uiState,
          onSelectSubject = { viewModel.setFormulaSubject(it) },
          onSelectTopic = onTopicSelected
        )
      }
    }
  }
}

@Composable
fun CurrentAffairsTabContent(
  uiState: com.example.ui.viewmodel.DailyLearningUiState,
  onSelectCategory: (CurrentAffairsCategory) -> Unit,
  onToggleBookmark: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {

    // Category chips
    item {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(CurrentAffairsCategory.values()) { cat ->
          val isSelected = uiState.currentAffairsCategory == cat
          FilterChip(
            selected = isSelected,
            onClick = { onSelectCategory(cat) },
            label = { Text(cat.chipLabel) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NavyPrimary,
              selectedLabelColor = Color.White
            )
          )
        }
      }
    }

    // Filtered Feed Items
    val filteredFeeds = uiState.currentAffairsFeeds.filter {
      uiState.currentAffairsCategory == CurrentAffairsCategory.ALL || it.category == uiState.currentAffairsCategory
    }

    items(filteredFeeds) { item ->
      val isBookmarked = uiState.bookmarkedFeedIds.contains(item.id)
      CurrentAffairsFeedCard(
        item = item,
        isBookmarked = isBookmarked,
        onToggleBookmark = { onToggleBookmark(item.id) }
      )
    }
  }
}

@Composable
fun CurrentAffairsFeedCard(
  item: LiveCurrentAffairsItem,
  isBookmarked: Boolean,
  onToggleBookmark: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Category and Verified Tag
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(IndigoAccent.copy(alpha = 0.12f))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = item.category.chipLabel,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = IndigoAccent
            )
          }

          Spacer(modifier = Modifier.width(6.dp))

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (item.isCached) Color(0xFFFEF3C7) else Color(0xFFD1FAE5))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = if (item.isCached) "Archived Feed" else "Official Release",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
              color = if (item.isCached) WarningAmber else SuccessGreen
            )
          }
        }

        IconButton(onClick = onToggleBookmark, modifier = Modifier.size(28.dp)) {
          Icon(
            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
            contentDescription = "Bookmark",
            tint = NavyPrimary,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = item.title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = item.summary,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFFF1F5F9))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "Source: ${item.source}",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = Color(0xFF475569)
          )
        }

        Text(
          text = item.pubDate,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

@Composable
fun FormulaVaultTabContent(
  uiState: com.example.ui.viewmodel.DailyLearningUiState,
  onSelectSubject: (FormulaSubject) -> Unit,
  onSelectTopic: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {

    // Subject Selector
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FormulaSubject.values().forEach { subj ->
          val isSelected = uiState.formulaSubject == subj
          FilterChip(
            selected = isSelected,
            onClick = { onSelectSubject(subj) },
            label = { Text("${subj.displayName} (${subj.topicCount})") },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NavyPrimary,
              selectedLabelColor = Color.White
            )
          )
        }
      }
    }

    // Overall Subject Mastery Progress
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${uiState.formulaSubject.displayName} Mastery",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "${uiState.topicMasteryPercentage}% Complete",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = SuccessGreen
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          LinearProgressIndicator(
            progress = { uiState.topicMasteryPercentage / 100f },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp)),
            color = SuccessGreen,
            trackColor = Color(0xFFE2E8F0)
          )
        }
      }
    }

    // Topic list (32 Math, 20 Reasoning, 20 English)
    items(uiState.formulaTopics) { topic ->
      FormulaTopicCard(
        topic = topic,
        onClick = { onSelectTopic(topic.id) }
      )
    }
  }
}

@Composable
fun FormulaTopicCard(
  topic: FormulaTopic,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() },
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(NavyPrimary.copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "${topic.chapter.take(4)}",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
          color = NavyPrimary
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = topic.title,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "${topic.importantIdentities.size + 1} Formulas • ${topic.solvedExamples.size} Examples • ${topic.practiceMcqs.size} MCQs",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Icon(
        imageVector = Icons.Default.ChevronRight,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}
