package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ExamRepository
import com.example.domain.model.Difficulty
import com.example.domain.model.ExamCategory
import com.example.domain.model.ExamRegistry
import com.example.domain.model.QuestionStatus
import com.example.domain.model.TestItem
import com.example.domain.model.TestQuestion
import com.example.domain.model.TestResult
import com.example.domain.model.TestType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TestTakingState(
  val testItem: TestItem? = null,
  val questions: List<TestQuestion> = emptyList(),
  val currentQuestionIndex: Int = 0,
  val userAnswers: Map<String, Int?> = emptyMap(), // questionId -> selectedOptionIndex
  val markedForReview: Set<String> = emptySet(),
  val timeRemainingSeconds: Int = 0,
  val isTimerRunning: Boolean = false,
  val isSubmitted: Boolean = false,
  val testResult: TestResult? = null,
  val isLoading: Boolean = false,
  val errorMessage: String? = null
)

data class PyqVaultFilterState(
  val selectedExam: String = "SSC CGL",
  val selectedYear: String = "2024",
  val selectedShift: String = "All",
  val selectedSubject: String = "All",
  val selectedSourceLabel: String = "All",
  val verifiedOnly: Boolean = false,
  val availableYears: List<String> = listOf("2024", "2023", "2022", "2021", "2020", "2019"),
  val availableShifts: List<String> = listOf("All", "Shift-1", "Shift-2", "Shift-3"),
  val availableSubjects: List<String> = listOf("All", "General Intelligence & Reasoning", "Quantitative Aptitude", "English Comprehension", "General Awareness"),
  val questions: List<TestQuestion> = emptyList(),
  val totalMatchingCount: Int = 0,
  val currentPage: Int = 0,
  val pageSize: Int = 20,
  val isLoading: Boolean = false,
  val searchQuery: String = ""
)

data class QuestionBankState(
  val totalQuestionsInBank: Int = 0,
  val lastImportResult: String? = null,
  val isGeneratingAi: Boolean = false,
  val aiGenerationMessage: String? = null
)

class ExamViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = ExamRepository(application)

  private val _selectedCategory = MutableStateFlow(ExamCategory.SSC)
  val selectedCategory: StateFlow<ExamCategory> = _selectedCategory.asStateFlow()

  private val _testsList = MutableStateFlow<List<TestItem>>(emptyList())
  val testsList: StateFlow<List<TestItem>> = _testsList.asStateFlow()

  private val _testTakingState = MutableStateFlow(TestTakingState())
  val testTakingState: StateFlow<TestTakingState> = _testTakingState.asStateFlow()

  private val _pyqVaultState = MutableStateFlow(PyqVaultFilterState())
  val pyqVaultState: StateFlow<PyqVaultFilterState> = _pyqVaultState.asStateFlow()

  private val _questionBankState = MutableStateFlow(QuestionBankState())
  val questionBankState: StateFlow<QuestionBankState> = _questionBankState.asStateFlow()

  private val _bookmarkedQuestions = MutableStateFlow<List<TestQuestion>>(emptyList())
  val bookmarkedQuestions: StateFlow<List<TestQuestion>> = _bookmarkedQuestions.asStateFlow()

  private val _wrongAnswers = MutableStateFlow<List<Pair<TestQuestion, Int>>>(emptyList())
  val wrongAnswers: StateFlow<List<Pair<TestQuestion, Int>>> = _wrongAnswers.asStateFlow()

  private var timerJob: Job? = null

  init {
    viewModelScope.launch {
      repository.initializeIfNeeded()
      loadTestsForCategory(_selectedCategory.value)
      loadPyqVault()
      loadBookmarksAndMistakes()
    }
  }

  fun selectCategory(category: ExamCategory) {
    _selectedCategory.value = category
    loadTestsForCategory(category)
  }

  fun loadTestsForCategory(category: ExamCategory) {
    viewModelScope.launch {
      val tests = repository.getTestsByCategory(category.id)
      _testsList.value = tests
    }
  }

  // --- START 15-QUESTION TEST ---
  fun startTest(testItem: TestItem) {
    viewModelScope.launch {
      _testTakingState.value = TestTakingState(isLoading = true)

      // Fetch exactly 15 questions for standard test
      val questions = repository.getQuestionsForTest(testItem.id).take(15)

      // Check if there was an active session to resume
      val activeSession = repository.getActiveSession(testItem.id)
      val initialAnswers = mutableMapOf<String, Int?>()
      val initialReview = mutableSetOf<String>()
      var initialIndex = 0
      var timeSeconds = testItem.durationMinutes * 60

      if (activeSession != null) {
        try {
          val jsonAns = org.json.JSONObject(activeSession.answersSummary)
          val keys = jsonAns.keys()
          while (keys.hasNext()) {
            val k = keys.next()
            initialAnswers[k] = jsonAns.getInt(k)
          }
          val reviewArr = org.json.JSONArray(activeSession.markedReviewSummary)
          for (i in 0 until reviewArr.length()) {
            initialReview.add(reviewArr.getString(i))
          }
          initialIndex = activeSession.currentIndex.coerceIn(0, (questions.size - 1).coerceAtLeast(0))
          timeSeconds = activeSession.timeRemainingSeconds
        } catch (_: Exception) {}
      }

      _testTakingState.value = TestTakingState(
        testItem = testItem,
        questions = questions,
        currentQuestionIndex = initialIndex,
        userAnswers = initialAnswers,
        markedForReview = initialReview,
        timeRemainingSeconds = timeSeconds,
        isTimerRunning = true,
        isLoading = false
      )

      startTimer()
    }
  }

  // Generate a dynamic standard 15-question test for any exam
  fun startStandard15QuestionExam(examName: String, category: ExamCategory, subject: String = "All Subjects") {
    viewModelScope.launch {
      _testTakingState.value = TestTakingState(isLoading = true)
      val (testItem, questions) = repository.generateOrGetStandard15QuestionTest(
        examName = examName,
        category = category,
        subject = subject,
        testType = TestType.FULL_MOCK
      )

      _testTakingState.value = TestTakingState(
        testItem = testItem,
        questions = questions.take(15),
        currentQuestionIndex = 0,
        userAnswers = emptyMap(),
        markedForReview = emptySet(),
        timeRemainingSeconds = testItem.durationMinutes * 60,
        isTimerRunning = true,
        isLoading = false
      )

      startTimer()
    }
  }

  // Start 15-question PYQ Drill from current PYQ filters
  fun startPyqDrill(onStarted: () -> Unit) {
    viewModelScope.launch {
      val state = _pyqVaultState.value
      _testTakingState.value = TestTakingState(isLoading = true)
      val (testItem, questions) = repository.createPyqDrillTest(
        exam = state.selectedExam,
        year = state.selectedYear,
        shift = state.selectedShift,
        subject = state.selectedSubject
      )

      _testTakingState.value = TestTakingState(
        testItem = testItem,
        questions = questions.take(15),
        currentQuestionIndex = 0,
        userAnswers = emptyMap(),
        markedForReview = emptySet(),
        timeRemainingSeconds = testItem.durationMinutes * 60,
        isTimerRunning = true,
        isLoading = false
      )

      startTimer()
      onStarted()
    }
  }

  private fun startTimer() {
    timerJob?.cancel()
    timerJob = viewModelScope.launch {
      while (_testTakingState.value.isTimerRunning && _testTakingState.value.timeRemainingSeconds > 0) {
        delay(1000)
        _testTakingState.update { it.copy(timeRemainingSeconds = it.timeRemainingSeconds - 1) }

        // Periodically autosave state every 10s
        val current = _testTakingState.value
        if (current.timeRemainingSeconds % 10 == 0 && current.testItem != null) {
          repository.saveActiveSession(
            testId = current.testItem.id,
            currentIndex = current.currentQuestionIndex,
            timeRemainingSeconds = current.timeRemainingSeconds,
            answers = current.userAnswers,
            markedForReview = current.markedForReview
          )
        }
      }

      if (_testTakingState.value.timeRemainingSeconds <= 0 && !_testTakingState.value.isSubmitted) {
        submitCurrentTest()
      }
    }
  }

  // Save selected option for current question
  fun selectAnswer(questionId: String, optionIndex: Int) {
    _testTakingState.update { state ->
      val newAnswers = state.userAnswers.toMutableMap()
      newAnswers[questionId] = optionIndex
      state.copy(userAnswers = newAnswers)
    }
    persistActiveSession()
  }

  fun clearSelectedAnswer(questionId: String) {
    _testTakingState.update { state ->
      val newAnswers = state.userAnswers.toMutableMap()
      newAnswers.remove(questionId)
      state.copy(userAnswers = newAnswers)
    }
    persistActiveSession()
  }

  fun toggleMarkForReview(questionId: String) {
    _testTakingState.update { state ->
      val newReview = state.markedForReview.toMutableSet()
      if (newReview.contains(questionId)) {
        newReview.remove(questionId)
      } else {
        newReview.add(questionId)
      }
      state.copy(markedForReview = newReview)
    }
    persistActiveSession()
  }

  // Save & Next button behavior: saves answer, moves to next question, or stays if on last question
  fun saveAndNext() {
    val state = _testTakingState.value
    if (state.currentQuestionIndex < state.questions.size - 1) {
      _testTakingState.update { it.copy(currentQuestionIndex = it.currentQuestionIndex + 1) }
    }
    persistActiveSession()
  }

  fun goToPreviousQuestion() {
    val state = _testTakingState.value
    if (state.currentQuestionIndex > 0) {
      _testTakingState.update { it.copy(currentQuestionIndex = it.currentQuestionIndex - 1) }
    }
    persistActiveSession()
  }

  fun jumpToQuestion(index: Int) {
    val state = _testTakingState.value
    if (index in state.questions.indices) {
      _testTakingState.update { it.copy(currentQuestionIndex = index) }
      persistActiveSession()
    }
  }

  private fun persistActiveSession() {
    viewModelScope.launch {
      val state = _testTakingState.value
      val testItem = state.testItem ?: return@launch
      repository.saveActiveSession(
        testId = testItem.id,
        currentIndex = state.currentQuestionIndex,
        timeRemainingSeconds = state.timeRemainingSeconds,
        answers = state.userAnswers,
        markedForReview = state.markedForReview
      )
    }
  }

  fun submitCurrentTest() {
    val state = _testTakingState.value
    val testItem = state.testItem ?: return
    timerJob?.cancel()

    viewModelScope.launch {
      _testTakingState.update { it.copy(isLoading = true, isTimerRunning = false) }
      val totalTime = testItem.durationMinutes * 60
      val timeSpent = (totalTime - state.timeRemainingSeconds).coerceAtLeast(1)

      val result = repository.submitTest(
        testItem = testItem,
        questions = state.questions,
        answers = state.userAnswers,
        timeSpentSeconds = timeSpent
      )

      _testTakingState.update {
        it.copy(
          isLoading = false,
          isSubmitted = true,
          testResult = result
        )
      }
      loadBookmarksAndMistakes()
    }
  }

  fun getQuestionStatus(question: TestQuestion): QuestionStatus {
    val state = _testTakingState.value
    val isAnswered = state.userAnswers.containsKey(question.id) && state.userAnswers[question.id] != null
    val isMarked = state.markedForReview.contains(question.id)

    return when {
      isAnswered && isMarked -> QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW
      isMarked -> QuestionStatus.MARKED_FOR_REVIEW
      isAnswered -> QuestionStatus.ANSWERED
      else -> QuestionStatus.NOT_ANSWERED
    }
  }

  // --- PYQ VAULT LOGIC ---
  fun setPyqExam(exam: String) {
    _pyqVaultState.update { it.copy(selectedExam = exam, currentPage = 0) }
    viewModelScope.launch {
      val years = repository.getPyqYears(exam)
      val shifts = repository.getPyqShifts(exam, _pyqVaultState.value.selectedYear)
      val subjects = repository.getPyqSubjects(exam)
      _pyqVaultState.update {
        it.copy(
          availableYears = years,
          availableShifts = listOf("All") + shifts,
          availableSubjects = listOf("All") + subjects
        )
      }
      loadPyqVault()
    }
  }

  fun setPyqYear(year: String) {
    _pyqVaultState.update { it.copy(selectedYear = year, currentPage = 0) }
    viewModelScope.launch {
      val shifts = repository.getPyqShifts(_pyqVaultState.value.selectedExam, year)
      _pyqVaultState.update { it.copy(availableShifts = listOf("All") + shifts) }
      loadPyqVault()
    }
  }

  fun setPyqShift(shift: String) {
    _pyqVaultState.update { it.copy(selectedShift = shift, currentPage = 0) }
    loadPyqVault()
  }

  fun setPyqSubject(subject: String) {
    _pyqVaultState.update { it.copy(selectedSubject = subject, currentPage = 0) }
    loadPyqVault()
  }

  fun setPyqSourceLabel(label: String) {
    _pyqVaultState.update { it.copy(selectedSourceLabel = label, currentPage = 0) }
    loadPyqVault()
  }

  fun togglePyqVerifiedOnly() {
    _pyqVaultState.update { it.copy(verifiedOnly = !it.verifiedOnly, currentPage = 0) }
    loadPyqVault()
  }

  fun setPyqSearchQuery(query: String) {
    _pyqVaultState.update { it.copy(searchQuery = query) }
  }

  fun loadPyqVault() {
    viewModelScope.launch {
      val s = _pyqVaultState.value
      _pyqVaultState.update { it.copy(isLoading = true) }

      val questions = repository.queryPyqVault(
        exam = s.selectedExam,
        year = s.selectedYear,
        shift = s.selectedShift,
        subject = s.selectedSubject,
        sourceLabel = s.selectedSourceLabel,
        verifiedOnly = s.verifiedOnly,
        limit = s.pageSize,
        offset = s.currentPage * s.pageSize
      )

      val totalCount = repository.countPyqVault(
        exam = s.selectedExam,
        year = s.selectedYear,
        shift = s.selectedShift,
        subject = s.selectedSubject,
        sourceLabel = s.selectedSourceLabel,
        verifiedOnly = s.verifiedOnly
      )

      _pyqVaultState.update {
        it.copy(
          questions = questions,
          totalMatchingCount = totalCount,
          isLoading = false
        )
      }
    }
  }

  // --- QUESTION BANK GROWING & IMPORT ---
  fun importQuestionsFromJson(json: String) {
    viewModelScope.launch {
      val (imported, skipped) = repository.importQuestionsFromJson(json)
      _questionBankState.update {
        it.copy(
          lastImportResult = "Successfully imported $imported questions ($skipped duplicates skipped)."
        )
      }
      loadPyqVault()
    }
  }

  fun generateAiQuestionsForBank(examName: String, category: String, subject: String, count: Int = 5) {
    viewModelScope.launch {
      _questionBankState.update { it.copy(isGeneratingAi = true, aiGenerationMessage = "Generating $count questions for $examName...") }
      try {
        val generated = repository.generateAiQuestionsForBank(
          examName = examName,
          category = category,
          subject = subject,
          count = count,
          difficulty = Difficulty.MEDIUM
        )
        _questionBankState.update {
          it.copy(
            isGeneratingAi = false,
            aiGenerationMessage = "Successfully generated and added ${generated.size} practice questions with deduplication checks."
          )
        }
        loadPyqVault()
      } catch (e: Exception) {
        _questionBankState.update {
          it.copy(
            isGeneratingAi = false,
            aiGenerationMessage = "Generation failed: ${e.message}"
          )
        }
      }
    }
  }

  // --- BOOKMARKS & MISTAKES ---
  fun toggleBookmark(question: TestQuestion) {
    viewModelScope.launch {
      repository.toggleBookmark(question)
      loadBookmarksAndMistakes()
    }
  }

  private fun loadBookmarksAndMistakes() {
    viewModelScope.launch {
      val bookmarks = repository.getBookmarkedQuestions()
      val mistakes = repository.getWrongAnswers()
      _bookmarkedQuestions.value = bookmarks
      _wrongAnswers.value = mistakes
    }
  }
}
