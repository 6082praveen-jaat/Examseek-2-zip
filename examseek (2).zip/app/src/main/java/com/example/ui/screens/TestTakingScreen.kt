package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.QuestionStatus
import com.example.domain.model.TestQuestion
import com.example.ui.theme.DarkCard
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ReviewPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.ExamViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestTakingScreen(
  viewModel: ExamViewModel,
  onTestSubmitted: () -> Unit,
  onExitTest: () -> Unit
) {
  val state by viewModel.testTakingState.collectAsState()
  var showPaletteSheet by remember { mutableStateOf(false) }
  var showSubmitDialog by remember { mutableStateOf(false) }
  var showExitDialog by remember { mutableStateOf(false) }
  var isHindiSelected by remember { mutableStateOf(false) }

  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  BackHandler {
    showExitDialog = true
  }

  if (state.isLoading) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator(color = NavyPrimary)
        Spacer(modifier = Modifier.height(12.dp))
        Text("Loading 15-Question Test Environment...")
      }
    }
    return
  }

  val test = state.testItem
  val questions = state.questions
  val currentQuestion = questions.getOrNull(state.currentQuestionIndex)

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = test?.title ?: "15-Question CBT Mock Test",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              maxLines = 1
            )
            Text(
              text = "Question ${state.currentQuestionIndex + 1} of ${questions.size}",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.85f)
            )
          }
        },
        actions = {
          // Timer Badge
          val minutes = state.timeRemainingSeconds / 60
          val seconds = state.timeRemainingSeconds % 60
          val isTimeLow = state.timeRemainingSeconds < 120

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isTimeLow) ErrorRed else Color.White.copy(alpha = 0.2f))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Timer,
                contentDescription = "Timer",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds),
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
          }

          // Question Palette Trigger
          IconButton(
            onClick = { showPaletteSheet = true },
            modifier = Modifier.testTag("open_palette_button")
          ) {
            Icon(
              imageVector = Icons.Default.GridView,
              contentDescription = "Question Palette",
              tint = Color.White
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    },
    bottomBar = {
      // CBT Action Controls
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surface)
          .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
          .padding(horizontal = 12.dp, vertical = 8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Mark for Review Button
          val isMarked = currentQuestion?.let { state.markedForReview.contains(it.id) } == true
          OutlinedButton(
            onClick = { currentQuestion?.let { viewModel.toggleMarkForReview(it.id) } },
            modifier = Modifier.testTag("mark_review_button"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(
              contentColor = if (isMarked) ReviewPurple else MaterialTheme.colorScheme.onSurface
            )
          ) {
            Text(if (isMarked) "Unmark" else "Mark Review", fontSize = 12.sp)
          }

          // Clear Button
          TextButton(
            onClick = { currentQuestion?.let { viewModel.clearSelectedAnswer(it.id) } },
            modifier = Modifier.testTag("clear_response_button")
          ) {
            Text("Clear", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
          }

          // Previous Button
          OutlinedButton(
            onClick = { viewModel.goToPreviousQuestion() },
            enabled = state.currentQuestionIndex > 0,
            modifier = Modifier.testTag("prev_question_button"),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text("Previous", fontSize = 12.sp)
          }

          // Save & Next Button
          Button(
            onClick = { viewModel.saveAndNext() },
            modifier = Modifier.testTag("save_and_next_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text("Save & Next", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Full Submit Button
        Button(
          onClick = { showSubmitDialog = true },
          modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .testTag("submit_test_button"),
          colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Submit 15-Question Test", fontWeight = FontWeight.Bold)
        }
      }
    }
  ) { paddingValues ->
    if (currentQuestion == null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues),
        contentAlignment = Alignment.Center
      ) {
        Text("No question available.")
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {

        // Question Header Card
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Subject Tag
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(IndigoAccent.copy(alpha = 0.12f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "${currentQuestion.subject} • ${currentQuestion.topic}",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = IndigoAccent
              )
            }

            // Marking Scheme
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(Color(0xFFD1FAE5))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "+${test?.marksPerQuestion?.toInt() ?: 2}",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = SuccessGreen
                )
              }
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(Color(0xFFFEE2E2))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "-${test?.negativeMarkingRate ?: 0.5f}",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = ErrorRed
                )
              }
            }
          }
        }

        // Hindi Toggle if available
        if (currentQuestion.hindiQuestionText.isNotBlank()) {
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End,
              verticalAlignment = Alignment.CenterVertically
            ) {
              IconButton(onClick = { isHindiSelected = !isHindiSelected }) {
                Icon(Icons.Default.Language, contentDescription = "Toggle Language")
              }
              Text(
                text = if (isHindiSelected) "English" else "हिंदी",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = NavyPrimary,
                modifier = Modifier.clickable { isHindiSelected = !isHindiSelected }
              )
            }
          }
        }

        // Question Statement
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = if (isHindiSelected && currentQuestion.hindiQuestionText.isNotBlank()) {
                  currentQuestion.hindiQuestionText
                } else {
                  currentQuestion.questionText
                },
                style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 24.sp, fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
              )

              // Source/Provenance Badge
              Spacer(modifier = Modifier.height(10.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Source: ${currentQuestion.source} (${currentQuestion.year})",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                IconButton(
                  onClick = { viewModel.toggleBookmark(currentQuestion) },
                  modifier = Modifier.size(24.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = NavyPrimary,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }
          }
        }

        // 4 Options
        val selectedOption = state.userAnswers[currentQuestion.id]
        val optionsList = if (isHindiSelected && currentQuestion.hindiOptions.isNotEmpty()) {
          currentQuestion.hindiOptions
        } else {
          currentQuestion.options
        }

        itemsIndexed(optionsList) { optIdx, optText ->
          val isSelected = selectedOption == optIdx
          val optLabel = when (optIdx) {
            0 -> "A"
            1 -> "B"
            2 -> "C"
            else -> "D"
          }

          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("option_${currentQuestion.id}_$optIdx")
              .clickable { viewModel.selectAnswer(currentQuestion.id, optIdx) },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) Color(0xFFEFF6FF) else MaterialTheme.colorScheme.surface
            ),
            border = if (isSelected) {
              CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NavyPrimary))
            } else {
              CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)))
            }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(34.dp)
                  .clip(CircleShape)
                  .background(if (isSelected) NavyPrimary else Color(0xFFF1F5F9))
                  .border(1.dp, if (isSelected) NavyPrimary else Color(0xFFCBD5E1), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = optLabel,
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                  color = if (isSelected) Color.White else NavyDark
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Text(
                text = optText,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isSelected) NavyPrimary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
              )
            }
          }
        }
      }
    }
  }

  // Question Palette Bottom Sheet (15 questions)
  if (showPaletteSheet) {
    ModalBottomSheet(
      onDismissRequest = { showPaletteSheet = false },
      sheetState = sheetState
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Question Palette (15 Questions)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          IconButton(onClick = { showPaletteSheet = false }) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Legend
        PaletteLegend()

        Spacer(modifier = Modifier.height(16.dp))

        // Grid of 15 buttons
        LazyVerticalGrid(
          columns = GridCells.Fixed(5),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          gridItemsIndexed(questions) { index, q ->
            val status = viewModel.getQuestionStatus(q)
            val isCurrent = index == state.currentQuestionIndex

            val (bgColor, textColor) = when (status) {
              QuestionStatus.ANSWERED -> Pair(SuccessGreen, Color.White)
              QuestionStatus.MARKED_FOR_REVIEW -> Pair(ReviewPurple, Color.White)
              QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW -> Pair(Color(0xFF7C3AED), Color.White)
              QuestionStatus.NOT_ANSWERED -> Pair(ErrorRed, Color.White)
              QuestionStatus.NOT_VISITED -> Pair(Color(0xFFE2E8F0), Color(0xFF475569))
            }

            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(bgColor)
                .border(
                  width = if (isCurrent) 2.dp else 0.dp,
                  color = if (isCurrent) NavyDark else Color.Transparent,
                  shape = RoundedCornerShape(8.dp)
                )
                .clickable {
                  viewModel.jumpToQuestion(index)
                  showPaletteSheet = false
                },
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "${index + 1}",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = textColor
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }

  // Submission Confirmation Dialog
  if (showSubmitDialog) {
    val answeredCount = state.userAnswers.values.filterNotNull().size
    val markedCount = state.markedForReview.size
    val unattemptedCount = questions.size - answeredCount

    AlertDialog(
      onDismissRequest = { showSubmitDialog = false },
      title = {
        Text("Submit 15-Question Test?", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("Are you sure you want to finish this attempt? Review your summary below:")
          Spacer(modifier = Modifier.height(4.dp))
          Text("• Total Questions: ${questions.size}", fontWeight = FontWeight.SemiBold)
          Text("• Answered: $answeredCount", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
          Text("• Marked for Review: $markedCount", color = ReviewPurple, fontWeight = FontWeight.SemiBold)
          Text("• Unattempted: $unattemptedCount", color = ErrorRed, fontWeight = FontWeight.SemiBold)
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showSubmitDialog = false
            viewModel.submitCurrentTest()
            onTestSubmitted()
          },
          colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
        ) {
          Text("Confirm Submit")
        }
      },
      dismissButton = {
        TextButton(onClick = { showSubmitDialog = false }) {
          Text("Review Again")
        }
      }
    )
  }

  // Exit Confirmation Dialog
  if (showExitDialog) {
    AlertDialog(
      onDismissRequest = { showExitDialog = false },
      title = { Text("Pause or Leave Test?") },
      text = {
        Text("Your responses and remaining time are saved in the local database. You can resume this 15-question test at any time.")
      },
      confirmButton = {
        Button(
          onClick = {
            showExitDialog = false
            onExitTest()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
        ) {
          Text("Exit Test")
        }
      },
      dismissButton = {
        TextButton(onClick = { showExitDialog = false }) {
          Text("Resume")
        }
      }
    )
  }
}

@Composable
fun PaletteLegend() {
  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      LegendItem(color = SuccessGreen, label = "Answered")
      LegendItem(color = ErrorRed, label = "Not Answered")
      LegendItem(color = ReviewPurple, label = "Marked for Review")
    }
  }
}

@Composable
fun LegendItem(color: Color, label: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(12.dp)
        .clip(CircleShape)
        .background(color)
    )
    Spacer(modifier = Modifier.width(4.dp))
    Text(text = label, style = MaterialTheme.typography.labelSmall)
  }
}
