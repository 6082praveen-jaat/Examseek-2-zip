package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrustAndLegalScreen(onNavigateBack: () -> Unit) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Trust, Copyright & Academic Integrity",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("trust_legal_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Shield, contentDescription = null, tint = SuccessGreen)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "1. Provenance & Official PYQs",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "ExamSeek collects and indexes Previous Year Questions exclusively from legally authorized public answer keys released by exam boards (such as Staff Selection Commission, Railway Recruitment Boards, Institute of Banking Personnel Selection, and Union Public Service Commission). Every question in the PYQ Vault includes its source exam, year, shift, and official answer-key reference where applicable.",
              style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
              color = Color(0xFF334155)
            )
          }
        }
      }

      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Security, contentDescription = null, tint = NavyPrimary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "2. AI Content Transparency & Integrity",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "• AI-generated practice questions are explicitly labeled AI_GENERATED_PRACTICE and are never passed off as official PYQs.\n" +
                "• All AI-generated content is automatically validated for valid options, balanced difficulty, and unique cryptographic hashes (SHA-256) to prevent repetition.\n" +
                "• In the AI Doubt Guru, if an uploaded question image is blurry, partial, or illegible, the system will explicitly request a clearer image rather than guessing or fabricating the question.",
              style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
              color = Color(0xFF334155)
            )
          }
        }
      }

      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Gavel, contentDescription = null, tint = Color(0xFFB45309))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "3. Fair Use & Educational Disclaimer",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "ExamSeek is an independent educational tool designed solely to assist aspirants preparing for competitive examinations. ExamSeek is NOT affiliated with, authorized by, or endorsed by any government entity, recruitment commission, or public board. All trademarks and official board names belong to their respective holders.",
              style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
              color = Color(0xFF334155)
            )
          }
        }
      }
    }
  }
}
