package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.currentaffairs.LiveCurrentAffairsService
import com.example.data.formula.FormulaRepository
import com.example.domain.formula.FormulaSubject
import com.example.domain.formula.FormulaTopic
import com.example.domain.formula.TopicQuizResult
import com.example.domain.model.CurrentAffairsCategory
import com.example.domain.model.LiveCurrentAffairsItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DailyLearningUiState(
  val selectedTab: Int = 0, // 0: Current Affairs, 1: Formula Hub
  val currentAffairsCategory: CurrentAffairsCategory = CurrentAffairsCategory.ALL,
  val currentAffairsFeeds: List<LiveCurrentAffairsItem> = emptyList(),
  val bookmarkedFeedIds: Set<String> = emptySet(),
  val isRefreshingFeeds: Boolean = false,
  val formulaSubject: FormulaSubject = FormulaSubject.MATHEMATICS,
  val formulaTopics: List<FormulaTopic> = emptyList(),
  val selectedTopic: FormulaTopic? = null,
  val topicMasteryPercentage: Int = 0,
  val bookmarkedTopicIds: Set<String> = emptySet(),
  val completedTopicIds: Set<String> = emptySet()
)

class DailyLearningViewModel(application: Application) : AndroidViewModel(application) {

  private val caService = LiveCurrentAffairsService()
  private val formulaRepo = FormulaRepository(application)

  private val _uiState = MutableStateFlow(DailyLearningUiState())
  val uiState: StateFlow<DailyLearningUiState> = _uiState.asStateFlow()

  init {
    loadFeeds()
    loadFormulaTopics(FormulaSubject.MATHEMATICS)

    viewModelScope.launch {
      caService.state.collect { caState ->
        _uiState.update {
          it.copy(
            currentAffairsFeeds = caState.items,
            isRefreshingFeeds = caState.isLoading
          )
        }
      }
    }

    viewModelScope.launch {
      formulaRepo.completedTopicIds.collect { completed ->
        val total = _uiState.value.formulaTopics.size.coerceAtLeast(1)
        val subjectCompleted = _uiState.value.formulaTopics.count { completed.contains(it.id) }
        val mastery = ((subjectCompleted.toFloat() / total) * 100f).toInt()
        _uiState.update { it.copy(completedTopicIds = completed, topicMasteryPercentage = mastery) }
      }
    }
  }

  fun setTab(index: Int) {
    _uiState.update { it.copy(selectedTab = index) }
  }

  fun setCategory(category: CurrentAffairsCategory) {
    _uiState.update { it.copy(currentAffairsCategory = category) }
  }

  fun refreshCurrentAffairs() {
    viewModelScope.launch {
      caService.fetchLiveFeeds(force = true)
    }
  }

  private fun loadFeeds() {
    viewModelScope.launch {
      caService.fetchLiveFeeds(force = false)
    }
  }

  fun toggleBookmarkFeed(id: String) {
    _uiState.update { current ->
      val updated = current.bookmarkedFeedIds.toMutableSet()
      if (updated.contains(id)) updated.remove(id) else updated.add(id)
      current.copy(bookmarkedFeedIds = updated)
    }
  }

  fun setFormulaSubject(subject: FormulaSubject) {
    _uiState.update { it.copy(formulaSubject = subject) }
    loadFormulaTopics(subject)
  }

  private fun loadFormulaTopics(subject: FormulaSubject) {
    val topics = formulaRepo.getTopicsBySubject(subject)
    val completed = formulaRepo.completedTopicIds.value
    val subjectCompleted = topics.count { completed.contains(it.id) }
    val mastery = if (topics.isNotEmpty()) ((subjectCompleted.toFloat() / topics.size) * 100f).toInt() else 0
    _uiState.update {
      it.copy(
        formulaTopics = topics,
        topicMasteryPercentage = mastery,
        bookmarkedTopicIds = formulaRepo.bookmarkedTopicIds.value,
        completedTopicIds = completed
      )
    }
  }

  fun selectTopic(topicId: String) {
    val topic = formulaRepo.getTopicById(topicId)
    formulaRepo.recordTopicView(topicId)
    _uiState.update { it.copy(selectedTopic = topic) }
  }

  fun clearSelectedTopic() {
    _uiState.update { it.copy(selectedTopic = null) }
  }

  fun recordPracticeScore(topicId: String, score: Int, total: Int) {
    formulaRepo.recordQuizAttempt(
      TopicQuizResult(
        topicId = topicId,
        score = score,
        totalQuestions = total,
        timestamp = System.currentTimeMillis()
      )
    )
    loadFormulaTopics(_uiState.value.formulaSubject)
  }
}
